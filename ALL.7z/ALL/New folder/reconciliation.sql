
      reconciliation 
	  (p_batch_order.batchid, 
	  p_batch_order.messagesequenceno, 
	  p_batch_order.batchnototal, 
	  p_batch_order.messagedetailcount, 
	  p_batch_order.batchdate,
	  p_batch_order.batchdetailcount,-- p_batch_order.MessageDetailCount,

PROCEDURE reconciliation
    (
      p_batchid           IN VARCHAR2 ,
      p_batchmessagecount IN NUMBER,
      p_batchnototal      IN NUMBER,
      p_line_count        IN NUMBER,
      p_batchdate         IN DATE,
      p_orderlinetotal    IN NUMBER,
      p_maximumorderdate  IN DATE,
      p_minimumorderdate  IN DATE ,
      p_orderlinesmessage IN NUMBER,
      p_headers_agg       IN NUMBER,
      p_lines_agg         IN NUMBER,
      p_tot_msg           IN NUMBER,---version 1.15----
      p_finish_status OUT BOOLEAN,
      p_status_code IN OUT NUMBER
    )
  AS
    v_batch_count NUMBER:=0;
    v_line_count  NUMBER:=0;
    v_orderlines  NUMBER:=0;
    v_batch_date  DATE;
    v_count       NUMBER:=0;
    v_recon_text  VARCHAR2 (2000);
    v_log_level   NUMBER := fnd_log.level_procedure;
    v_max_date    DATE   := p_maximumorderdate;
    v_min_date    DATE   := p_minimumorderdate;
    CURSOR c_order_batch
    IS
      SELECT * FROM xxcu.xxcu_ont_int_order_batch WHERE batchid = p_batchid;
    r_order_batch c_order_batch%rowtype;
  BEGIN
    OPEN c_order_batch;
    FETCH c_order_batch INTO r_order_batch;
    IF c_order_batch%found THEN
      v_batch_count                  := r_order_batch.batch_no + 1;
      v_batch_date                   := r_order_batch.batch_date;
      v_orderlines                   := r_order_batch.orderline_count +p_orderlinesmessage;-- p_orderlinetotal;
      v_line_count                   := r_order_batch.lines_imported  + p_line_count;
	  
	  
      IF r_order_batch.max_order_date > v_max_date THEN
        v_max_date                   := r_order_batch.max_order_date; --Not bigger than old value from database
      END IF;
      IF r_order_batch.min_order_date < v_min_date THEN
        v_min_date                   := r_order_batch.min_order_date; --Not smaller than old value from database
      END IF;
	  
	  
      UPDATE xxcu.xxcu_ont_int_order_batch
      SET batch_no      = v_batch_count,
        orderline_count = v_orderlines,
        lines_imported  = v_line_count,
        headers_agg      = headers_agg + p_headers_agg,
        lines_agg        = lines_agg   + p_lines_agg,
        max_order_date   = v_max_date,
        min_order_date   = v_min_date,
        tot_no_msg       =p_tot_msg,
        last_update_date = to_date(sysdate,'DD-MON-YY HH24:MI:SS')
      WHERE batchid      = p_batchid;
    
	
	
	ELSE
      v_batch_count := p_batchmessagecount;
      v_batch_date  := to_date(sysdate,'DD-MON-YY HH24:MI:SS');
      v_line_count  := p_line_count;
      v_orderlines  := p_orderlinesmessage;
	  
	  
      INSERT
      INTO xxcu.xxcu_ont_int_order_batch
        (
          batchid,
          batch_no,
          batch_no_total,
          batch_date,
          orderline_total,
          orderline_count,
          lines_imported,
          last_update_date,
          max_order_date,
          min_order_date,
          headers_agg,
          lines_agg,
          status,
          tot_no_msg
        )
        VALUES
        (
          p_batchid,
          1,
          p_batchnototal,
          to_date(p_batchdate,'DD-MON-YY HH24:MI:SS'),
          p_orderlinetotal,
          p_orderlinesmessage,
          v_line_count,
          to_date(sysdate,'DD-MON-YY HH24:MI:SS'),
          v_max_date,
          v_min_date,
          p_headers_agg,
          p_lines_agg,
          'AQ IMPORT',
          p_tot_msg
        );
    END IF;
    COMMIT;
    p_finish_status:=true;
    CLOSE c_order_batch;
    
    dbms_output.put_line('p_batchnototal'|| p_batchnototal);
    dbms_output.put_line('v_batch_count'|| v_batch_count);
    
    v_recon_text := v_recon_text || ' || In summary, for the transfer of BatchID = ' || p_batchid || ' || Batch_no' || p_batchnototal || ' - Meldinger Mottatt = ' || v_batch_count || ' - Forventet = ' || p_batchnototal || '|| Ordreliner mottatt = ' || p_orderlinetotal || ' Ordrelinjer forventet = ' || v_orderlines || ' - Behandlet = ' || v_line_count || ' || Siste melding:' || ' - Forventet = ' || p_orderlinesmessage || ' - Behandlet = ' || p_orderlinetotal;
    xxcu_log_pkg.log (p_log_level => v_log_level, p_module_name => gpackagename, p_log_text => v_recon_text);
  END;