

DECLARE
                l_msg SYS.XMLTYPE;
  l_adr XMLTYPE;
  r_enqueue_options DBMS_AQ.ENQUEUE_OPTIONS_T;
  r_message_properties DBMS_AQ.MESSAGE_PROPERTIES_T;
  recipients          dbms_aq.aq$_recipient_list_t;
  v_message_handle RAW(16);
  l_xml_str VARCHAR(32767);
  l_xml_str1 CLOB;
   p_clob CLOB;
  ip_xml SYS.XMLTYPE;  
BEGIN
    dbms_lob.createTemporary( l_xml_str1, TRUE );
    dbms_lob.open (l_xml_str1, dbms_lob.lob_readwrite );
   
  BEGIN
    dbms_output.put_line('In XXAD_PS_FROM_RUTE_PRC ');
                                l_xml_str:=  ('<?xml version="1.0" encoding="UTF-8"?>
<ns2:OEOrderImport xmlns:ns2="urn:posten.no/eConnect/ABO/ERP/InvoiceBasis/v1">
  <ns4:Header xmlns:ns4="urn:posten.no/eConnect/Common/Header/v1">
    <ns4:MessageId>T50507_ProcessCustomsInvoiceAndPrint_4b831e4f-589c-4c64-9aaa-23b04b7f1006</ns4:MessageId>
    <ns4:ServiceName>T50507_ProcessCustomsInvoiceAndPrint_PS</ns4:ServiceName>
    <ns4:MessageType>OEOrderImport</ns4:MessageType>
    <ns4:MessageMode>REQUEST</ns4:MessageMode>
    <ns4:FirstProcessedTimestamp>2017-11-08T11:57:34</ns4:FirstProcessedTimestamp>
    <ns4:ProcessedTimestamp>2017-11-08T11:57:34</ns4:ProcessedTimestamp>
    <ns4:SourceSystemTimestamp>2017-11-08T11:57:34</ns4:SourceSystemTimestamp>
    <ns4:SourceCompany>Posten</ns4:SourceCompany>
    <ns4:SourceSystem>NO002_BUTTERFLY</ns4:SourceSystem>
    <ns4:SourceSystemUser>eConnect</ns4:SourceSystemUser>
    <ns4:SourceSystemRef/>
    <ns4:OperationName>Enqueue</ns4:OperationName>
    <ns4:IntergationURI>T90003_EnqueueXMLOeBS_ERP_AQ/ProxyServices/T90003_EnqueueXMLOeBS_ERP_AQ_PS</ns4:IntergationURI>
    <ns4:ResubmissionPoint>PROXY</ns4:ResubmissionPoint>
  </ns4:Header>
  <ns3:OperatingUnit xmlns:ns3="urn:posten.no/eConnect/Common/ComplexTypes/v1">
    <ns3:UnitName>Posten Norge AS</ns3:UnitName>
    <ns3:UnitNumber>000002</ns3:UnitNumber>
    <ns3:OrganizationNumber/>
    <ns3:ExternalReference/>
  </ns3:OperatingUnit>
  <ns2:Order>
    <ns2:Batch>
      <ns2:BatchID>T50507_ProcessCustomsInvoice2AndPrint_221</ns2:BatchID>
      <ns2:BatchNoTotal>1</ns2:BatchNoTotal>
      <ns2:BatchDate>2018-02-23T11:57:34</ns2:BatchDate>
      <ns2:MessageSequenceNo>1</ns2:MessageSequenceNo>
      <ns2:OrderLineTotal>1</ns2:OrderLineTotal>
      <ns2:MessageDetailCount>1</ns2:MessageDetailCount>
      <ns2:MessageDetailOrderCount>1</ns2:MessageDetailOrderCount>
      <ns2:NumberOfMessages>1</ns2:NumberOfMessages>
      <ns6:OrderHeader xmlns:ns6="urn:posten.no/eConnect/EBO/InvoiceBasis/v1">
        <ns7:CustomerNumber xmlns:ns7="urn:posten.no/eConnect/Common/BaseTypes/v1">20000061059</ns7:CustomerNumber>
        <ns6:POReference/>
        <ns6:SalesAgreementNumber/>
        <ns6:OrderType>Regular</ns6:OrderType>
        <ns6:PrintedOrderNumber>123444566</ns6:PrintedOrderNumber>
        <ns7:OrderReference xmlns:ns7="urn:posten.no/eConnect/Common/BaseTypes/v1">1-23732753-0844032217</ns7:OrderReference>
        <ns6:ReturnOrderReference/>
        <ns6:OrderedDate>2018-02-23T00:00:00</ns6:OrderedDate>
        <ns6:TransactionalCurrencyCode>NOK</ns6:TransactionalCurrencyCode>
        <ns6:ChartequeNumber/>
        <ns6:PaymentTypeCode/>
        <ns6:PricingDate>2018-02-23T00:00:00</ns6:PricingDate>
        <ns6:PaymentProviderTransID/>
        <ns6:ExcludeFromDunning/>
        <ns6:PrePaymentFlag>Y</ns6:PrePaymentFlag>
        <ns6:InvoiceAttachmentFile>
          <ns6:FileReference>20170308083528_!00000000000118_1703080161.pdf</ns6:FileReference>
          <ns6:DocumentName>20170308083528_!00000000000118_1703080161.pdf</ns6:DocumentName>
          <ns6:URL/>
          <ns6:MIMEType/>
        </ns6:InvoiceAttachmentFile>
        <ns6:InvoiceAttachmentFile>
          <ns6:FileReference>20170308083521_!00000000000118_170308070659AOA0029___529.pdf</ns6:FileReference>
          <ns6:DocumentName>20170308083521_!00000000000118_170308070659AOA0029___529.pdf</ns6:DocumentName>
          <ns6:URL/>
          <ns6:MIMEType/>
        </ns6:InvoiceAttachmentFile>
        <ns6:InvoiceAttachmentFile>
          <ns6:FileReference>20170308083521_!00000000000118_170308070706AOA0029___530.pdf</ns6:FileReference>
          <ns6:DocumentName>20170308083521_!00000000000118_170308070706AOA0029___530.pdf</ns6:DocumentName>
          <ns6:URL/>
          <ns6:MIMEType/>
        </ns6:InvoiceAttachmentFile>
        <ns6:MessageToCustomer/>
        <ns6:ReservedAmount/>
        <ns6:InvoiceText/>
        <ns6:AgreementName/>
        <ns6:ProjectReference/>
        <ns6:PrePaymentFlag/>
        <ns6:SettlementFlag/>
        <ns6:PaymentId/>
        <ns6:SenderName>STEINAR FJELDVANG</ns6:SenderName>
        <ns6:CustomsID>0175402007004265</ns6:CustomsID>
        <ns6:MasterConsignmentId/>
        <ns6:ConsignmentNumber/>
        <ns6:ConsignmentItemNumber>KV000046807NO</ns6:ConsignmentItemNumber>
        <ns6:PrintCriteria>
          <ns6:InvoiceCustomerGroup>P1</ns6:InvoiceCustomerGroup>
          <ns6:GoodsTotalValue>13002</ns6:GoodsTotalValue>
          <ns6:ShipmentType>EXP</ns6:ShipmentType>
          <ns6:TotalNumberofItems>1</ns6:TotalNumberofItems>
          <ns6:InvoiceSettlement>D</ns6:InvoiceSettlement>
          <ns6:CommodityClassification>0336</ns6:CommodityClassification>
          <ns6:CustomsClearanceStatusCode>TK</ns6:CustomsClearanceStatusCode>
          <ns6:CustomsClearanceDate>2017-03-08</ns6:CustomsClearanceDate>
          <ns6:InvoiceSplit>0</ns6:InvoiceSplit>
          <ns6:InvoiceMail/>
          <ns6:CustomerEnclosure/>
          <ns6:AdrLevDeviation>1</ns6:AdrLevDeviation>
          <ns6:ReceiptReference>1</ns6:ReceiptReference>
          <ns6:InvoiceType>1</ns6:InvoiceType>
          <ns6:language>NO</ns6:language>
        </ns6:PrintCriteria>
        <ns6:OrderLine>
          <ns6:ItemNumber>12617</ns6:ItemNumber>
          <ns6:OrderedQuantity>45</ns6:OrderedQuantity>
          <ns6:QuantityUOM>34</ns6:QuantityUOM>
          <ns6:UnitListPrice>1.2</ns6:UnitListPrice>
          <ns6:UnitNetPrice>1.2</ns6:UnitNetPrice>
          <ns6:Tax>2</ns6:Tax>
          <ns6:TaxValue/>
          <ns7:OrderLineReference xmlns:ns7="urn:posten.no/eConnect/Common/BaseTypes/v1">1-237272232353-080317-15554</ns7:OrderLineReference>
          <ns6:ReturnOrderLineReference/>
          <ns6:AssignmentNumbers>12</ns6:AssignmentNumbers>
          <ns6:ReturnReasonCode/>
          <ns6:DiscountBreakupInfo/>
          <ns6:PostalCodeFrom/>
          <ns6:PostalCodeTo/>
          <ns6:CountryCodeFrom/>
          <ns6:CountryCodeTo/>
          <ns6:AccountingUnit/>
          <ns6:PriceAdjustmentPerUnit>0.00</ns6:PriceAdjustmentPerUnit>
          <ns6:TaxCode>3</ns6:TaxCode>
          <ns6:ShipTo/>
          
          <ns6:InvoiceSpecification/>
        </ns6:OrderLine>
      </ns6:OrderHeader>
    </ns2:Batch>
  </ns2:Order>
</ns2:OEOrderImport>
');   
                                
 dbms_lob.Append( l_xml_str1, l_xml_str );                        
                l_xml_str := NULL;
                p_clob := to_clob(l_xml_str1);
                BEGIN
      ip_xml :=xmltype(p_clob);
    EXCEPTION
    WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'SQLERRM'||SQLERRM);
    END;
                                
      --recipients(1) := sys.aq$_agent('SUBS_PNS', NULL, NULL);
      r_message_properties.correlation :='OEOrderImport';
      DBMS_AQ.ENQUEUE( 
                                queue_name                                                                    => 'XXCU.XXCU_INT_INBOUND_MSG',
                                enqueue_options                                           => r_enqueue_options, 
                                message_properties                                      => r_message_properties,
                                payload                                                                                => ip_xml, 
                                msgid                                                                                    => v_message_handle );
      COMMIT;
  EXCEPTION
  WHEN OTHERS THEN
    dbms_output.put_line('Error in Generating XML  '||SQLERRM);
    FND_FILE.PUT_LINE(fnd_file.LOG,'Error in Generating XML  '||SQLERRM);
  END;
END ;
----------------------------------------------------------------------------



