PROCEDURE update_batch_status(
      p_batchid IN VARCHAR2,
      p_status  IN VARCHAR2)
  IS
    pragma autonomous_transaction;
  BEGIN
    UPDATE xxcu.xxcu_ont_int_order_batch
    SET status         = p_status,
      last_update_date = to_date(sysdate,'DD-MON-YY HH24:MI:SS')
    WHERE batchid      = p_batchid;
    COMMIT;
  END;