PROCEDURE insert_invoice_spec_p
(
      p_order_head_rec        IN xxcu_ont_create_order_parser.orderhead_rec,
      p_order_line_rec        IN xxcu_ont_create_order_parser.orderline_rec,
      p_inv_spec_rec          IN xxcu_ont_create_order_parser.inv_spec_rec,
      p_orig_sys_document_ref IN VARCHAR2,
      p_line_number           IN VARCHAR2,
      p_order_number          IN NUMBER,
      p_status_code           IN OUT NUMBER,
      p_error_message 		  OUT VARCHAR2
)
  AS
  
  --  ln_order_head            NUMBER;
    --ln_order_head_cnt        NUMBER;
   -- ln_order_num             NUMBER;
    lv_orig_sys_document_ref VARCHAR2(100);
    lv_line_number           VARCHAR2(80);
   -- ln_cnt                   NUMBER :=0;
   -- ln_cnt_line              NUMBER :=0;
   -- ln_cnt_url               NUMBER :=0;
 --  ln_cnt_y                 NUMBER :=0;
    ln_spec_order_number     NUMBER;
  
  
  BEGIN
    lv_orig_sys_document_ref:= p_orig_sys_document_ref;
    lv_line_number          := p_line_number;
    ln_spec_order_number    := p_order_number;
    
    IF(p_order_line_rec.speclines.count>0) THEN
      INSERT
      INTO xxcu_intf_spec_lines VALUES
        (
          
          lv_line_number,
          p_inv_spec_rec.order_line_number,
          p_inv_spec_rec.order_line_text,
          p_inv_spec_rec.order_line_no_of_packages,
          p_inv_spec_rec.order_line_pallet,
          p_inv_spec_rec.order_line_pp_price,
          p_inv_spec_rec.order_line_net_weight,
          sysdate,
          g_user_id,
          g_user_id,
          sysdate,
          p_inv_spec_rec.order_line_nop_uom ,
          p_inv_spec_rec.order_line_net_weight_uom ,
          p_inv_spec_rec.order_line_length,
          p_inv_spec_rec.order_line_width ,
          p_inv_spec_rec.order_line_height ,
          p_inv_spec_rec.order_line_dim_uom,
          p_inv_spec_rec.order_line_date,
          p_inv_spec_rec.order_line_per_time_unit,
          p_inv_spec_rec.order_line_unit_price,
          p_inv_spec_rec.order_line_unit_amount,
          p_inv_spec_rec.order_line_cargo_type,
          p_inv_spec_rec.order_line_freight_calc_wt,
          p_inv_spec_rec.order_line_frt_calc_wt_uom,
          p_inv_spec_rec.order_line_volume ,
          p_inv_spec_rec.order_line_volume_uom,
          p_inv_spec_rec.order_line_load_meter,
          p_inv_spec_rec.order_line_cargo_label,
          NVL(p_order_head_rec.printed_order_number,ln_spec_order_number),          
          p_inv_spec_rec.order_line_gross_weight,
          p_inv_spec_rec.order_line_gross_weight_uom,          
          lv_orig_sys_document_ref,
          p_order_head_rec.order_source,
          g_intf_inv_spec_seq 
        );
    END IF;
    xxcu_common_log_rt.msglog ('INFO', 'Inserted in Spec Lines', 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
   
  EXCEPTION
  WHEN OTHERS THEN
    xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled errors in the xxcu_invoice_spec_p > ::Contact your system administrator:: ' || sqlerrm );
    p_status_code  := 2;
    p_error_message:='Error in invoice spec procedure'||sqlerrm||dbms_utility.format_error_backtrace;
  END;