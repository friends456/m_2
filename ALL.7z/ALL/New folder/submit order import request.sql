PROCEDURE submit_order_import_request(
      p_batch_id     IN VARCHAR2,
      p_orig_sys_ref IN VARCHAR2,
      p_org_id       IN NUMBER)
  AS
    l_req_id            NUMBER;
   -- l_ret_val           BOOLEAN;
  --  l_tid               NUMBER;
   -- x_phase             VARCHAR2 (100);
    --x_status            VARCHAR2 (100);
    ln_resp_id          NUMBER;
    ln_app_id           NUMBER;
   -- x_dev_phase         VARCHAR2 (100);
  --  x_dev_status        VARCHAR2 (100);
   -- x_message           VARCHAR2 (2000);
   -- v_starttid          VARCHAR2 (2000) := to_date(sysdate,'DD-MON-YY HH24:MI:SS');
    ln_org_id           NUMBER;
    lv_orig_sys_ref     VARCHAR2(240);
  --  lv_phase            VARCHAR2(100):='X';
    --lv_status_code_conc VARCHAR2(100):='X';
  BEGIN
    ln_org_id      :=p_org_id;
    lv_orig_sys_ref:=p_orig_sys_ref;
    dbms_output.put_line(ln_org_id);
	
	
    xxcu_common_log_rt.msglog ('INFO', 'ln_org_id order import'||ln_org_id|| ' ' || lv_orig_sys_ref, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
    mo_global.init('ONT');
    mo_global.set_policy_context('S',ln_org_id);
	
    SELECT user_id INTO g_user_id FROM fnd_user WHERE user_name='OPERATIONS';
    SELECT responsibility_id,
      application_id
    INTO ln_resp_id,
      ln_app_id
    FROM fnd_responsibility_vl
    WHERE responsibility_name = 'PB OM Super User';
	
    fnd_global.apps_initialize(g_user_id, ln_resp_id, ln_app_id);
	
    
    --initialize_applications_OIMP;
    l_req_id := fnd_request.submit_request ( application => 'ONT' , program => 'OEOIMP' , argument1 => ln_org_id--FND_PROFILE.VALUE('ORG_ID')
    ,argument2 => g_order_source_id  -- Order Source
    ,argument3 => lv_orig_sys_ref     -- Original System Document Ref
    ,argument4 => NULL  -- Operation Code
    ,argument5 => 'N'  -- Validate Only?
    ,argument6 => '1'  -- Debug Level
    ,argument7 => 4     --g_num_conc_instances                                                                                                                           -- Number of Order Import instances
    ,argument8 => NULL  -- Sold To Org Id
    ,argument9 => NULL   -- Sold To Org
    ,argument10 => NULL  -- Change Sequence
    ,argument11 => 'Y'  -- Enable Single Line Queue for Instances
    ,argument12 => 'N' -- Trim Trailing Blanks
    ,argument13 => 'Y' -- Process Orders With No Org Specified
    ,argument14 => NULL --ln_org_id  --FND_PROFILE.VALUE('ORG_ID')                                                                                                                   -- Default Operating Unit
    ,argument15 => 'Y'  -- Validate Descriptive Flexfields?
    );
    COMMIT;
    xxcu_log_pkg.log (p_log_level => fnd_log.level_statement, p_module_name => gpackagename, p_log_text => 'To start the background process for order import. ' || l_req_id );
	
    xxcu_common_log_rt.msglog ('INFO', 'inside order import'||l_req_id, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
	
    dbms_output.put_line('l_req_id'|| l_req_id);
    
    IF l_req_id = 0 THEN
      xxcu_log_pkg.log (p_log_level => fnd_log.level_procedure, p_module_name => gpackagename, p_log_text => 'Creation of orders from the background application errors' );
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    xxcu_log_pkg.log (p_log_level => fnd_log.level_statement, p_module_name => gpackagename, p_log_text => 'Error starting background process for order import ' );
  END;