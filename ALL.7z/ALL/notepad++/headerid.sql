i/p-customer_number,order_reference_number,org_id)
o/p-headerid, version no.

FUNCTION getheader_id(
      p_customer_no  IN VARCHAR2,
      p_order_ref_no IN VARCHAR2,
      p_org_id       IN NUMBER, --added org_id defect 2848
      p_version_number OUT NUMBER )
    RETURN NUMBER
  IS
    v_header_id NUMBER;
  BEGIN
    --initialize_applications;
    BEGIN
      
	  SELECT header_id ,
        version_number
      INTO v_header_id,
        p_version_number
      FROM oe_order_headers ----empty
      WHERE
        /*TRUNC (ordered_date) = TRUNC (p_dato)
        AND*/
        sold_to_org_id = getcustomer_id (p_customer_no)
        -- AND created_by             = g_user_id
        -- AND booked_flag            = 'N'
      AND orig_sys_document_ref =p_order_ref_no
        ---start 07.04.2016 not needed as it will be unique everytime
        -- AND ROWNUM                = 1
      AND org_id = p_org_id ----added org_id defect 2848
      ORDER BY header_id DESC;
    EXCEPTION
    WHEN OTHERS THEN
      v_header_id := NULL;
    END;
    RETURN v_header_id;
  END;