I/P-CUSTOMER_ID,SITE_USE_CODE,ORG_ID
O/P-SITE USE ID

FUNCTION getsiteuseid(
      p_customer_id   IN NUMBER,
      p_site_use_code IN VARCHAR2,
      p_org_id        IN NUMBER)
	  
    RETURN NUMBER
  AS
    v_site_use_id NUMBER;
	
  BEGIN
    
	BEGIN
      SELECT site_use_id ----992642----for BILL-TO Code
      INTO v_site_use_id
      FROM hz_cust_acct_sites_all address,
        hz_cust_site_uses_all siteuse
      WHERE address.cust_acct_site_id = siteuse.cust_acct_site_id
      AND address.cust_account_id     = p_customer_id
      AND site_use_code               = p_site_use_code----like BILL-TO, SHIP-TO
      AND siteuse.org_id              = p_org_id---141
      AND address.status              = 'A'
      AND primary_flag                = 'Y'
      AND siteuse.status              = 'A';
      --start 07.04.2016
      --AND ROWNUM                      = 1;
    EXCEPTION
    WHEN no_data_found THEN
      v_site_use_id := NULL;
    END;
	
    RETURN v_site_use_id;
  END;