 BEGIN
             
			 BEGIN
                SELECT COUNT(1)
                INTO l_order_count
                FROM oe_order_headers_all
                WHERE orig_sys_document_ref = p_batch_order.v_order_head (hi).order_reference
                AND org_id                  = p_batch_order.v_order_head (hi).org_id
                AND order_source_id         = g_order_source_id;
              EXCEPTION
              WHEN OTHERS THEN
                l_order_count:=2;
              END;
             
			 IF l_order_count > 0 AND upper(p_batch_order.v_order_head (hi).order_type) = 'REGULAR' THEN
                
				UPDATE oe_lines_iface_all
                SET error_flag         ='Y'
                WHERE orig_sys_line_ref=v_upd_orig_sys_line_ref;
                
				UPDATE oe_price_adjs_iface_all
                SET error_flag           ='Y'
                WHERE orig_sys_line_ref  =v_upd_orig_sys_line_ref
                AND orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;-- v_orig_sys_document_ref , --changed for incident E2-IM013472372
                COMMIT;
                
                SELECT oe_msg_id_s.nextval
                INTO l_transaction_id
                FROM dual;
                
				
				INSERT
                INTO oe_processing_msgs
                  (
                    transaction_id ,
                    request_id,
                    entity_code ,
                    entity_ref ,
                    entity_id ,
                    header_id ,
                    line_id ,
                    order_source_id ,
                    original_sys_document_ref ,
                    original_sys_document_line_ref ,
                    orig_sys_shipment_ref ,
                    change_sequence ,
                    source_document_type_id ,
                    source_document_id ,
                    source_document_line_id ,
                    attribute_code ,
                    creation_date ,
                    created_by ,
                    last_update_date ,
                    last_updated_by ,
                    last_update_login ,
                    program_application_id ,
                    program_id ,
                    program_update_date ,
                    process_activity ,
                    notification_flag ,
                    type ,
                    message_source_code ,
                    message_status_code ,
                    org_id
                  )
                  VALUES
                  (
                    l_transaction_id ,
                    NULL
                    --     ,l_msg_data
                    ,
                    'LINE' ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    g_order_source_id ,
                    p_batch_order.v_order_head (hi).order_reference,-- v_orig_sys_document_ref , --changed for incident E2-IM013472372
                    p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    sysdate ,
                    g_user_id ,
                    sysdate ,
                    g_user_id ,
                    fnd_global.login_id ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    'ERROR' ,
                    'C' ,
                    'OPEN' ,
                    p_batch_order.v_order_head (hi).org_id
                  );
                
				BEGIN
                  INSERT
                  INTO oe_processing_msgs_tl
                    (
                      transaction_id ,
                      language ,
                      source_lang ,
                      message_text ,
                      created_by ,
                      creation_date ,
                      last_updated_by ,
                      last_update_date ,
                      last_update_login
                    )
                  SELECT l_transaction_id ,
                    l.language_code ,
                    'US' ,
                    (SELECT message_text
                    FROM fnd_new_messages
                    WHERE message_name='XXCU_DUPLICATE_ORDER'
                    AND language_code ='US'
                    ) ,
                    g_user_id ,
                    sysdate ,
                    g_user_id ,
                    sysdate ,
                    fnd_global.login_id
                  FROM fnd_languages l
                  WHERE l.installed_flag IN ('I','B')
                  AND language_code       = 'US'
                  AND NOT EXISTS
                    (SELECT NULL
                    FROM oe_processing_msgs_tl t
                    WHERE t.transaction_id = l_transaction_id
                    AND t.language         = l.language_code
                    );
                 
				 INSERT
                  INTO oe_processing_msgs_tl
                    (
                      transaction_id ,
                      language ,
                      source_lang ,
                      message_text ,
                      created_by ,
                      creation_date ,
                      last_updated_by ,
                      last_update_date ,
                      last_update_login
                    )
                  SELECT l_transaction_id ,
                    l.language_code ,
                    'N' ,
                    (SELECT message_text
                    FROM fnd_new_messages
                    WHERE message_name='XXCU_DUPLICATE_ORDER'
                    AND language_code ='N'
                    ) ,
                    g_user_id ,
                    sysdate ,
                    g_user_id ,
                    sysdate ,
                    fnd_global.login_id
                  FROM fnd_languages l
                  WHERE l.installed_flag IN ('I','B')
                  AND language_code       = 'N'
                  AND NOT EXISTS
                    (SELECT NULL
                    FROM oe_processing_msgs_tl t
                    WHERE t.transaction_id = l_transaction_id
                    AND t.language         = l.language_code
                    );
                END;
                COMMIT;
              END IF;
           
		   EXCEPTION
            WHEN OTHERS THEN
              p_status_code := g_code_error;
              xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Duplicate Order received' || g_program_loc || '> ::Contact your system administrator:: ' || v_batch_seq_no || sqlerrm );
              dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
            END;