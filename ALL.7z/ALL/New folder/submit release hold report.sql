PROCEDURE submit_release_hold_report(
      p_batch_id VARCHAR2,
      p_org_id IN NUMBER)
  AS
    l_req_id     NUMBER;
    l_ret_val    BOOLEAN;
   -- l_tid        NUMBER;
    x_phase      VARCHAR2 (100);
    x_status     VARCHAR2 (100);
    x_dev_phase  VARCHAR2 (100);
    x_dev_status VARCHAR2 (100);
    x_message    VARCHAR2 (2000);
   -- v_starttid   VARCHAR2 (2000) := to_date(sysdate,'DD-MON-YY HH24:MI:SS');
    ln_org_id    NUMBER;
    ln_batch_id  VARCHAR2(240);
  
  BEGIN
    ln_org_id  :=p_org_id;
    ln_batch_id:=p_batch_id;
	
	
    --initialize_applications_OIMP;
    l_req_id := fnd_request.submit_request ( application => 'XXCU' ,program => 'XXCU_ONT_RELEASE_HOLD_P' ,argument1 => ln_batch_id,argument2 => ln_org_id);
    COMMIT;
	
    IF l_req_id  > 0 THEN
      l_ret_val := fnd_concurrent.wait_for_request (request_id => l_req_id, interval => 5, phase => x_phase, status => x_status, dev_phase => x_dev_phase, dev_status => x_dev_status, MESSAGE => x_message );
      xxcu_log_pkg.log (p_log_level => fnd_log.level_procedure, p_module_name => gpackagename, p_log_text => 'Releasing Order Holds and Closing Case folders ' || ' request_id: ' || l_req_id || ' - ' || x_phase || ' - ' || x_status || ' - ' || x_dev_phase || ' - ' || x_dev_status || ' - ' || x_message );
    ELSE
      xxcu_log_pkg.log (p_log_level => fnd_log.level_procedure, p_module_name => gpackagename, p_log_text => 'Releasing Order Holds failed' );
      --dbms_output.put_line()
    END IF;
	
	
  EXCEPTION
  WHEN OTHERS THEN
    xxcu_log_pkg.log (p_log_level => fnd_log.level_statement, p_module_name => gpackagename, p_log_text => 'Error starting Release holds program ' );
  END;