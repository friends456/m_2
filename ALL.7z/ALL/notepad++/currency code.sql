i/p----customer_id,org_id
o/p----ATTRIBUTE10 ie.currency code  hz_parties,hz_cust_accounts, hz_cust_acct_sites_all---attribute10 is always null


FUNCTION get_currencycode(
      p_cust_id IN NUMBER,
      p_org_id  IN NUMBER)
    RETURN VARCHAR2
  IS
    lv_curr_code VARCHAR2(100);
  BEGIN
    
	BEGIN
      SELECT hca.attribute10 --NULL
      INTO lv_curr_code
      FROM hz_cust_acct_sites_all hca
      WHERE hca.cust_account_id=p_cust_id--166170
      AND hca.org_id           =p_org_id---141
      AND hca.status           ='A'  ----Customer Status flag. Receivables lookup code for CODE_STATUS
      AND hca.bill_to_flag     ='P';----Indicates if this is a Bill-To site. Y for a Bill-To site, 
									---P for the primary Bill-To site, and N for a site that is not a Bill-To site.
    EXCEPTION
    WHEN OTHERS THEN
      lv_curr_code:=NULL;
    END;
    
	IF(lv_curr_code IS NULL) THEN
      BEGIN
        SELECT hca.attribute10 --NULL 
        INTO lv_curr_code
        FROM hz_cust_accounts hca
        WHERE hca.cust_account_id=p_cust_id
        AND hca.status           ='A';---------Customer status flag. Lookup code for CODE_STATUS	
      EXCEPTION
      WHEN OTHERS THEN
        lv_curr_code:=NULL;
      END;
    END IF;
	
	
    IF(lv_curr_code IS NULL) THEN
      BEGIN
        SELECT hp.attribute10 --NULL
        INTO lv_curr_code
        FROM hz_cust_accounts hca,
          hz_parties hp
        WHERE hca.cust_account_id=p_cust_id
        AND hp.party_id          =hca.party_id
        AND hca.status           ='A';
      EXCEPTION
      WHEN OTHERS THEN
        lv_curr_code:=NULL;
      END;
    END IF;
	
	
    RETURN lv_curr_code;
  END;