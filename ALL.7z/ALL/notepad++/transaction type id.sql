i/p---order source,order type,org id
o/p---transaction type id
exception----status code,error message

FUNCTION get_transaction_type_id(
      p_order_source IN VARCHAR2,
      p_order_type   IN VARCHAR2,
      p_org_id       IN NUMBER,
      x_status_code OUT NUMBER,
      x_error_message OUT VARCHAR2 )
    RETURN NUMBER
  IS
    lv_log_label    VARCHAR2(200);
    lv_message      VARCHAR2(2000);
    v_order_type_id NUMBER;
    lv_order_type   VARCHAR2(200);
    lv_order_source VARCHAR2(200);
  BEGIN
    lv_order_source        :=p_order_source;
    lv_order_type          :=p_order_type;
   

   IF(upper(lv_order_type) ='REGULAR') THEN
      /*
      start Wave 2 modification
      SELECT ott.transaction_type_id
      INTO v_order_type_id
      FROM
      --oe_order_headers_all ooha,
      oe_transaction_types_all ott,
      RA_CUST_TRX_TYPES_ALL rctt
      WHERE 1                       =1 --and ott.transaction_type_id=ooha.order_type_id
      AND ott.org_id                =p_org_id
      AND ott.transaction_type_code ='ORDER'
      /* AND upper(rctt.name) LIKE '%'
      ||upper(p_order_head_rec.order_source)
      ||'%'----Added to resolve Defect # 140*/
      ---commented for CR 1202
      /*  AND upper(ott.attribute1)= upper(p_order_source) ---added for CR1202
      --  AND ott.transaction_type_id=1161--------need to remove just for testing used
      AND ott.order_category_code    ='ORDER'
      AND (ott.end_date_active      IS NULL
      OR TRUNC(ott.end_date_active) >=TRUNC(SYSDATE))
      AND RCTT.CUST_TRX_TYPE_ID      =OTT.CUST_TRX_TYPE_ID;
      end wave 2 modification*/
      --Wave 2 modification
      SELECT ott.transaction_type_id
      INTO v_order_type_id
      FROM applsys.fnd_flex_value_sets ffvs,
        fnd_flex_values_vl ffv,
        oe_transaction_types_tl ott
      WHERE flex_value_set_name      ='XXCU_OM_SOURCE_ORDER_TYPE'
      AND ffvs.flex_value_set_id     =ffv.flex_value_set_id
      AND upper(ffv.flex_value)      =upper(lv_order_source)
      AND (ffv.end_date_active      IS NULL
      AND ott.language               ='US'
      AND upper(ott.name)            =upper(ffv.attribute2)
      OR TRUNC(ffv.end_date_active) >=TRUNC(sysdate));
    
	
	ELSE
      /*
      start Wave 2 modification
      SELECT ott.transaction_type_id
      INTO v_order_type_id
      FROM
      --oe_order_headers_all ooha,
      oe_transaction_types_all ott,
      RA_CUST_TRX_TYPES_ALL rctt
      WHERE 1                      =1 --and ott.transaction_type_id=ooha.order_type_id
      AND ott.org_id               =p_org_id
      AND ott.transaction_type_code='ORDER'
      /*     AND upper(rctt.name) LIKE '%'
      ||upper(p_order_head_rec.order_source)
      ||'%'----Added to resolve Defect # 140*/
      -- commented for CR1202
      /* AND upper(ott.attribute1)      = upper(p_order_source) ---added for CR1202
      AND ott.order_category_code    ='RETURN'
      AND (ott.end_date_active      IS NULL
      OR TRUNC(ott.end_date_active) >=TRUNC(SYSDATE))
      AND RCTT.CUST_TRX_TYPE_ID      =OTT.CUST_TRX_TYPE_ID;
      end wave 2 modification*/
      --Wave 2 Modification
      SELECT ott.transaction_type_id
      INTO v_order_type_id
      FROM applsys.fnd_flex_value_sets ffvs,
        fnd_flex_values_vl ffv,
        oe_transaction_types_tl ott
      WHERE flex_value_set_name      ='XXCU_OM_SOURCE_ORDER_TYPE'
      AND ffvs.flex_value_set_id     =ffv.flex_value_set_id
      AND upper(ffv.flex_value)      =upper(lv_order_source)
      AND (ffv.end_date_active      IS NULL
      AND ott.language               ='US'
      AND upper(ott.name)            =upper(ffv.attribute3)
      OR TRUNC(ffv.end_date_active) >=TRUNC(sysdate));
    END IF;
    
	
	RETURN v_order_type_id;
  
  
  EXCEPTION
  WHEN OTHERS THEN
    lv_log_label := 'Order Type Invalid' ;
    lv_message   := 'Failed to Derive Order Type. Please check Order Type Setup.';
    xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.get_transaction_type_id.' || lv_log_label , lv_message, false);
    x_status_code  := 2;
    x_error_message:=lv_message||sqlerrm||dbms_utility.format_error_backtrace;
    xxcu_common_log_rt.msglog ('ERR', 'Failed to derive transaction type id '||sqlerrm||dbms_utility.format_error_backtrace, 1117, '1', 'get_transaction_type_id', '-1' );
  END;