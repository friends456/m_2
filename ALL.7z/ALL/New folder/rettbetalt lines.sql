PROCEDURE create_rettbetalt_lines
    (
      p_order_head_rec IN xxcu_ont_create_order_parser.orderhead_rec,
      p_order_line_rec IN xxcu_ont_create_order_parser.orderline_rec,
      p_pricing_date   IN DATE,
      p_status_code    IN OUT NUMBER,
      p_error_message OUT VARCHAR2
    )
  AS
    l_return_reason VARCHAR2(2000);
    ln_count NUMBER:=0;
    
	
	CURSOR c_original_line(p_orig_sys_doc_ref VARCHAR2)
    IS
      SELECT *
      FROM oe_order_lines_all
      WHERE orig_sys_document_ref=p_orig_sys_doc_ref;
	  
	  
    CURSOR c_inv_spec_data(p_orig_sys_doc_ref VARCHAR2)
    IS
      SELECT *
      FROM xxcu_interface_specifications
      WHERE orig_sys_document_ref=p_orig_sys_doc_ref;
	  
	  
  BEGIN
    FOR rec_orginal_line IN c_original_line(p_order_head_rec.return_order_reference)
    LOOP
      
	  BEGIN
        SELECT lookup_code
        INTO l_return_reason
        FROM apps.fnd_lookup_values lv
        WHERE lv.language         = userenv('LANG')
        AND upper(lv.lookup_code) = 'RB-'
          || upper(p_order_line_rec.reason_code)
        AND lookup_type ='CREDIT_MEMO_REASON';
		
      EXCEPTION
      WHEN OTHERS THEN
        l_return_reason:='NO REASON';
        dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
      END;
	  
	  
	  
      INSERT
      INTO oe_lines_iface_all
        (
          order_source_id,
          org_id,
          sold_to_org_id,
          line_id,
          orig_sys_document_ref,
          orig_sys_line_ref,         
          order_quantity_uom,
          unit_list_price,
          unit_selling_price,
          tax,
          customer_item_net_price,
          tax_value,
          calculate_price_flag,
          created_by,
          last_updated_by,
          inventory_item_id,
          ordered_quantity,
          context,
          attribute10,
          return_reason_code,
          attribute4,
          attribute5,
          attribute6,
          attribute7,
          operation_code,
          creation_date,
          last_update_date,         
          salesrep_id,
          return_context,
          return_attribute1,
          return_attribute2,
          reference_header_id,
          reference_line_id,
          payment_term_id,
          pricing_date,
          attribute3,
          tax_code,
          return_attribute3,
          return_attribute4 ,
          global_attribute1
        )
        VALUES
        (
          rec_orginal_line.order_source_id,
          rec_orginal_line.org_id,
          rec_orginal_line.sold_to_org_id,
          oe_order_lines_s.nextval,
          p_order_head_rec.order_reference,
          'RB'
          ||g_order_number
          ||oe_order_lines_s.currval,
          rec_orginal_line.order_quantity_uom,
          rec_orginal_line.unit_list_price,
          rec_orginal_line.unit_selling_price,
          rec_orginal_line.tax_code,
          rec_orginal_line.customer_item_net_price,
          rec_orginal_line.tax_value,            
          rec_orginal_line.calculate_price_flag,                                                                                                                                   --l_calcualte_price,
          g_user_id,
          g_user_id,
          rec_orginal_line.inventory_item_id,
          rec_orginal_line.ordered_quantity,
          rec_orginal_line.context,
          rec_orginal_line.attribute10,
          NVL(l_return_reason,rec_orginal_line.return_reason_code),
          rec_orginal_line.attribute4,
          rec_orginal_line.attribute5,
          rec_orginal_line.attribute6,
          rec_orginal_line.attribute7,
          'INSERT',
          sysdate,
          sysdate,          
          rec_orginal_line.salesrep_id,
          'ORDER',
          rec_orginal_line.header_id,
          rec_orginal_line.line_id,
          rec_orginal_line.header_id,
          rec_orginal_line.line_id,
          rec_orginal_line.payment_term_id,
          p_pricing_date,
          rec_orginal_line.attribute3,
          rec_orginal_line.tax_code,
          p_order_head_rec.return_order_reference,
          rec_orginal_line.orig_sys_line_ref,
          g_intf_inv_spec_seq
        );
      COMMIT;
    END LOOP;
	
	
    BEGIN
      SELECT COUNT(*)
      INTO ln_count
      FROM xxcu_interface_specifications
      WHERE orig_sys_document_ref=p_order_head_rec.order_reference;
    EXCEPTION
    WHEN OTHERS THEN
      ln_count:=0;
    END;
	
	
    IF(ln_count=0) THEN
      FOR rec_inv_spec IN c_inv_spec_data(p_order_head_rec.return_order_reference)
      LOOP
        INSERT
        INTO xxcu_interface_specifications VALUES
          (
            'N',
            rec_inv_spec.order_source,
            p_order_head_rec.order_reference,
            'RB'
            ||g_order_number
            ||oe_order_lines_s.currval,
            rec_inv_spec.date_from,
            rec_inv_spec.date_to,
            rec_inv_spec.description,
            rec_inv_spec.order_date,
            rec_inv_spec.uom,
            rec_inv_spec.waybill_number,
            rec_inv_spec.sender_name,
            rec_inv_spec.receiver_name,
            rec_inv_spec.ship_from_city,
            rec_inv_spec.ship_to_city,
            rec_inv_spec.number_of_packages,
            rec_inv_spec.pallet,
            rec_inv_spec.volume,
            rec_inv_spec.weight,
            rec_inv_spec.freight_calc_weight,
            rec_inv_spec.responsible_person,
            rec_inv_spec.pp_price,
            rec_inv_spec.cargo_type,
            rec_inv_spec.creation_date,
            rec_inv_spec.created_by,
            rec_inv_spec.last_updated_by,
            rec_inv_spec.last_updated_date,
            rec_inv_spec.container_reference,
            rec_inv_spec.pick_up_point,
            rec_inv_spec.awb,
            rec_inv_spec.mawb,
            rec_inv_spec.hawb,
            rec_inv_spec.vessel,
            rec_inv_spec.incoterm,
            rec_inv_spec.sender_reference,
            rec_inv_spec.receiver_reference,
            rec_inv_spec.agent_reference,
            rec_inv_spec.load_carrier,
            rec_inv_spec.transport_method,
            rec_inv_spec.delivery_point,
            rec_inv_spec.our_reference,
            rec_inv_spec.cargo_id_number,
            rec_inv_spec.position_number,
            rec_inv_spec.load_meter,
            rec_inv_spec.cargo_label,
            rec_inv_spec.charteque_number,
            rec_inv_spec.delivered_time,
            rec_inv_spec.received_time,
            rec_inv_spec.ship_from_address1,
            rec_inv_spec.ship_from_address2,
            rec_inv_spec.ship_from_address3,
            rec_inv_spec.ship_from_country,
            rec_inv_spec.ship_from_postal_code,
            rec_inv_spec.ship_to_address1,
            rec_inv_spec.ship_to_address2,
            rec_inv_spec.ship_to_address3,
            rec_inv_spec.ship_to_postal_code,
            rec_inv_spec.ship_to_country,
            rec_inv_spec.volume_uom,
            rec_inv_spec.weight_uom,
            rec_inv_spec.freight_calc_weight_uom,
            rec_inv_spec.order_number,
            rec_inv_spec.currency,
            rec_inv_spec.currency_amount,
            rec_inv_spec.exchange_rate,
            rec_inv_spec.exchange_date,
            rec_inv_spec.pick_up_address1,
            rec_inv_spec.pick_up_address2,
            rec_inv_spec.pick_up_address3,
            rec_inv_spec.pick_up_postal_code,
            rec_inv_spec.pick_up_city,
            rec_inv_spec.pick_up_country,
            rec_inv_spec.delivery_address1,
            rec_inv_spec.delivery_address2,
            rec_inv_spec.delivery_address3,
            rec_inv_spec.delivery_postal_code,
            rec_inv_spec.delivery_city,
            rec_inv_spec.delivery_country,
            rec_inv_spec.consignment_type_code,
            rec_inv_spec.consignment_type_text,
            rec_inv_spec.transport_method_text,
            rec_inv_spec.incoterm_text,
            rec_inv_spec.ship_to_fiscal_code,
            rec_inv_spec.ship_from_fiscal_code,
            rec_inv_spec.note,
            rec_inv_spec.loading_point,
            rec_inv_spec.unloading_point,
            rec_inv_spec.spec_intf_ref,
            rec_inv_spec.ordered_by,
            rec_inv_spec.ordered_by_address1,
            rec_inv_spec.ordered_by_address2,
            rec_inv_spec.ordered_by_address3,
            rec_inv_spec.ordered_by_postal_code,
            rec_inv_spec.ordered_by_city,
            rec_inv_spec.ordered_by_country,
            rec_inv_spec.ordered_by_contact_person,
            rec_inv_spec.ordered_by_contact_email,
            rec_inv_spec.bill_to_contact_person,
            rec_inv_spec.bill_to_contact_email,
            rec_inv_spec.deviation,
            rec_inv_spec.franking_type,
            rec_inv_spec.price_table,
            rec_inv_spec.speed,
            rec_inv_spec.destination,
            rec_inv_spec.weight_spec,
            rec_inv_spec.unit_price_incl_vat,
            rec_inv_spec.total_incl_vat,
            rec_inv_spec.paid_amount,
            rec_inv_spec.agreement_sum,
            rec_inv_spec.shipment_id_number,
            rec_inv_spec.unit_price_excl_vat,
            rec_inv_spec.freight_payer 
          );
        COMMIT;
      END LOOP;
	  
    END IF;
	
	
	
  EXCEPTION
  WHEN OTHERS THEN
    p_status_code := 2;
    xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error while updating error code for invalid return order' || g_program_loc || '> ::Contact your system administrator:: ' || sqlerrm );
    p_error_message:=sqlerrm||dbms_utility.format_error_backtrace;
  END;