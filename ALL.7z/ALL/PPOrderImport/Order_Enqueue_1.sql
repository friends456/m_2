
DECLARE
                l_msg SYS.XMLTYPE;
  l_adr XMLTYPE;
  r_enqueue_options DBMS_AQ.ENQUEUE_OPTIONS_T;
  r_message_properties DBMS_AQ.MESSAGE_PROPERTIES_T;
  recipients          dbms_aq.aq$_recipient_list_t;
  v_message_handle RAW(16);
  l_xml_str VARCHAR(32767);
  l_xml_str1 CLOB;
   p_clob CLOB;
  ip_xml SYS.XMLTYPE;  
BEGIN
    dbms_lob.createTemporary( l_xml_str1, TRUE );
    dbms_lob.open (l_xml_str1, dbms_lob.lob_readwrite );
   
  BEGIN
    dbms_output.put_line('In XXAD_PS_FROM_RUTE_PRC ');
                                l_xml_str:=  ('<?xml version="1.0" encoding="UTF-8"?>
<ns1:PPOrderImport xmlns:ns1="urn:posten.no/eConnect/ABO/ERP/InvoiceBasis/v1">
  <ns1:Header xmlns:ns1="urn:posten.no/eConnect/Common/Header/v1">
    <ns1:MessageId>021a53cb-de2a-4be4-bd78-30982223233bf19</ns1:MessageId>
    <ns1:ServiceName>T50549_SendInvoiceBasisAmphoraToERP</ns1:ServiceName>
    <ns1:MessageType>PPOrderImport</ns1:MessageType>
    <ns1:MessageMode>REQUEST</ns1:MessageMode>
    <ns1:FirstProcessedTimestamp>2017-10-10T09:33:10</ns1:FirstProcessedTimestamp>
    <ns1:ProcessedTimestamp>2017-10-10T09:33:13</ns1:ProcessedTimestamp>
    <ns1:SourceSystemTimestamp>2017-10-10T09:33:10</ns1:SourceSystemTimestamp>
    <ns1:TargetSystemTimestamp/>
    <ns1:SecurityToken/>
    <ns1:SourceCompany>POS</ns1:SourceCompany>
    <ns1:SourceSystem>PN Varer Ordrehode</ns1:SourceSystem>
    <ns1:SourceSystemUser/>
    <ns1:SourceSystemRef/>
    <ns1:OperationName>Enqueue</ns1:OperationName>
    <ns1:IntergationURI>T90003_EnqueueXMLOeBS_ERP_AQ/ProxyServices/T90003_EnqueueXMLOeBS_ERP_AQ_PS</ns1:IntergationURI>
    <ns1:ResubmissionPoint>PROXY</ns1:ResubmissionPoint>
  </ns1:Header>
  <ns3:OperatingUnit xmlns:ns3="urn:posten.no/eConnect/Common/ComplexTypes/v1">
    <ns3:UnitName>Posten Norge AS</ns3:UnitName>
    <ns3:UnitNumber/>
    <ns3:OrganizationNumber/>
    <ns3:ExternalReference/>
  </ns3:OperatingUnit>
  <ns1:Order>
    <ns1:Batch>
      <ns1:BatchID>3333522242</ns1:BatchID>
      <ns1:BatchNoTotal>1</ns1:BatchNoTotal>
      <ns1:BatchDate>2018-02-22T00:00:00</ns1:BatchDate>
      <ns1:MessageSequenceNo>1</ns1:MessageSequenceNo>
      <ns1:OrderLineTotal>1</ns1:OrderLineTotal>
      <ns1:MessageDetailCount>1</ns1:MessageDetailCount>
      <ns1:MessageDetailOrderCount>1</ns1:MessageDetailOrderCount>
      <ns1:NumberOfMessages>1</ns1:NumberOfMessages>
      <ns4:OrderHeader xmlns:ns4="urn:posten.no/eConnect/EBO/InvoiceBasis/v1">
        <ns5:CustomerNumber xmlns:ns5="urn:posten.no/eConnect/Common/BaseTypes/v1">20000061133</ns5:CustomerNumber>
        <ns4:POReference/>
        <ns4:SalesAgreementNumber/>
        <ns4:OrderType>Regular</ns4:OrderType>
        <ns4:PrintedOrderNumber>377444245</ns4:PrintedOrderNumber>
        <ns5:OrderReference xmlns:ns5="urn:posten.no/eConnect/Common/BaseTypes/v1">4454442442</ns5:OrderReference>
        <ns4:ReturnOrderReference/>
        <ns4:OrderedDate>2018-02-22T09:32:57</ns4:OrderedDate>
        <ns4:TransactionalCurrencyCode>NOK</ns4:TransactionalCurrencyCode>
        <ns4:ChartequeNumber>MEG32A 1860</ns4:ChartequeNumber>
        <ns4:PaymentTypeCode/>
        <ns4:PricingDate>2018-02-22T09:32:57</ns4:PricingDate>
        <ns4:PaymentProviderTransID/>
        <ns4:ExcludeFromDunning/>
        <ns4:MessageToCustomer/>
        <ns4:AgreementName/>
        <ns4:ProjectReference/>
        <ns4:PrePaymentFlag/>
        <ns4:MinisiteID>10041</ns4:MinisiteID>
        <ns4:PaymentTerm>45 days</ns4:PaymentTerm>
        <ns4:OrderLine>
          <ns4:ItemNumber>13243</ns4:ItemNumber>
          <ns4:OrderedQuantity>1</ns4:OrderedQuantity>
          <ns4:QuantityUOM/>
          <ns4:UnitListPrice>375.1334</ns4:UnitListPrice>
          <ns4:UnitNetPrice>375.1334</ns4:UnitNetPrice>
          <ns4:Tax>0</ns4:Tax>
          <ns4:TaxValue>0</ns4:TaxValue>
          <ns4:OrderLineReference>126764466733664</ns4:OrderLineReference>
          <ns4:ReturnOrderLineReference/>
          <ns4:ReturnReasonCode/>
          <ns4:DiscountBreakupInfo/>
          <ns4:CombinationID>76656565</ns4:CombinationID>
          <ns4:PostalCodeFrom>72202</ns4:PostalCodeFrom>
          <ns4:PostalCodeTo>3112</ns4:PostalCodeTo>
          <ns4:CountryCodeFrom>DE</ns4:CountryCodeFrom>
          <ns4:CountryCodeTo>NO</ns4:CountryCodeTo>
          <ns4:AccountingUnit>-3</ns4:AccountingUnit>
          <ns4:PriceAdjustmentPerUnit/>
          <ns4:TaxCode>52_EKSPORT</ns4:TaxCode>
          <ns4:ShippingMethod>000001_Posten_P_XXCU_BREV_</ns4:ShippingMethod>
          <ns4:ShipTo/>
          <ns4:InvoiceSpecification>
            <ns4:DateFrom/>
            <ns4:DateTo/>
            <ns4:Description>Importfortolling </ns4:Description>
            <ns4:OrderDate>2017-10-10T09:32:57</ns4:OrderDate>
            <ns4:ShipFrom>
              <ns4:Address1>ADOLF H�FELE STR. 1</ns4:Address1>
              <ns4:Address2/>
              <ns4:Address3/>
              <ns4:City>Nagold</ns4:City>
              <ns4:PostalCode>72202</ns4:PostalCode>
              <ns4:Country>DE</ns4:Country>
            </ns4:ShipFrom>
            <ns4:ShipTo>
              <ns4:Address1>M�keveien 2A</ns4:Address1>
              <ns4:Address2/>
              <ns4:Address3/>
              <ns4:City>T�NSBERG</ns4:City>
              <ns4:PostalCode>3112</ns4:PostalCode>
              <ns4:Country>NO</ns4:Country>
            </ns4:ShipTo>
            <ns4:NoOfPackages>1</ns4:NoOfPackages>
            <ns4:PackagesUOM/>
            <ns4:WaybillNumber/>
            <ns4:SenderName>H�FELE GMBH</ns4:SenderName>
            <ns4:ReceiverName>Thoresen Racing Sales As Tones Raceavdel</ns4:ReceiverName>
            <ns4:Pallet/>
            <ns4:Volume/>
            <ns4:VolumeUOM/>
            <ns4:Weight>150.00</ns4:Weight>
            <ns4:WeightUOM>KGM</ns4:WeightUOM>
            <ns4:FreightCalcWeight>370</ns4:FreightCalcWeight>
            <ns4:FreightCalcWeightUOM>KGM</ns4:FreightCalcWeightUOM>
            <ns4:ResponsiblePerson>MGA</ns4:ResponsiblePerson>
            <ns4:PPPrice/>
            <ns4:CargoType/>
            <ns4:ContainerReference/>
            <ns4:PickUpPoint/>
            <ns4:AirWaybillNumber/>
            <ns4:MasterAWB/>
            <ns4:HouseAWB/>
            <ns4:Vessel/>
            <ns4:Incoterm>DAP</ns4:Incoterm>
            <ns4:SenderReference>test to 0504 </ns4:SenderReference>
            <ns4:ReceiverReference>0504</ns4:ReceiverReference>
            <ns4:AgentReference>de-no</ns4:AgentReference>
            <ns4:LoadCarrier>IMP3200</ns4:LoadCarrier>
            <ns4:TransportMethod>30</ns4:TransportMethod>
            <ns4:DeliveryPoint>THORESEN RACING SALES AS</ns4:DeliveryPoint>
            <ns4:OurReference>3200/IMP/70703941005316600/MGA</ns4:OurReference>
            <ns4:CargoIdNumber>2017 D</ns4:CargoIdNumber>
            <ns4:PositionNumber>51</ns4:PositionNumber>
            <ns4:LoadMeter>.20</ns4:LoadMeter>
            <ns4:CargoLabel>yyyy</ns4:CargoLabel>
            <ns4:ChartequeNumber/>
            <ns4:DeliveredTime/>
            <ns4:ReceivedTime/>
            <ns4:Currency/>
            <ns4:CurrencyAmount/>
            <ns4:ExchangeRate/>
            <ns4:ExchangeDate/>
            <ns4:PickUpAddress1/>
            <ns4:PickUpAddress2/>
            <ns4:PickUpAddress3/>
            <ns4:PickUpPostalCode/>
            <ns4:PickUpCity/>
            <ns4:PickUpCountry/>
            <ns4:DeliveryAddress1>M�KEVEIEN 2A</ns4:DeliveryAddress1>
            <ns4:DeliveryAddress2/>
            <ns4:DeliveryAddress3/>
            <ns4:DeliveryPostalCode>3112</ns4:DeliveryPostalCode>
            <ns4:DeliveryCity>T�NSBERG</ns4:DeliveryCity>
            <ns4:DeliveryCountry>NO</ns4:DeliveryCountry>
            <ns4:UnloadingPoint/>
            <ns4:LoadingPoint/>
            <ns4:Note/>
            <ns4:ConsignmentTypeCode/>
            <ns4:ConsignmentTypeText/>
            <ns4:TransportMethodText/>
            <ns4:IncotermText/>
            <ns4:ShipToFiscalCode/>
            <ns4:ShipFromFiscalCode/>
            <ns4:InvoiceSpecificationLines>
              <ns4:OrderLineNumber>1</ns4:OrderLineNumber>
              <ns4:OrderLineText>kl VARER</ns4:OrderLineText>
              <ns4:OrderLineNoOfPackages>1</ns4:OrderLineNoOfPackages>
              <ns4:OrderLinePackagesUOM/>
              <ns4:OrderLinePallet/>
              <ns4:OrderLinePPPrice/>
              <ns4:OrderLineNetWeight/>
              <ns4:OrderLineNetWeightUOM/>
              <ns4:OrderLineLength/>
              <ns4:OrderLineWidth/>
              <ns4:OrderLineHeight/>
              <ns4:OrderLineDimensionUOM/>
              <ns4:OrderLineDate/>
              <ns4:OrderLinePerTimeUnit/>
              <ns4:OrderLineUnitPrice/>
              <ns4:OrderLineAmount/>
              <ns4:OrderLineCargoType>yyyy</ns4:OrderLineCargoType>
              <ns4:OrderLineFreightCalcWeight>370.00</ns4:OrderLineFreightCalcWeight>
              <ns4:OrderLineFreightCalcWeightUOM>KGM</ns4:OrderLineFreightCalcWeightUOM>
              <ns4:OrderLineVolume/>
              <ns4:OrderLineVolumeUOM/>
              <ns4:OrderLineLoadMeter>0.20</ns4:OrderLineLoadMeter>
              <ns4:OrderLineCargoLabel/>
              <ns4:OrderLineGrossWeight>150.00</ns4:OrderLineGrossWeight>
              <ns4:OrderLineGrossWeightUOM>KGM</ns4:OrderLineGrossWeightUOM>
            </ns4:InvoiceSpecificationLines>
          </ns4:InvoiceSpecification>
        </ns4:OrderLine>
        </ns4:OrderHeader>
    </ns1:Batch>
  </ns1:Order>
</ns1:PPOrderImport>');   
                                
 dbms_lob.Append( l_xml_str1, l_xml_str );                        
                l_xml_str := NULL;
                p_clob := to_clob(l_xml_str1);
                BEGIN
      ip_xml :=xmltype(p_clob);
    EXCEPTION
    WHEN OTHERS THEN
      fnd_file.put_line(fnd_file.log,'SQLERRM'||SQLERRM);
    END;
                                
      --recipients(1) := sys.aq$_agent('SUBS_PNS', NULL, NULL);
      r_message_properties.correlation :='PPOrderImport';
      DBMS_AQ.ENQUEUE( 
                                queue_name                                                                    => 'XXCU.XXCU_PNAS_TO_NPB',
                                enqueue_options                                           => r_enqueue_options, 
                                message_properties                                      => r_message_properties,
                                payload                                                                                => ip_xml, 
                                msgid                                                                                    => v_message_handle );
      COMMIT;
  EXCEPTION
  WHEN OTHERS THEN
    dbms_output.put_line('Error in Generating XML  '||SQLERRM);
    FND_FILE.PUT_LINE(fnd_file.LOG,'Error in Generating XML  '||SQLERRM);
  END;
END ;
----------------------------------------------------------------------------



