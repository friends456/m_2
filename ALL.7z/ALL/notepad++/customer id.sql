hz_cust_accounts
  i/p---account_number
  o/p---customer_id(cust_account_id)

FUNCTION getcustomer_id(
      p_customer_no IN VARCHAR2)
    RETURN NUMBER
  AS
    v_ret_val NUMBER;
  BEGIN
    BEGIN
      SELECT cust_account_id------166170
      INTO v_ret_val
      FROM hz_cust_accounts
      WHERE account_number = p_customer_no; --------10000002096
    EXCEPTION
    WHEN no_data_found THEN
      NULL;
    END;
    RETURN v_ret_val;
  END;
  
  