FOR bjjj IN 1 .. p_batch_order.v_order_head (hi).lv_private_cust.count
          LOOP
            
            IF(p_batch_order.v_order_head (hi).lv_private_cust(bjjj).customer_reference IS NOT NULL AND p_batch_order.v_order_head (hi).customer_number IS NULL) THEN
			
			
              FOR cust_rec IN 1.. p_batch_order.v_order_head ( hi ) .lv_private_cust.count
              LOOP
                
                BEGIN
                  SELECT flv.description
                  INTO lv_orig_system
                  FROM applsys.fnd_lookup_values flv                   
                  WHERE flv.lookup_type     ='XXCU_CUSTOMER_ORDER_SOURCE'
                  AND upper(flv.lookup_code)=upper(p_batch_order.v_order_head (hi).order_source)
                  AND flv.language          ='US';                  
                EXCEPTION
                WHEN OTHERS THEN
                  xxcu_common_log_rt.msglog ('ERR', 'Error while deriving source system for private customer'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                END;
                
                BEGIN
                  SELECT NVL(DECODE(upper(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).distribution_flag),'YES','Y','N'),'N')
                  INTO lv_distri_flag
                  FROM dual;
                EXCEPTION
                WHEN OTHERS THEN
                  lv_distri_flag:='N';
                END;
				
******************************************				
           IF( p_batch_order.v_order_head (hi). lv_private_cust(cust_rec).lv_addresslines.count=1 ) THEN
				
              FOR cust_addr IN 1 .. p_batch_order.v_order_head ( hi ). lv_private_cust(cust_rec).lv_addresslines.count				 
               LOOP				  
                    BEGIN
                     
                      xxcu_create_svcs_pkg.create_person_cust_bo ( p_init_msg_list => fnd_api.g_false, p_validate_bo_flag => fnd_api.g_true, p_person_prenameadj=> NULL, p_person_first_name =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).first_name, p_person_mid_name =>NULL, p_person_last_name => p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).last_name, p_date_of_birth =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).date_of_birth, p_account_name => NULL, p_country_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country,                                                                                                 -- country
                      p_address1 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address1, p_address2 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address2, p_address3 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address3, p_address4 =>NULL, p_city =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).city, p_postal_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).postal_code, p_county =>NULL, p_state =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country, -- country
                      p_province =>NULL, p_ship_address1 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address1, p_ship_address2 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address2, p_ship_address3 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address3, p_ship_address4 =>NULL, p_ship_city =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).city , p_ship_postal_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).postal_code, p_ship_country_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country , p_ship_county =>NULL, p_ship_state =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country , p_ship_province =>NULL, p_care_of =>NULL, p_behalf_of =>NULL, p_invoice_ref =>NULL, p_reserved_text =>NULL,
                      p_created_by_module =>NULL, p_source_system =>lv_orig_system, p_source_system_reference =>NULL, p_user_id =>NULL, p_phone_number =>NULL, p_far_bill =>NULL, p_far_ship =>NULL, x_person_cust_obj_tbl=>x_person_cust_obj_tbl, x_return_status=>p_return_status , x_msg_count=>x_msg_count, x_msg_data=>p_msg_data, x_person_id=>p_person_id );
                      
                      COMMIT;
                      xxcu_common_log_rt.msglog ('INFO','Customer creation status '||p_return_status||' ' ||p_person_id|| p_msg_data, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                    EXCEPTION
                    WHEN OTHERS THEN
                      xxcu_common_log_rt.msglog ('ERR', 'Error while creating customer 1'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                    END ;					
              END LOOP;
				  
                  BEGIN
                    FOR i IN x_person_cust_obj_tbl.first.. x_person_cust_obj_tbl.last
                    LOOP
                      FOR j IN x_person_cust_obj_tbl(i).account_objs.first..x_person_cust_obj_tbl(i).account_objs.last
                      LOOP
                        xxcu_common_log_rt.msglog ('INFO', 'Account Number :'||x_person_cust_obj_tbl(i).account_objs(j).account_number, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                        lv_acct_number:=x_person_cust_obj_tbl(i).account_objs(j).account_number;
                      END LOOP;
                    END LOOP;
                  EXCEPTION
                  WHEN OTHERS THEN
                    lv_acct_number:=NULL;
                  END;
               

			ELSE 
                
				BEGIN                   
                    xxcu_create_svcs_pkg.create_person_cust_bo ( p_init_msg_list => fnd_api.g_false, p_validate_bo_flag => fnd_api.g_true, p_person_prenameadj=> NULL, p_person_first_name =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).first_name, p_person_mid_name =>NULL, p_person_last_name => p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).last_name, p_date_of_birth =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).date_of_birth, p_account_name => NULL, p_country_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).country,                                                         -- country
                    p_address1 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).address1, p_address2 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).address2, p_address3 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).address3, p_address4 =>NULL, p_city =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).city, p_postal_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).postal_code, p_county =>NULL, p_state =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).country, -- country
                    p_province =>NULL, p_ship_address1 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).address1, p_ship_address2 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).address2, p_ship_address3 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).address3, p_ship_address4 =>NULL, p_ship_city =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).city , p_ship_postal_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).postal_code, p_ship_country_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).country , p_ship_county =>NULL, p_ship_state =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).country , p_ship_province =>NULL, p_care_of =>NULL, p_behalf_of =>NULL, p_invoice_ref =>NULL, p_reserved_text =>NULL, p_created_by_module =>NULL, p_source_system =>lv_orig_system,
                    p_source_system_reference =>NULL, p_user_id =>NULL, p_phone_number =>NULL, p_far_bill =>NULL, p_far_ship =>NULL, x_person_cust_obj_tbl=>x_person_cust_obj_tbl, x_return_status=>p_return_status , x_msg_count=>x_msg_count, x_msg_data=>p_msg_data, x_person_id=>p_person_id );                    
                    COMMIT;
                    xxcu_common_log_rt.msglog ('INFO', 'Customer creation status '||p_return_status||' ' ||p_person_id|| p_msg_data, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                    
					BEGIN
                      FOR i IN x_person_cust_obj_tbl.first.. x_person_cust_obj_tbl.last
                      LOOP
                        FOR j IN x_person_cust_obj_tbl(i).account_objs.first..x_person_cust_obj_tbl(i).account_objs.last
                        LOOP
                          xxcu_common_log_rt.msglog ('INFO', 'Account Number :'||x_person_cust_obj_tbl(i).account_objs(j).account_number, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                          lv_acct_number:=x_person_cust_obj_tbl(i).account_objs(j).account_number;
                        END LOOP;
                      END LOOP;
                    EXCEPTION
                    WHEN OTHERS THEN
                      lv_acct_number:=NULL;
                    END;
					
                  EXCEPTION
                  WHEN OTHERS THEN
                    xxcu_common_log_rt.msglog ('ERR', 'Error while creating private customer 2'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  END;		  
                END IF;
**************************************************				
				
				
                BEGIN
                  IF(lv_acct_number IS NULL) THEN
                    xxcu_common_log_rt.msglog ('INFO', 'p_person_id'||p_person_id, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                    SELECT cust_account_id,
                      object_version_number
                    INTO ln_sold_to_org,
                      p_object_version_number
                    FROM hz_cust_accounts
                    WHERE party_id=p_person_id;
                    xxcu_common_log_rt.msglog ('INFO', 'ln_sold_to_org'||ln_sold_to_org, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  ELSE
                    SELECT cust_account_id,
                      object_version_number
                    INTO ln_sold_to_org,
                      p_object_version_number
                    FROM hz_cust_accounts
                    WHERE account_number=lv_acct_number;
                  END IF;
                EXCEPTION
                WHEN OTHERS THEN
                  xxcu_common_log_rt.msglog ('ERROR', 'Customer Creation failed '||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  p_status_code  :=2;
                  p_error_message:='Customer Creation failed '||p_msg_data;
                  DELETE
                  FROM oe_headers_iface_all
                  WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                  AND org_id                 =p_batch_order.v_order_head (hi).org_id;
                END;
*****************************************************************************************				
				
      IF(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).far_number IS NOT NULL) THEN
                 
				 mo_global.init ('AR');
                  SELECT responsibility_id,
                    application_id
                  INTO ln_resp_id,
                    ln_appl_id
                  FROM applsys.fnd_responsibility_tl
                  WHERE responsibility_name LIKE 'PB AR Super User'
                  AND language='US';
                 
				 fnd_global.apps_initialize (user_id => g_user_id, resp_id => ln_resp_id, resp_appl_id => ln_appl_id );
                  mo_global.set_policy_context ('S', p_batch_order.v_order_head (hi).org_id);
                
				BEGIN
                    SELECT object_version_number
                    INTO ln_object_version_number
                    FROM ar.hz_parties
                    WHERE party_id=p_person_id;
                  EXCEPTION
                  WHEN OTHERS THEN
                    fnd_file.put_line(fnd_file.output,'Invalid object version number');
        		END;
				
                  lv_party_rec.party_id        := p_person_id;
                  lv_party_rec.attribute9      := p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).far_number;
                  lv_person_rec_type.party_rec := lv_party_rec;
                  hz_party_v2pub.update_person (p_init_msg_list => fnd_api.g_true, p_person_rec => lv_person_rec_type, p_party_object_version_number => ln_object_version_number, x_profile_id => ln_profile_id, x_return_status =>lv_return_status, x_msg_count => ln_msg_count, x_msg_data => lv_msg_data );
                
				IF (lv_return_status <> 'S') THEN
                    xxcu_common_log_rt.msglog ('ERR', 'ERROR while updating attribute9 of hz_parties:' || lv_msg_data, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  ELSE
                    xxcu_common_log_rt.msglog ('INFO', 'Attribute9 is updated successfully.', 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                END IF;
				  
                  COMMIT;
     END IF;
**************************************************************************************				
     IF(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number IS NOT NULL) THEN
                 
				 mo_global.init ('AR');
                  SELECT responsibility_id,
                    application_id
                  INTO ln_resp_id,
                    ln_appl_id
                  FROM applsys.fnd_responsibility_tl
                  WHERE responsibility_name LIKE 'PB AR Super User'
                  AND language='US';
				  
                  fnd_global.apps_initialize (user_id => g_user_id, resp_id => ln_resp_id, resp_appl_id => ln_appl_id );
                  mo_global.set_policy_context ('S', p_batch_order.v_order_head (hi).org_id);
				  
                  p_cust_account_rec.cust_account_id := ln_sold_to_org;
                  p_cust_account_rec.account_number  := p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number;
                  hz_cust_account_v2pub.update_cust_account ( 'T' , p_cust_account_rec , p_object_version_number , x_return_status , x_msg_count , x_msg_data ) ;
                  COMMIT;
      END IF;
				
**********************************************************************************************				
        IF(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).digi_id IS NOT NULL) THEN
                  lv_attr_group_name                                                 := 'DIGIPOST_ID';
                  l_change_info_table                                                := NULL;
                  lv_attribute_name :='ID';
				  
                  BEGIN
                    SELECT application_id,
                      attr_group_id
                    INTO ln_application_id,
                      ln_attribute_group_id
                    FROM ego_attr_groups_v
                    WHERE attr_group_type='HZ_PERSON_PROFILES_GROUP';
                  EXCEPTION
                  WHEN OTHERS THEN
                    xxcu_common_log_rt.msglog ('ERR', 'No data found for attr_group_type HZ_PERSON_PROFILES_GROUP'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  END;
				  
				  
                  l_attributes_row_table :=ego_user_attr_row_table( ego_user_attr_row_obj( 1 --ROW_IDENTIFIER
                  ,ln_attribute_group_id                                                     --ATTR_GROUP_ID
                  ,ln_application_id                                                         --ATTR_GROUP_APP_ID
                  ,lv_attr_group_type                                                        --ATTR_GROUP_TYPE
                  ,lv_attr_group_name ,NULL ,NULL                                            --DATA_LEVEL_1
                  ,NULL                                                                      --DATA_LEVEL_2
                  ,NULL ,NULL ,NULL ,ego_user_attrs_data_pvt.g_create_mode                   --TRANSACTION_TYPE
                  ) );
				  
                  l_attributes_data_table := ego_user_attr_data_table( ego_user_attr_data_obj( 1--ROW_IDENTIFIER
                  ,lv_attribute_name                                                            --ATTR_NAME
                  ,p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).digi_id            --ATTR_VALUE_STR
                  ,NULL                                                                         --ATTR_VALUE_NUM (in the baseUOM,'FT')
                  ,NULL                                                                         --ATTR_VALUE_DATE
                  ,NULL                                                                         --ATTR_DISP_VALUE
                  ,NULL                                                                         --ATTR_UNIT_OF_MEASURE (display this value in'CM')
                  ,1                                                                            --USER_ROW_IDENTIFIER
                  ) );
				  
                  BEGIN
                    SELECT hpp.person_profile_id,
                      hca.party_id
                    INTO ln_person_profile_id,
                      ln_party_id
                    FROM hz_person_profiles hpp,
                      hz_cust_accounts hca
                    WHERE hpp.party_id =hca.party_id
                    AND hca.cust_account_id=ln_sold_to_org;
                  EXCEPTION
                  WHEN OTHERS THEN
                    xxcu_common_log_rt.msglog ('ERR', 'No data found for person profile id'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  END;
                  
				  hz_extensibility_pub.process_person_record ( p_api_version => 1.0 , p_person_profile_id => ln_person_profile_id , 
				  p_attributes_row_table => l_attributes_row_table , p_attributes_data_table => l_attributes_data_table ,
				  p_change_info_table => l_change_info_table , p_entity_id => 1 , p_entity_index => 1 , p_entity_code => NULL , 
				  p_debug_level => 3 , p_init_error_handler => fnd_api.g_true , p_write_to_concurrent_log => fnd_api.g_false ,
				  p_init_fnd_msg_list => fnd_api.g_false , p_log_errors => fnd_api.g_true , p_add_errors_to_fnd_stack => fnd_api.g_false , 
				  p_commit => fnd_api.g_false ,x_failed_row_id_list => lv_failed_row_id_list ,x_return_status => lv_return_status ,
				  x_errorcode => ln_errorcode ,x_msg_count => ln_msg_count ,x_msg_data => lv_msg_data );
                  
				  SELECT extension_id
                  INTO ln_extension_id
                  FROM hz_per_profiles_ext_b
                  WHERE person_profile_id=ln_person_profile_id;
                  
                  IF (LENGTH(lv_failed_row_id_list) > 0) THEN
                    fnd_file.put_line(fnd_file.output,'List of rows that failed: '||lv_failed_row_id_list);
                   
				   DECLARE
                      lv_errors_tbl error_handler.error_tbl_type;
                    BEGIN
                      error_handler.get_message_list(lv_errors_tbl);
                      FOR i IN 1..lv_errors_tbl.count
                      LOOP
                        xxcu_common_log_rt.msglog ('ERR', 'Message:'||SUBSTR(lv_errors_tbl(i).message_text,1,254), 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));                       
                      END LOOP;
                    END;
                  END IF;
				  
                END IF;
********************************************************************************************				
				
               
     BEGIN
                 
		 BEGIN
                    
					SELECT flv.profile_option_value
                    INTO lv_term_name
                    FROM fnd_profile_options_vl fpov,
                      applsys.fnd_profile_option_values flv
                    WHERE fpov.profile_option_name='XXCU_DEFAULT_PAYMET_TERM'
                    AND flv.profile_option_id     =fpov.profile_option_id;
                  EXCEPTION
                  WHEN OTHERS THEN
                    xxcu_common_log_rt.msglog ('ERR', 'Error in profile option PB Default Payment Term for Private Customers'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
          END;
				  
            BEGIN
                  
				  SELECT term_id INTO ln_term FROM ra_terms WHERE name=lv_term_name;
                  EXCEPTION
                  WHEN OTHERS THEN
                    xxcu_common_log_rt.msglog ('ERR', 'Error while deriving paymet term for private customer'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
             END;
				  
                  UPDATE oe_headers_iface_all
                  SET payment_term_id        =ln_term,--'10 days',--defect 4783
                    sold_to_org_id           =ln_sold_to_org
                  WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                  AND org_id                 =p_batch_order.v_order_head (hi).org_id;
                  COMMIT;
				  
                EXCEPTION
                WHEN OTHERS THEN
                  xxcu_common_log_rt.msglog ('ERR', 'Error while updating order header'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                END;
                
              END LOOP;
            END IF;
          END LOOP;
		  
************************************************