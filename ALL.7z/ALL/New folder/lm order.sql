PROCEDURE create_lm_order
    (
      p_batch_order    IN xxcu_ont_create_order_parser.batch_order_rec,
      p_shipment_order IN xxcu_ont_create_order_parser.shipment_order_rec,
      p_org_id         IN NUMBER,
      p_status_code OUT NUMBER,
      p_error_message OUT VARCHAR2
    )
  AS
    lv_shipment_head xxcu_ont_create_order_parser.shipment_head :=xxcu_ont_create_order_parser.shipment_head();
    lv_packagelines xxcu_ont_create_order_parser.package_lines:= xxcu_ont_create_order_parser.package_lines () ;
    lv_pricelines xxcu_ont_create_order_parser.price_lines    := xxcu_ont_create_order_parser.price_lines();
    lv_terminal xxcu_ont_create_order_parser.terminal_lines   := xxcu_ont_create_order_parser.terminal_lines();
    ln_errors          NUMBER;
    lv_finish_status   BOOLEAN;
    lv_status_function NUMBER := g_code_ok;
    ln_org_id          NUMBER;
    lv_success         VARCHAR2(200);
	
  BEGIN
    lv_shipment_head := xxcu_ont_create_order_parser.shipment_head();
    lv_packagelines  := xxcu_ont_create_order_parser.package_lines();
    lv_pricelines    :=xxcu_ont_create_order_parser.price_lines();
    lv_terminal      :=xxcu_ont_create_order_parser.terminal_lines();
    g_org_id         :=p_org_id;
    lv_shipment_head.extend(1);
    lv_packagelines.extend;
    lv_pricelines.extend;
    lv_terminal.extend;
	
	
    BEGIN
      SELECT user_id INTO g_user_id FROM fnd_user WHERE user_name='OPERATIONS';
    EXCEPTION
    WHEN OTHERS THEN
      g_user_id:=NULL;
    END;
	
	
    FOR hi IN 1 .. p_batch_order.lv_shipment_head.count
    LOOP
      xxcu_common_log_rt.msglog ('INFO', 'Shipment Header'||p_batch_order.lv_shipment_head.count, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
      
	  
	  FOR ll IN 1 .. p_batch_order.lv_shipment_head ( hi ) .lv_terminal.count
      LOOP
        xxcu_common_log_rt.msglog ('INFO', 'Terminal Header'||p_batch_order.lv_shipment_head ( hi ) .lv_terminal.count, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
       
	   BEGIN
          INSERT
          INTO xxcu_oe_shipment_spec 
		  VALUES
            (
              xxcu_oe_shipment_id_s.nextval,
              p_batch_order.lv_shipment_head(hi).customer_num,
              p_batch_order.lv_shipment_head(hi).trans_curr_code,
              NULL,
              NULL ,
              NULL ,
              NULL ,
              p_batch_order.lv_shipment_head(hi).ordered_date ,
              p_batch_order.lv_shipment_head(hi).payment_provider_trans_id ,
              p_batch_order.lv_shipment_head(hi).reserved_amount ,
              p_batch_order.lv_shipment_head(hi).source ,
              p_batch_order.lv_shipment_head(hi).sender_reference ,
              p_batch_order.lv_shipment_head(hi).shipment_id_num ,
              p_batch_order.lv_shipment_head(hi).returned ,
              p_batch_order.lv_shipment_head(hi).freight_cal_wt ,
              p_batch_order.lv_shipment_head(hi).price_zone ,
              p_batch_order.lv_shipment_head(hi).weight_group ,
              p_batch_order.lv_shipment_head(hi).num_of_pkgs ,
              p_batch_order.lv_shipment_head(hi).sender_name ,
              p_batch_order.lv_shipment_head(hi).ship_from_addr1 ,
              p_batch_order.lv_shipment_head(hi).ship_from_addr2 ,
              p_batch_order.lv_shipment_head(hi).ship_from_postal_code ,
              p_batch_order.lv_shipment_head(hi).ship_from_city ,
              p_batch_order.lv_shipment_head(hi).ship_from_country ,
              p_batch_order.lv_shipment_head(hi).receiver_reference ,
              p_batch_order.lv_shipment_head(hi).receiver_name ,
              p_batch_order.lv_shipment_head(hi).ship_to_addr1 ,
              p_batch_order.lv_shipment_head(hi).ship_to_addr2 ,
              p_batch_order.lv_shipment_head(hi).ship_to_postal_code ,
              p_batch_order.lv_shipment_head(hi).ship_to_city ,
              p_batch_order.lv_shipment_head(hi).ship_to_country ,
              p_batch_order.lv_shipment_head(hi).delivery_point ,
              p_batch_order.lv_shipment_head(hi).delivery_addr1 ,
              p_batch_order.lv_shipment_head(hi).delivery_addr2 ,
              p_batch_order.lv_shipment_head(hi).delivery_postal_code ,
              p_batch_order.lv_shipment_head(hi).delivery_city ,
              p_batch_order.lv_shipment_head(hi).delivery_country ,
              p_batch_order.lv_shipment_head(hi).volume_factor ,
              p_batch_order.lv_shipment_head(hi).shipment_sum ,
              p_batch_order.lv_shipment_head(hi).message_to_cust ,
              NULL ,
              p_batch_order.lv_shipment_head(hi).postal_code_to ,
              p_batch_order.lv_shipment_head(hi).postal_code_from ,
              p_batch_order.lv_shipment_head(hi).po_reference ,
              p_batch_order.lv_shipment_head(hi).agreement_name ,
              g_user_id ,
              sysdate ,
              g_user_id ,
              sysdate,
              g_org_id,
              p_batch_order.batchid,
              NULL,
              NULL,                                                            --defect 4205
              p_batch_order.lv_shipment_head(hi).department,                   --defect 3947
              p_batch_order.lv_shipment_head(hi).lv_terminal(ll).terminal_name,-- CR 4419
              p_batch_order.lv_shipment_head(hi).lv_terminal(ll).terminal_id,   -- CR 4419
              NULL, 
              NULL,
              NULL--worker added for parallel processing of LM
            );
			
        EXCEPTION
        WHEN OTHERS THEN
          --xxcu_log_pkg.LOG (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled errors in the xxcu_invoice_spec_p > ::Contact your system administrator:: ' || SQLERRM );
          xxcu_common_log_rt.msglog ('ERR', 'Error Inserted in Spec Header'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
          p_status_code  := 2;
          p_error_message:='Error in create lm order procedure'||sqlerrm||dbms_utility.format_error_backtrace;
          ROLLBACK;
        END;
		
      END LOOP;
	  
	  
	  
	  
	  
      FOR i IN 1 .. p_batch_order.lv_shipment_head(hi).lv_packagelines.count
      LOOP
        BEGIN
          INSERT
          INTO xxcu_oe_package_spec VALUES
            (
              xxcu_oe_package_id_s.nextval,
              p_batch_order.lv_shipment_head(hi).lv_packagelines(i).cargo_id_num,
              p_batch_order.lv_shipment_head(hi).lv_packagelines(i).weight,
              p_batch_order.lv_shipment_head(hi).lv_packagelines(i).volume,
              xxcu_oe_shipment_id_s.currval,
              p_batch_order.lv_shipment_head(hi).lv_packagelines(i).volume_weight,
              p_batch_order.lv_shipment_head(hi).lv_packagelines(i).received_time,
              sysdate ,
              g_user_id ,
              sysdate ,
              g_user_id,
              NULL
            );
        EXCEPTION
        WHEN OTHERS THEN
          --xxcu_log_pkg.LOG (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled errors in the xxcu_invoice_spec_p > ::Contact your system administrator:: ' || SQLERRM );
          xxcu_common_log_rt.msglog ('ERR', 'Error Inserted in PAckage Lines'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
          p_status_code  := 1;
          p_error_message:='Error in create lm order procedure xxcu_oe_package_spec'||sqlerrm||dbms_utility.format_error_backtrace;
          ROLLBACK;
        END;
      END LOOP;
	  
	  
	  
      FOR l IN 1 .. p_batch_order.lv_shipment_head(hi).lv_pricelines.count
      LOOP
        BEGIN
          INSERT
          INTO xxcu_oe_priceline_spec VALUES
            (
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).item_number,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).ordered_qty ,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).unit_list_price ,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).unit_net_price ,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).price_adjs_per_unit ,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).tax_code ,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).tax ,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).tax_value ,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).country_from ,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).country_to ,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).disc_breakup_info ,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).quantity_uom ,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).product_code ,
              NULL,--defect 3702
              xxcu_oe_shipment_id_s.currval,
              NULL ,
              NULL ,
              NULL,
              sysdate ,
              xxcu_oe_pricelist_id_s.nextval ,
              g_user_id ,
              sysdate ,
              g_user_id ,
              NULL ,
              NULL,
              NULL,
              p_batch_order.lv_shipment_head(hi).lv_pricelines(l).department,--defect 3702
              NULL
            );
			
			
        EXCEPTION
        WHEN OTHERS THEN
          --xxcu_log_pkg.LOG (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled errors in the xxcu_invoice_spec_p > ::Contact your system administrator:: ' || SQLERRM );
          xxcu_common_log_rt.msglog ('ERR', 'Error Inserted in Price Lines'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
          p_status_code  := 2;
          p_error_message:='Error in create lm order procedure XXCU_OE_PRICELIST_SPEC'||sqlerrm||dbms_utility.format_error_backtrace;
        END;
		
		
        lv_success:='TRUE';
      END LOOP;
	  
	  
    END LOOP;
	
	
    COMMIT;
    IF(lv_success ='TRUE') THEN
	
      g_program_loc    := 'Reconciliation';
	  lv_finish_status := false;
	  reconciliation (p_batch_order.batchid, p_batch_order.messagesequenceno, p_batch_order.batchnototal, p_batch_order.messagedetailcount, p_batch_order.batchdate,p_batch_order.batchdetailcount,-- p_batch_order.MessageDetailCount,
      NULL, NULL, p_batch_order.messagedetailcount,NULL, NULL,p_batch_order.numberofmessages, lv_finish_status, lv_status_function );
	  
	  
     	  
	  
      IF lv_finish_status THEN
        --IF (v_finish_status AND (lv_wrong_price<>'Y' AND lv_wrong_tax<>'Y' AND lv_wrong_cust<>'Y' AND lv_wrong_ref<>'Y' AND lv_wrong_ret_data <>'Y')) THEN
        update_batch_status(p_batch_order.batchid, 'ORDER IMPORT');
        g_program_loc := 'BookOrder';
        ln_org_id     :=g_org_id;
		
		
        --how many lines did not import?
        SELECT COUNT (*)
        INTO ln_errors
        FROM oe_lines_iface_all
        WHERE error_flag          = 'Y'
        AND TRUNC (creation_date) = TRUNC (sysdate)
        AND order_source_id       = g_order_source_id;
		
		
        IF ln_errors              > 0 THEN
          xxcu_log_pkg.log (p_log_level => fnd_log.level_event, p_module_name => gpackagename, p_log_text => 'Info: a few lines(' || ln_errors || ') the import has failed, will move the lines again feilde over head and import the remaining' );
        END IF;
		
        update_batch_status(p_batch_order.batchid, 'FINISHED');
		
      END IF;
	  
    END IF;
  END;