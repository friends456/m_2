
  FUNCTION createorderhead_interface(
      p_order_head_rec   IN xxcu_ont_create_order_parser.orderhead_rec,
      p_batch_id         IN VARCHAR2,
      p_status_code      IN OUT NUMBER,
      p_num_orderheaders IN OUT NUMBER,
      p_amount           IN NUMBER,
      p_error_message OUT VARCHAR2 )
    RETURN VARCHAR2
  AS
  
  
    l_operation             VARCHAR2 ( 50 ) ;
    l_header_id             NUMBER;
    l_customer_id           NUMBER;
    l_orig_sys_document_ref VARCHAR2 (50);
    l_version_number        NUMBER;
    l_num_iface_headers     NUMBER;
    l_conversion_date       DATE;
    l_log_label             VARCHAR2(200);
    l_payment_term          NUMBER;
    v_curr_code             VARCHAR2(100);
    l_message               VARCHAR2(2000);
	
    k_func_name             VARCHAR2(100):='createorderhead_interface';
    l_conversion_type       VARCHAR2 (50);
    v_context               NUMBER;
    v_order_type_id         NUMBER;
    v_salesrep_id           NUMBER;
    v_bsa_num               NUMBER;
    lv_new_curr_code        VARCHAR2(100);
    g_user_id               NUMBER;
    lv_org_name             VARCHAR2(100);
    lv_attribute1           VARCHAR2(150);
    lv_attribute2           VARCHAR2(150);
    lv_attribute15          VARCHAR2(150);
    lv_attribute14          VARCHAR2(150);
    lv_curr_code            VARCHAR2(100);
    lv_pricing_date         DATE;
    ln_doc_seq_id           NUMBER;
    lv_trans_type           VARCHAR2(240);
    lv_post_fix             VARCHAR2(240); -- changes for CR#C-06068
    lv_type                 VARCHAR2(80);
    --ln_order_number         NUMBER;  /*Version 1.30 Kavita CR#2499 declared globally with name g_order_number*/
    c                  NUMBER:=0;
    lv_receipt_method  VARCHAR2(60);
    lv_return_status   VARCHAR2(50);
    ln_msg_count       NUMBER;
    ln_receipt_num     VARCHAR2(2000);--:='88569443621';
    lv_msg_data        VARCHAR2(2000);
    ln_payment_set_id  NUMBER;
    ln_amount          NUMBER;
    ln_resp_id         NUMBER;
    ln_app_id          NUMBER;
    ln_cash_receipt_id NUMBER;
    lv_rec_curr_code   VARCHAR2(25);
    lv_attribute5      VARCHAR2(240);
    lv_attribute3      VARCHAR2(240);
    lv_attribute4      VARCHAR2(240);---added by vijay on 27-jun-2017 for defect 3528
    lv_attribute18     VARCHAR2(240);
    
	
	---l_application_ref_type ar_receivable_applications.application_ref_type%type; --ME
    ln_application_ref_id ar_receivable_applications.application_ref_id%type;
   ---ln_application_ref_num ar_receivable_applications.application_ref_num%type; --me
    ln_sec_application_ref_id ar_receivable_applications.secondary_application_ref_id%type;
    ln_receivable_application_id ar_receivable_applications.receivable_application_id%type;
	
	
	
    --ln_bank_account_id             NUMBER; --me
    ln_remit_bank                  NUMBER;
    lv_approval_code               VARCHAR2(2000);
    lv_payment_response_error_code VARCHAR2(2000);
	
    ln_payment_server_order_num ar_cash_receipts.payment_server_order_num%type; ----------VARCHAR2(80 BYTE), 94 col
	
    lv_payment_type_code VARCHAR2(240);
    lv_flag              VARCHAR2(10);
    lv_attr4             VARCHAR2(240);
    ln_cnt_desc          NUMBER:=0;
    lv_proj_ref          VARCHAR2(240);
    lv_proj_flag         VARCHAR2(240);
    lv_proj_flag_party   VARCHAR2(240);
    lv_proj_flag_acc     VARCHAR2(240);
    lv_proj_flag_site    VARCHAR2(240);
    lv_proj_flag_bsa     VARCHAR2(240);
    lv_context           VARCHAR2(240);
    lv_attr2             VARCHAR2(240);
    lv_attr6             VARCHAR2(240);
    lv_attr7             VARCHAR2(240);
    lv_attr8             VARCHAR2(240);
    lv_attr13            VARCHAR2(240);
    lv_attr16            VARCHAR2(240);
    lv_attribute6        VARCHAR2(240);
    lv_attribute7        VARCHAR2(240);
    lv_attribute8        VARCHAR2(240);
    lv_attribute13       VARCHAR2(240);
    lv_attribute16       VARCHAR2(240);
	
	
	
  BEGIN
    c                 :=0;
    p_num_orderheaders:=0;
    lv_new_curr_code  :=NULL;
    g_order_number    :=NULL;
    xxcu_common_log_rt.msglog ('INFO', 'Inside Create Head ', 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
   
    
	***********
	BEGIN
      SELECT name
      INTO lv_org_name
      FROM hr_operating_units
      WHERE organization_id=p_order_head_rec.org_id;
	  
      SELECT userid
      INTO g_user_id
      FROM xxcu_int_init_app_logons
      WHERE procedure_name   =upper('XXCU_ONT_CREATE_ORDER_PKG')
      AND operating_unit_name=lv_org_name;
    EXCEPTION
    WHEN OTHERS THEN
      g_user_id :=fnd_global.user_id;
    END;
    ***************
	IF(p_order_head_rec.order_source='NO002_RB' AND upper(p_order_head_rec.order_type)='RETURN') THEN
      BEGIN
        SELECT cust_account_id
        INTO l_customer_id
        FROM hz_cust_accounts hca,
          oe_order_headers_all ooha
        WHERE ooha.orig_sys_document_ref=p_order_head_rec.return_order_reference
        AND ooha.sold_to_org_id         =hca.cust_account_id
        AND ooha.org_id                 =p_order_head_rec.org_id;
      EXCEPTION
      WHEN OTHERS THEN
        l_customer_id:=NULL;
      END;
    ELSE
      l_customer_id := getcustomer_id (p_order_head_rec.customer_number);
    END IF;
	
    xxcu_common_log_rt.msglog ('INFO', 'l_customer_id '||l_customer_id, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
	*******************
	
	
    
    *****************
	l_orig_sys_document_ref := p_order_head_rec.order_reference;
    xxcu_common_log_rt.msglog ('INFO', 'l_orig_sys_document_ref '||l_orig_sys_document_ref, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
    *****************
	
	
    
	*******************************
	IF p_order_head_rec.pricing_date IS NOT NULL THEN
      l_conversion_type              := 'Corporate';
    ELSE
      l_conversion_type := NULL;
    END IF;
    xxcu_common_log_rt.msglog ('INFO', 'l_conversion_type '||l_conversion_type, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
    
	******************************
	BEGIN
      SELECT gso.currency_code
      INTO lv_curr_code
      FROM hr_operating_units hou,
        gl_sets_of_books gso
      WHERE gso.set_of_books_id=hou.set_of_books_id
      AND hou.organization_id  =p_order_head_rec.org_id;
    EXCEPTION
    WHEN OTHERS THEN
      lv_curr_code:=NULL;
    END;
	********************************
	
    IF (upper(p_order_head_rec.order_type)='RETURN' AND lv_curr_code<>NVL(get_currencycode(getcustomer_id (p_order_head_rec.customer_number),p_order_head_rec.org_id),p_order_head_rec.currency_code) AND p_order_head_rec.payment_provider_trans_id IS NULL) THEN
      BEGIN
        SELECT pricing_date
        INTO lv_pricing_date
        FROM oe_order_headers_all
        WHERE orig_sys_document_ref=p_order_head_rec.return_order_reference
        AND org_id = p_order_head_rec.org_id; 
      EXCEPTION
      WHEN OTHERS THEN
        lv_pricing_date:=NULL;
        xxcu_common_log_rt.msglog ('INFO', 'lv_pricing_date '||lv_pricing_date||sqlerrm, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
      END;
    ELSE
      
      IF(lv_curr_code  <>NVL(get_currencycode(getcustomer_id (p_order_head_rec.customer_number),p_order_head_rec.org_id),p_order_head_rec.currency_code)) THEN
        lv_pricing_date:=p_order_head_rec.pricing_date;
      ELSE
        lv_pricing_date:=NULL;
      END IF;
    END IF;
	
	***************************
    IF(get_currencycode(getcustomer_id (p_order_head_rec.customer_number),p_order_head_rec.org_id) IS NOT NULL AND p_order_head_rec.payment_provider_trans_id IS NULL AND p_order_head_rec.currency_code=lv_curr_code) THEN
      lv_new_curr_code:=get_currencycode(getcustomer_id (p_order_head_rec.customer_number),p_order_head_rec.org_id);
    END IF;
	***************************
    
    IF upper(p_order_head_rec.order_type) = 'RETURN' THEN 
      BEGIN
        SELECT transactional_curr_code
        INTO lv_new_curr_code
        FROM oe_order_headers_all
        WHERE orig_sys_document_ref=p_order_head_rec.return_order_reference
        AND org_id                 = p_order_head_rec.org_id; 
      EXCEPTION
      WHEN OTHERS THEN
        lv_new_curr_code :=NULL;
      END;
    END IF;
	
	************************************
    
    dbms_output.put_line('l_orig_sys_document_ref'|| l_orig_sys_document_ref);
    **********************************
	BEGIN
      SELECT COUNT (1)
      INTO l_num_iface_headers
      FROM oe_headers_iface_all
      WHERE orig_sys_document_ref = l_orig_sys_document_ref
      AND order_source_id         = g_order_source_id;
    EXCEPTION
    WHEN no_data_found THEN
      dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
      l_num_iface_headers := 0;
    END;
	**********************************
    
	xxcu_log_pkg.log(xxcu_log_pkg.gk_exception, k_log_module_prefix || '.' || k_func_name || '.' || l_num_iface_headers , l_num_iface_headers, false);
   
   
    xxcu_log_pkg.log (p_log_level => fnd_log.level_statement, p_module_name => gpackagename, p_log_text => 'IN if l_num_iface_headers = 0' );
    
	
	l_header_id := getheader_id ( p_order_head_rec.customer_number,p_order_head_rec.return_order_reference,p_order_head_rec.org_id ,l_version_number);
    
	xxcu_log_pkg.log (p_log_level => fnd_log.level_statement, p_module_name => gpackagename, p_log_text => 'createorderhead_interface: l_header_id:' || l_header_id );


    l_operation        := 'INSERT'; 
    p_num_orderheaders := p_num_orderheaders + 1;
    
	
    xxcu_log_pkg.log (p_log_level => fnd_log.level_statement, p_module_name => gpackagename, p_log_text => 'Info: Inserted into oe_headers_iface_all ( ' || p_order_head_rec.customer_number || ') ' );
    
	
    dbms_output.put_line('INSIDE INSERT HEADER HEADERID'|| l_header_id);
    dbms_output.put_line('l_customer_id'|| l_customer_id);
   
   
   
    BEGIN
      v_order_type_id := get_transaction_type_id( p_order_head_rec.order_source, p_order_head_rec.order_type, p_order_head_rec.org_id, p_status_code, p_error_message);-------------------------doubt value of status code err msg
    EXCEPTION
    WHEN OTHERS THEN
      xxcu_common_log_rt.msglog ('ERR', 'Failed to derive transaction type id 2 '||sqlerrm||dbms_utility.format_error_backtrace, 1117, '1', 'get_transaction_type_id', '-1' );
    END;
    
	
    BEGIN
      SELECT ffvv.attribute11 ----fully null
      INTO lv_context
      FROM fnd_flex_value_sets ffvs,
        fnd_flex_values ffvv
      WHERE ffvs.flex_value_set_name='XXCU_OM_SOURCE_ORDER_TYPE'
      AND ffvs.flex_value_set_id    =ffvv.flex_value_set_id
      AND upper(ffvv.flex_value)    =upper(p_order_head_rec.order_source);
    EXCEPTION
    WHEN OTHERS THEN
      lv_context:=NULL;
    END;
	
	
    
    BEGIN
      SELECT COUNT(*)
      INTO ln_cnt_desc
      FROM fnd_descr_flex_contexts_vl
      WHERE descriptive_flex_context_name=lv_context
      AND descriptive_flexfield_name     ='OE_HEADER_ATTRIBUTES';
    EXCEPTION
    WHEN OTHERS THEN
      ln_cnt_desc:=0;
    END;
    
	
	
	
	---------------checking if context is to be set as 'TMS' or not-------------------------
    IF(lv_context=NULL OR ln_cnt_desc=0) THEN
      BEGIN
        SELECT COUNT(*)
        INTO v_context
        FROM
          oe_transaction_types_v ott,
          ra_cust_trx_types_all rctt
        WHERE 1                    =1 
        AND ott.org_id             =p_order_head_rec.org_id
        AND ott.transaction_type_id=v_order_type_id
        AND transaction_type_code IN ('ORDER','RETURN')
        AND order_category_code   IN ('ORDER','RETURN')
        AND (end_date_active      IS NULL
        OR TRUNC(end_date_active) >=TRUNC(sysdate))
        AND rctt.cust_trx_type_id  =ott.cust_trx_type_id
        AND rctt.name LIKE '%TMS%';
      EXCEPTION
      WHEN OTHERS THEN
        v_context:=0;
        dbms_output.put_line('v_context'||v_context);
      END;
    END IF;
    
	
	IF(p_order_head_rec.handling_date IS NOT NULL) THEN
      lv_attr2                        :=TO_CHAR(to_date(p_order_head_rec.handling_date,'DD-MON-YY HH:MI:SS'),'YYYY/MM/DD HH:MI:SS');
    ELSE
      IF (p_order_head_rec.charteque_number IS NOT NULL) THEN
        lv_attr2                            :=p_order_head_rec.charteque_number;
      ELSE
        IF (p_order_head_rec.waiting_date IS NOT NULL) THEN
          lv_attr2                        :=TO_CHAR(to_date(p_order_head_rec.waiting_date,'DD-MON-YY HH:MI:SS'),'YYYY/MM/DD HH:MI:SS');--defect 4246
        ELSE
          IF (p_order_head_rec.customs_id IS NOT NULL) THEN
            lv_attr2                      :=p_order_head_rec.customs_id;
          ELSE
            IF (p_order_head_rec.contract_modifier_num IS NOT NULL) THEN
              lv_attr2                                 :=p_order_head_rec.contract_modifier_num;
            END IF;
          END IF;
        END IF;
      END IF;
    END IF;
   


   IF(p_order_head_rec.settlement_flag IS NOT NULL) THEN
      lv_attr4                          :=p_order_head_rec.settlement_flag;
    ELSE
      IF (p_order_head_rec.special_handling IS NOT NULL) THEN
        lv_attr4                            :=p_order_head_rec.special_handling;
      ELSE
        IF (p_order_head_rec.sender_name IS NOT NULL) THEN
          lv_attr4                       :=p_order_head_rec.sender_name;
        ELSE
          IF (p_order_head_rec.contract_num IS NOT NULL) THEN
            lv_attr4                        :=p_order_head_rec.contract_num;
          END IF;
        END IF;
      END IF;
    END IF;
    
	
	IF(p_order_head_rec.master_consign_id IS NOT NULL) THEN
      lv_attr6                            :=p_order_head_rec.master_consign_id;
    END IF;
    
	
	IF(p_order_head_rec.consignment_num IS NOT NULL) THEN
      lv_attr7                          :=p_order_head_rec.consignment_num;
    END IF;
    
	
	IF(p_order_head_rec.consign_item_num IS NOT NULL) THEN
      lv_attr8                           :=p_order_head_rec.consign_item_num;
    END IF;
   

   IF(p_order_head_rec.sender_name IS NOT NULL) THEN
      lv_attr16                     :=p_order_head_rec.sender_name;
      
    ELSE
      IF(p_order_head_rec.credit_card_source IS NOT NULL) THEN
        lv_attr16                            :=p_order_head_rec.credit_card_source;
      END IF;
 END IF;
    
	
	
	IF(p_order_head_rec.invoice_text IS NOT NULL) THEN
      lv_attr13                      :=p_order_head_rec.invoice_text;
    ELSE
      IF (p_order_head_rec.bill_details IS NOT NULL) THEN
        lv_attr13                       :=p_order_head_rec.bill_details;
      ELSE
        IF (p_order_head_rec.payment_method IS NOT NULL) THEN
          lv_attr13                         :=p_order_head_rec.payment_method;
        ELSE
          IF (p_order_head_rec.minisite_id IS NOT NULL) THEN
            lv_attr13                      :=p_order_head_rec.minisite_id;
          END IF;
        END IF;
      END IF;
    END IF;
	
	
	
   
    BEGIN
     
      BEGIN
        SELECT val
        INTO v_salesrep_id
        FROM
          (SELECT po.profile_option_name value_name,
            po.user_profile_option_name,
            DECODE (TO_CHAR (pov.level_id), '10001', 'SITE', '10002', 'APP', '10003', 'RESP', '10005', 'SERVER', '10006', 'ORG', '10004', 'USER', '???' ) value_level,
            DECODE (TO_CHAR (pov.level_id), '10001', '', '10002', app.application_short_name, '10003', rsp.responsibility_key, '10005', svr.node_name, '10006', org.name, '10004', usr.user_name, '???' ) con,
            pov.profile_option_value val
          FROM apps.fnd_profile_options_vl po,
            apps.fnd_profile_option_values pov,
            apps.fnd_user usr,
            apps.fnd_application app,
            apps.fnd_responsibility rsp,
            apps.fnd_nodes svr,
            apps.hr_operating_units org
          WHERE 1                      = 1
          AND pov.application_id       = po.application_id
          AND pov.profile_option_id    = po.profile_option_id
          AND usr.user_id(+)           = pov.level_value
          AND rsp.application_id(+)    = pov.level_value_application_id
          AND rsp.responsibility_id(+) = pov.level_value
          AND app.application_id(+)    = pov.level_value
          AND svr.node_id(+)           = pov.level_value
          AND org.organization_id(+)   = pov.level_value
          AND po.profile_option_name LIKE 'ONT_DEFAULT_PERSON_ID'
          )
        WHERE value_level='USER';
      EXCEPTION
      WHEN OTHERS THEN
        v_salesrep_id:=NULL;
        dbms_output.put_line('331'||sqlerrm);
      END;
      
	  
	  
	  BEGIN
        IF (v_salesrep_id IS NULL) THEN
          SELECT val
          INTO v_salesrep_id
          FROM
            (SELECT po.profile_option_name value_name,
              po.user_profile_option_name,
              DECODE (TO_CHAR (pov.level_id), '10001', 'SITE', '10002', 'APP', '10003', 'RESP', '10005', 'SERVER', '10006', 'ORG', '10004', 'USER', '???' ) value_level,
              DECODE (TO_CHAR (pov.level_id), '10001', '', '10002', app.application_short_name, '10003', rsp.responsibility_key, '10005', svr.node_name, '10006', org.name, '10004', usr.user_name, '???' ) con,
              pov.profile_option_value val
            FROM apps.fnd_profile_options_vl po,
              apps.fnd_profile_option_values pov,
              apps.fnd_user usr,
              apps.fnd_application app,
              apps.fnd_responsibility rsp,
              apps.fnd_nodes svr,
              apps.hr_operating_units org
            WHERE 1                      = 1
            AND pov.application_id       = po.application_id
            AND pov.profile_option_id    = po.profile_option_id
            AND usr.user_id(+)           = pov.level_value
            AND rsp.application_id(+)    = pov.level_value_application_id
            AND rsp.responsibility_id(+) = pov.level_value
            AND app.application_id(+)    = pov.level_value
            AND svr.node_id(+)           = pov.level_value
            AND org.organization_id(+)   = pov.level_value
            AND po.profile_option_name LIKE 'ONT_DEFAULT_PERSON_ID'
            )
          WHERE value_level='RESP';
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        v_salesrep_id:=NULL;
        dbms_output.put_line('376'||sqlerrm);
      END;
     



	 BEGIN
        IF (v_salesrep_id IS NULL) THEN
          SELECT val
          INTO v_salesrep_id
          FROM
            (SELECT po.profile_option_name value_name,
              po.user_profile_option_name,
              DECODE (TO_CHAR (pov.level_id), '10001', 'SITE', '10002', 'APP', '10003', 'RESP', '10005', 'SERVER', '10006', 'ORG', '10004', 'USER', '???' ) value_level,
              DECODE (TO_CHAR (pov.level_id), '10001', '', '10002', app.application_short_name, '10003', rsp.responsibility_key, '10005', svr.node_name, '10006', org.name, '10004', usr.user_name, '???' ) con,
              pov.profile_option_value val
            FROM apps.fnd_profile_options_vl po,
              apps.fnd_profile_option_values pov,
              apps.fnd_user usr,
              apps.fnd_application app,
              apps.fnd_responsibility rsp,
              apps.fnd_nodes svr,
              apps.hr_operating_units org
            WHERE 1                      = 1
            AND pov.application_id       = po.application_id
            AND pov.profile_option_id    = po.profile_option_id
            AND usr.user_id(+)           = pov.level_value
            AND rsp.application_id(+)    = pov.level_value_application_id
            AND rsp.responsibility_id(+) = pov.level_value
            AND app.application_id(+)    = pov.level_value
            AND svr.node_id(+)           = pov.level_value
            AND org.organization_id(+)   = pov.level_value
            AND po.profile_option_name LIKE 'ONT_DEFAULT_PERSON_ID'
            )
          WHERE value_level='APP';
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        v_salesrep_id:=NULL;
        dbms_output.put_line('422'||sqlerrm);
      END;
      
	  
	  
	  BEGIN
        IF (v_salesrep_id IS NULL) THEN
          SELECT val
          INTO v_salesrep_id
          FROM
            (SELECT po.profile_option_name value_name,
              po.user_profile_option_name,
              DECODE (TO_CHAR (pov.level_id), '10001', 'SITE', '10002', 'APP', '10003', 'RESP', '10005', 'SERVER', '10006', 'ORG', '10004', 'USER', '???' ) value_level,
              DECODE (TO_CHAR (pov.level_id), '10001', '', '10002', app.application_short_name, '10003', rsp.responsibility_key, '10005', svr.node_name, '10006', org.name, '10004', usr.user_name, '???' ) con,
              pov.profile_option_value val
            FROM apps.fnd_profile_options_vl po,
              apps.fnd_profile_option_values pov,
              apps.fnd_user usr,
              apps.fnd_application app,
              apps.fnd_responsibility rsp,
              apps.fnd_nodes svr,
              apps.hr_operating_units org
            WHERE 1                      = 1
            AND pov.application_id       = po.application_id
            AND pov.profile_option_id    = po.profile_option_id
            AND usr.user_id(+)           = pov.level_value
            AND rsp.application_id(+)    = pov.level_value_application_id
            AND rsp.responsibility_id(+) = pov.level_value
            AND app.application_id(+)    = pov.level_value
            AND svr.node_id(+)           = pov.level_value
            AND org.organization_id(+)   = pov.level_value
            AND po.profile_option_name LIKE 'ONT_DEFAULT_PERSON_ID'
            )
          WHERE value_level='SITE';
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        l_log_label := 'Sales Person Invalid' ;
        l_message   := 'Sales Person not found';
        xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_func_name || '.' || l_log_label , l_message, false);
        dbms_output.put_line('469'||sqlerrm);
      END;
    END;
    
	
	
	
	
	BEGIN
      
      SELECT currency_code
      INTO v_curr_code
      FROM fnd_currencies
      WHERE currency_code        =upper(p_order_head_rec.currency_code)
      AND (end_date_active      IS NULL
      OR TRUNC(end_date_active) >=TRUNC(p_order_head_rec.ordereddate));
      
    EXCEPTION
    WHEN OTHERS THEN
      l_log_label := 'Invalid Currency';
      l_message   := 'Currency Not Found';
      xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_func_name || '.' || l_log_label , l_message, false);
      
    END;
    
	
	
	BEGIN
      IF(p_order_head_rec.sales_agmnt_no IS NOT NULL) THEN
        SELECT order_number
        INTO v_bsa_num
        FROM oe_blanket_headers_all
        WHERE org_id               =p_order_head_rec.org_id
        AND transactional_curr_code=upper(p_order_head_rec.currency_code)
        AND order_number           =p_order_head_rec.sales_agmnt_no
        AND sold_to_org_id         =l_customer_id;
      END IF;
    EXCEPTION
    WHEN OTHERS THEN
      l_log_label := 'Sales Agreement Number Not found';
      l_message   := 'Sales Agreement Number Not found';
      xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_func_name || '.' || l_log_label , l_message, false);
      --raise error;
    END;
    
	
	BEGIN
      SELECT getpayment_term(p_order_head_rec.org_id,p_order_head_rec.currency_code,p_order_head_rec.sales_agmnt_no,l_customer_id, p_order_head_rec.payment_term,p_order_head_rec.order_source)
      INTO l_payment_term
      FROM dual;
    EXCEPTION
    WHEN OTHERS THEN
      l_log_label := 'Payment Term Invalid';
      l_message   := 'Payment Term Not Found';
      xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_func_name || '.' || l_log_label , l_message, false);
    END;
    
    
	
	BEGIN
      SELECT attribute1,
        attribute2,
        attribute15,     
        attribute5,
        attribute3,
        attribute4,
        attribute18,
        attribute6,
        attribute7,
        attribute8,
        attribute13,
        attribute16,
        attribute14
        
      INTO lv_attribute1,
        lv_attribute2,
        lv_attribute15,
        lv_attribute5,
        lv_attribute3,
        lv_attribute4,
        lv_attribute18,
        lv_attribute6,
        lv_attribute7,
        lv_attribute8,
        lv_attribute13,
        lv_attribute16,
        lv_attribute14
        

	FROM oe_order_headers_all
      WHERE orig_sys_document_ref=p_order_head_rec.return_order_reference
      AND org_id                 = p_order_head_rec.org_id; --added org_id defect#2848
    EXCEPTION
    WHEN OTHERS THEN
      lv_attribute1 :=NULL;
      lv_attribute2 :=NULL;
      lv_attribute15:=NULL;
      lv_attribute6 :=NULL;
      lv_attribute7 :=NULL;
      lv_attribute8 :=NULL;
      lv_attribute13:=NULL;
      lv_attribute16:=NULL;
      lv_attribute14:=NULL;
    END;
	
	
    
    BEGIN
      
      SELECT attribute10 ---contains 'Y' & null
      INTO lv_post_fix
      FROM oe_transaction_types_all
      WHERE transaction_type_id=v_order_type_id ;
      IF (lv_post_fix          ='Y')
        --(lv_type           ='M')
        THEN                                                                                           
        g_order_number :=p_order_head_rec.printed_order_number||xxcu.xxcu_ont_order_number_seq.nextval;
      ELSE
        
        g_order_number :=p_order_head_rec.printed_order_number;
        
      END IF;
    EXCEPTION
    WHEN OTHERS THEN
      
      g_order_number :=p_order_head_rec.printed_order_number;
      
    END;
	
	
    lv_payment_type_code:=NULL;
    
    
	BEGIN
      
	  BEGIN
        SELECT DECODE(DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute15,p_order_head_rec.payment_provider_trans_id), NULL,'N','','N','Y')
        INTO lv_flag
        FROM dual;
      EXCEPTION
      WHEN OTHERS THEN
        lv_flag:='N';
      END;
	  
      IF (upper(p_order_head_rec.prepayment_flag)='Y' AND upper(p_order_head_rec.order_type) ='REGULAR') THEN
        lv_payment_type_code                    :='XXCU_PREPAYMENT';
      ELSE
        IF (lv_flag='Y')
          
          THEN
          lv_payment_type_code:='XXCU_CREDIT_CARD';
        ELSE
          lv_payment_type_code:=NULL;
        END IF;
      END IF;
    END ;
	
	
   
*************************************************************************
****************************
    BEGIN
      lv_proj_flag                    :=NULL;
	  
      IF(p_order_head_rec.project_ref IS NOT NULL) THEN
        lv_proj_flag                  :=p_order_head_rec.project_ref;
      ELSE
        BEGIN
          SELECT attribute2
          INTO lv_proj_flag_bsa
          FROM oe_blanket_headers_all
          WHERE org_id               =p_order_head_rec.org_id
          AND transactional_curr_code=upper(p_order_head_rec.currency_code)
          AND order_number           =p_order_head_rec.sales_agmnt_no
          AND upper(attribute2)      ='SINGLE'
          AND sold_to_org_id         =l_customer_id;
        EXCEPTION
        WHEN OTHERS THEN
          lv_proj_flag_bsa:=NULL;
        END;
		
        IF(lv_proj_flag_bsa IS NOT NULL) THEN
          lv_proj_flag      :=l_orig_sys_document_ref;
        END IF;
      END IF;
	  
	  
	 
      IF(lv_proj_flag IS NULL) THEN
        
		BEGIN
          SELECT hca.attribute4
          INTO lv_proj_flag_site
          FROM hz_cust_acct_sites_all hca
          WHERE hca.cust_account_id=l_customer_id
          AND hca.org_id           =p_order_head_rec.org_id
          AND hca.status           ='A'
          AND hca.bill_to_flag ='P';
        EXCEPTION
        WHEN OTHERS THEN
          lv_proj_flag_site:=NULL;
        END;
		
		
		
        
        BEGIN
          SELECT hca.hz_cust_accounts
          INTO lv_proj_flag_acc
          FROM hz_cust_accounts hca
          WHERE hca.cust_account_id =l_customer_id
          AND hca.status ='A';
        EXCEPTION
        WHEN OTHERS THEN
          lv_proj_flag_acc:=NULL;
        END;
		
		
	
        BEGIN
          SELECT hp.attribute4
          INTO lv_proj_flag_party
          FROM hz_cust_accounts hca,
            hz_parties hp
          WHERE hca.cust_account_id=l_customer_id
          AND hp.party_id          =hca.party_id
          AND hca.status ='A';
        EXCEPTION
        WHEN OTHERS THEN
          lv_proj_flag_party:=NULL;
        END;
		
		
		
        IF(upper(lv_proj_flag_site)='SINGLE' AND lv_proj_flag_bsa IS NULL) THEN
          lv_proj_flag            :=l_orig_sys_document_ref;
        ELSE
          IF(upper(lv_proj_flag_acc)='SINGLE' AND( lv_proj_flag_site IS NOT NULL OR lv_proj_flag_bsa IS NOT NULL)) THEN
            lv_proj_flag           :=NULL;
          ELSE
            IF (upper(lv_proj_flag_acc)='SINGLE' AND( lv_proj_flag_site IS NULL AND lv_proj_flag_bsa IS NULL)) THEN
              lv_proj_flag            :=l_orig_sys_document_ref;
            ELSE
              IF (upper(lv_proj_flag_party) ='SINGLE' AND (lv_proj_flag_acc IS NOT NULL OR lv_proj_flag_bsa IS NOT NULL OR lv_proj_flag_site IS NOT NULL)) THEN
                lv_proj_flag               :=NULL;
              ELSE
                IF (upper(lv_proj_flag_party) ='SINGLE' AND (lv_proj_flag_acc IS NULL AND lv_proj_flag_bsa IS NULL AND lv_proj_flag_site IS NULL)) THEN
                  lv_proj_flag               :=l_orig_sys_document_ref;
                END IF;
              END IF;
            END IF;
          END IF;
        END IF;
	
      END IF;
    END;
	
	********************************************
*******************************************************************************************	
	
	
    BEGIN
     
	 IF(v_context>0) THEN
        dbms_output.put_line('v_context>0');
        
		INSERT
        INTO oe_headers_iface_all
          (
            operation_code,
            global_attribute1,--batch_id,
            pricing_date,
            conversion_type,
            deliver_to_customer_id,
            sold_to_org_id,
            invoice_to_org_id,
            ship_to_org_id,
            blanket_number,
            price_list_id,
            order_type_id,
            invoicing_rule_id,
            accounting_rule_id,
            orig_sys_document_ref,
            order_source_id,
            org_id,
            salesrep_id,
            transactional_curr_code,
            payment_type_code,
            last_update_date,
            ordered_date,
            creation_date,
            customer_po_number,
            attribute1,
            attribute14,
            booked_flag,
            tax_exempt_flag,
            context,
            attribute2,
            created_by,
            last_updated_by,
            conversion_rate_date,
            payment_term_id,
            attribute15,
            attribute5,
            attribute18,
            order_number,
            attribute3,
            attribute19,
            attribute4,
            attribute6,
            attribute7,
            attribute8,
            attribute13,
            attribute16,
            attribute11 
          )
          VALUES
          (
            l_operation,
            p_batch_id,
            lv_pricing_date,
            l_conversion_type,
            l_customer_id,
            l_customer_id,
            getsiteuseid (l_customer_id, 'BILL_TO',p_order_head_rec.org_id),
            getsiteuseid (l_customer_id, 'SHIP_TO',p_order_head_rec.org_id),
            p_order_head_rec.sales_agmnt_no,
            getpricelistid (DECODE(lv_new_curr_code,NULL,p_order_head_rec.currency_code,lv_new_curr_code)),
            v_order_type_id,
            NULL,
            NULL,
            l_orig_sys_document_ref,
            g_order_source_id,
            p_order_head_rec.org_id,
            v_salesrep_id,
            DECODE(lv_new_curr_code,NULL,p_order_head_rec.currency_code,lv_new_curr_code),
            lv_payment_type_code,
            sysdate,
            p_order_head_rec.ordereddate,
            sysdate,
            p_order_head_rec.po_reference,
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute1,p_order_head_rec.exclude_from_dunning),
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute14, p_order_head_rec.reserved_amount),
            'Y',
            'S',
            'TMS',
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute2,p_order_head_rec.charteque_number),
            g_user_id,
            g_user_id,
            lv_pricing_date,
            l_payment_term,
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute15,p_order_head_rec.payment_provider_trans_id),
            p_order_head_rec.message_to_customer, 
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute18,p_order_head_rec.agreement_name),
            g_order_number,
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute3,lv_proj_flag),
            p_order_head_rec.printed_order_number,
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute4,lv_attr4),
            lv_attr6 ,
            lv_attr7,
            lv_attr8,
            lv_attr13,
            lv_attr16,
            p_order_head_rec.invoice_kid
          );
     

	 ELSE
        --   dbms_output.put_line('v_context=0');
        INSERT
        INTO oe_headers_iface_all
          (
            operation_code,
            global_attribute1,--batch_id,
            pricing_date,
            conversion_type,
            deliver_to_customer_id,
            sold_to_org_id,
            invoice_to_org_id,
            ship_to_org_id,
            blanket_number,
            price_list_id,
            order_type_id,
            invoicing_rule_id,
            accounting_rule_id,
            orig_sys_document_ref,
            order_source_id,
            org_id,
            salesrep_id,
            transactional_curr_code,
            payment_type_code,
            last_update_date,
            ordered_date,
            creation_date,
            customer_po_number,
            attribute14,
            booked_flag,
            tax_exempt_flag,
            context,
            attribute15,
            attribute1,
            created_by,
            last_updated_by,
            conversion_rate_date,
            payment_term_id,
            attribute2,
            attribute5,
            attribute18,
            order_number,
            attribute3,
            attribute19,
            attribute4,
            attribute6,
            attribute7,
            attribute8,
            attribute13,
            attribute16,     
            attribute11 
          )
          VALUES
          (
            l_operation,            
            p_batch_id,
            lv_pricing_date,
            l_conversion_type,
            l_customer_id,
            l_customer_id,            
            getsiteuseid (l_customer_id, 'BILL_TO',p_order_head_rec.org_id),
            getsiteuseid (l_customer_id, 'SHIP_TO',p_order_head_rec.org_id),
            p_order_head_rec.sales_agmnt_no,
            getpricelistid (DECODE(lv_new_curr_code,NULL,p_order_head_rec.currency_code,lv_new_curr_code)),
            v_order_type_id,
            NULL,
            NULL,
            l_orig_sys_document_ref,
            g_order_source_id,
            p_order_head_rec.org_id,
            v_salesrep_id,
            DECODE(lv_new_curr_code,NULL,p_order_head_rec.currency_code,lv_new_curr_code),            
            lv_payment_type_code,            
            sysdate,
            p_order_head_rec.ordereddate,
            sysdate,
            p_order_head_rec.po_reference,
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute14, p_order_head_rec.reserved_amount),
            'Y',
            'S',
            lv_context,
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute15,p_order_head_rec.payment_provider_trans_id),            
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute1,p_order_head_rec.exclude_from_dunning),            
            g_user_id,
            g_user_id,
            lv_pricing_date,
            l_payment_term,
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute2,lv_attr2),            
            p_order_head_rec.message_to_customer, 
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute18,p_order_head_rec.agreement_name),
            g_order_number,            
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute3,lv_proj_flag),            
            p_order_head_rec.printed_order_number,
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute4,lv_attr4),            
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute6,lv_attr6),
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute7,lv_attr7),
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute8,lv_attr8),
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute13,lv_attr13),
            DECODE(upper(p_order_head_rec.order_type),'RETURN',lv_attribute16,lv_attr16),
            p_order_head_rec.invoice_kid 
          );
		  
      END IF;
      l_log_label := 'Insert into header interface failed';
      l_message   := 'Insert into header interface failed';
      xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_func_name || '.' || l_log_label , l_message || sqlerrm, false);
      xxcu_common_log_rt.msglog ('INFO', 'Error in insert of lines'||sqlerrm||dbms_utility.format_error_backtrace, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
    END;
 ***************************************************************************
*********************************************** 
    IF(p_order_head_rec.prepayment_flag='Y' AND p_order_head_rec.payment_provider_trans_id IS NULL AND upper(p_order_head_rec.order_type)='REGULAR') THEN
      c                               :=c+1;
      ln_amount                       :=p_amount;
	  
      BEGIN
        
		
		BEGIN
          SELECT fpovv.profile_option_value
          INTO lv_receipt_method
          FROM fnd_profile_options_vl fpov,
            fnd_profile_option_values fpovv
          WHERE user_profile_option_name='XXCU: Payment methods for payment from PREPAYMENT'
          AND fpov.profile_option_id    =fpovv.profile_option_id ;
        EXCEPTION
        WHEN OTHERS THEN
          lv_receipt_method:=NULL;
        END;
		
        mo_global.init('AR');
        mo_global.set_policy_context('S',p_order_head_rec.org_id);
        
		SELECT responsibility_id,
          application_id
        INTO ln_resp_id,
          ln_app_id
        FROM fnd_responsibility_vl
        WHERE responsibility_name = 'PB AR Super User';
        fnd_global.apps_initialize(g_user_id, ln_resp_id, ln_app_id);
        
		SELECT DECODE(lv_new_curr_code,NULL,p_order_head_rec.currency_code,lv_new_curr_code)
        INTO lv_rec_curr_code
        FROM dual;
        
        
		
		BEGIN
          SELECT gso.currency_code
          INTO lv_curr_code
          FROM hr_operating_units hou,
            gl_sets_of_books gso
          WHERE gso.set_of_books_id=hou.set_of_books_id
          AND hou.organization_id  =p_order_head_rec.org_id;
        EXCEPTION
        WHEN OTHERS THEN
          lv_curr_code:=NULL;
        END;
		
        IF(lv_curr_code<>p_order_head_rec.currency_code) THEN
          l_conversion_type:='Corporate';
        ELSE
          l_conversion_type:=NULL;
        END IF;
		
		
               
		
		BEGIN
          SELECT arm.remit_bank_acct_use_id
          INTO ln_remit_bank
          FROM ar_receipt_method_accounts_all arm,
            ar_receipt_methods armm,
            ce.ce_bank_accounts cba,
            ce.ce_bank_acct_uses_all cbau
            
          WHERE armm.receipt_method_id=arm.receipt_method_id
          AND cbau.bank_acct_use_id=arm.remit_bank_acct_use_id
          AND cbau.bank_account_id =cba.bank_account_id
          AND arm.org_id           =p_order_head_rec.org_id
          AND cba.currency_code    =p_order_head_rec.currency_code          
          AND armm.receipt_method_id =lv_receipt_method;
        EXCEPTION
        WHEN OTHERS THEN
          ln_remit_bank:=NULL;
        END;
		
		
        IF(ln_remit_bank IS NULL) THEN
          
		  
		  BEGIN
            SELECT cbau.bank_acct_use_id
            INTO ln_remit_bank
            FROM ce.ce_bank_accounts cba,
              ce.ce_bank_acct_uses_all cbau
            WHERE bank_account_name LIKE '%AR%'
            AND cbau.bank_account_id           =cba.bank_account_id
            AND cbau.org_id                    =p_order_head_rec.org_id
            AND cba.multi_currency_allowed_flag='Y';
          EXCEPTION
          WHEN OTHERS THEN
            ln_remit_bank:=NULL;
            xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error while deriving bank account for prepayment ' || sqlerrm );
            p_status_code  := 2;
            p_error_message:='Error while deriving bank account for prepyment'||sqlerrm||dbms_utility.format_error_backtrace;
          END;
		  
        END IF;
		
		
        ar_prepayments_pub.create_prepayment( p_api_version =>1.0, p_init_msg_list => fnd_api.g_false, p_commit =>fnd_api.g_false, p_validation_level => fnd_api.g_valid_level_full, x_return_status =>lv_return_status, x_msg_count =>ln_msg_count, x_msg_data =>lv_msg_data,
        p_usr_currency_code => p_order_head_rec.currency_code

        p_currency_code => p_order_head_rec.currency_code, p_usr_exchange_rate_type => l_conversion_type, p_exchange_rate_type => NULL, p_exchange_rate => NULL, p_exchange_rate_date => NULL, p_amount => ln_amount, p_factor_discount_amount => NULL,
        p_receipt_number =>ln_receipt_num , p_receipt_date =>sysdate, p_gl_date =>sysdate, p_maturity_date =>NULL, p_postmark_date => NULL, p_customer_id =>l_customer_id, p_customer_name => NULL, p_customer_number =>NULL, p_customer_bank_account_id =>NULL, p_customer_bank_account_num =>NULL, p_customer_bank_account_name=> NULL, p_location => NULL, p_customer_site_use_id =>getsiteuseid (l_customer_id, 'BILL_TO',p_order_head_rec.org_id), p_customer_receipt_reference =>NULL, p_override_remit_account_flag =>NULL, p_remittance_bank_account_id =>ln_remit_bank, p_remittance_bank_account_num => NULL, p_remittance_bank_account_name => NULL, p_deposit_date => NULL, p_receipt_method_id =>lv_receipt_method, p_receipt_method_name => NULL, p_doc_sequence_value => NULL, p_ussgl_transaction_code => NULL, p_anticipated_clearing_date => NULL, p_called_from => NULL, p_attribute_rec => ar_receipt_api_pub.attribute_rec_const,
        p_global_attribute_rec => ar_receipt_api_pub.global_attribute_rec_const, p_receipt_comments => NULL,
        p_issuer_name => NULL, p_issue_date => NULL, p_issuer_bank_branch_id => NULL,
        p_cr_id =>ln_cash_receipt_id,
        p_applied_payment_schedule_id =>-7, p_amount_applied => NULL, p_application_ref_type =>'OM', p_application_ref_id =>ln_application_ref_id , p_application_ref_num =>l_orig_sys_document_ref, p_secondary_application_ref_id => ln_sec_application_ref_id, p_receivable_trx_id =>NULL, p_amount_applied_from =>NULL, p_apply_date => NULL, p_apply_gl_date =>NULL, app_ussgl_transaction_code => NULL, p_show_closed_invoices => 'FALSE', p_move_deferred_tax =>'Y', app_attribute_rec => ar_receipt_api_pub.attribute_rec_const,
        app_global_attribute_rec => ar_receipt_api_pub.global_attribute_rec_const, app_comments => NULL,
        p_payment_server_order_num =>ln_payment_server_order_num, p_approval_code =>lv_approval_code,
        p_call_payment_processor => fnd_api.g_true, p_payment_response_error_code =>lv_payment_response_error_code,
        p_receivable_application_id =>ln_receivable_application_id, p_payment_set_id => ln_payment_set_id, p_org_id =>p_order_head_rec.org_id, p_payment_trxn_extension_id =>NULL );
 
		SELECT DISTINCT payment_set_id
        INTO ln_payment_set_id
        FROM ar_receivable_applications_all
        WHERE cash_receipt_id =ln_cash_receipt_id
        AND payment_set_id   IS NOT NULL;
		
        initialize_variables(p_order_head_rec.org_id);
        
		
		INSERT
        INTO ont.oe_payments_iface_all
          (
            order_source_id ,
            orig_sys_document_ref,
            orig_sys_payment_ref,
            org_id ,
            receipt_method_id,
            payment_collection_event ,
            payment_set_id ,
            prepaid_amount ,
            payment_amount ,
            creation_date,
            created_by ,
            last_update_date ,
            last_updated_by ,
            payment_number ,
            defer_payment_processing_flag,
            payment_type_code,
            sold_to_org_id
            )
          VALUES
          (
            g_order_source_id,
            l_orig_sys_document_ref,
            l_orig_sys_document_ref,
            p_order_head_rec.org_id,
            lv_receipt_method,
            'PREPAY',
            ln_payment_set_id,
            p_amount,
            p_amount,
            sysdate,
            g_user_id,
            sysdate,
            g_user_id,
            c,
            'N',
            'CASH',
            l_customer_id
           );

		   EXCEPTION
      WHEN OTHERS THEN
        xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled errors in the insertion of o_payments_iface_all  ::Contact your system administrator:: ' || sqlerrm );
        dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
        p_status_code  := 2;
        p_error_message:=sqlerrm||dbms_utility.format_error_backtrace;
      END;
	  
	  
    END IF;
    RETURN l_orig_sys_document_ref;
  EXCEPTION
  WHEN OTHERS THEN
    xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled errors in the inauguration of the oe_headers_iface_all ( ' || p_order_head_rec.customer_number || ') ::Contact your system administrator:: ' || sqlerrm );
    dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
    p_status_code  := 2;
    p_error_message:=sqlerrm||dbms_utility.format_error_backtrace;
  END;