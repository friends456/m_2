
createorderline_interface 
(p_batch_order.v_order_head (hi),
p_batch_order.v_order_head (hi).orderlines (li),
v_header_id, 
p_batch_order.v_order_head (hi).order_reference, 
p_batch_order.v_order_head (hi).currency_code,
p_batch_order.v_order_head (hi).sales_agmnt_no,
getcustomer_id (p_batch_order.v_order_head (hi).customer_number),
p_status_code, 
v_num_orderlines,
 v_upd_orig_sys_line_ref --1161
,p_batch_order.v_order_head (hi).org_id,
lv_price_date,
p_batch_order.v_order_head (hi).order_type,
p_error_message);



PROCEDURE createorderline_interface
    (
      p_order_head_rec        IN xxcu_ont_create_order_parser.orderhead_rec, --/*Version added Kavita 1.30 CR#2499*/
      p_order_line_rec        IN xxcu_ont_create_order_parser.orderline_rec,
      p_header_id             IN NUMBER,
      p_orig_sys_document_ref IN VARCHAR2,
      p_curr_code             IN VARCHAR2,
      p_agreement_num         IN VARCHAR2,
      p_cust_id               IN NUMBER,
      p_status_code           IN OUT NUMBER,
      p_num_orderlines        IN OUT NUMBER, ---
      p_orig_sys_line_ref     IN OUT VARCHAR2,---
      p_org_id                IN NUMBER,
      p_pricing_date          IN DATE,--
      p_order_type            IN VARCHAR2,
      p_error_message OUT VARCHAR2
    )
  AS
    l_line_id         NUMBER;
    ln_customer_id    NUMBER; --/*Version added New variable Kavita 1.30 CR#2499*/
    lv_list_header_id NUMBER;
    lv_list_line_id   NUMBER;
    lv_change_code    VARCHAR2(100);
    lv_change_reason  VARCHAR2(200);
    --l_quantityOM            NUMBER;
    --l_quantityLM            NUMBER;
    l_operation             VARCHAR2 ( 50 ) ;
    l_payment_term          NUMBER;
    l_upd_orig_sys_line_ref VARCHAR2 (50);
    v_country_from          VARCHAR2(20);
    v_country_to            VARCHAR2(20);
    l_price_id              NUMBER;
    l_inventory_item_id     NUMBER;
    l_intf_count            NUMBER := 0;
    lv_tax_code             VARCHAR2(100);
    --  PRAGMA AUTONOMOUS_TRANSACTION;
    l_prog_loc          VARCHAR2 (100) := 'init';
    l_inventory_number  VARCHAR2 (100);
    l_calcualte_price   VARCHAR2 (50);
    lv_price_flag       VARCHAR2(50);
    l_accounting_string VARCHAR2 (50);
    l_return_reason     VARCHAR2 (100);
    k_proc_name         VARCHAR2(100):='createorderline_interface';
    l_log_label         VARCHAR2(2000);
    l_message           VARCHAR2(2000);
    v_uom               VARCHAR2(80);
    v_salesrep          VARCHAR2(200);
    ---start 10.03.2016
    v1_salesrep_id        NUMBER:=NULL;
    lv_org_name           VARCHAR2(100);
    ln_user_id            NUMBER;
    v_context             VARCHAR2(100);
    v_return_attribute1   VARCHAR2(80);
    g_user_id             NUMBER;
    lv_attribute10        VARCHAR2(240);
    lv_attribute4         VARCHAR2(240);
    lv_attribute5         VARCHAR2(240);
    lv_attribute6         VARCHAR2(240);
    lv_attribute7         VARCHAR2(240);
    lv_attribute2         VARCHAR2(240);
    lv_attribute8         VARCHAR2(240);
    lv_attribute3         VARCHAR2(240);
    lv_attribute12        VARCHAR2(240);
    lv_attribute17        VARCHAR2(240);--defect 5398
    lv_curr_code          VARCHAR2(100);
    ln_curr_rate          NUMBER;
    ln_unit_selling_price NUMBER;
    lv_credit_card        VARCHAR2(150);
    lv_header_curr        VARCHAR2(40);
    lv_new_curr_code      VARCHAR2(100);
    ln_unit_list_price    NUMBER;
    ln_tax_value          NUMBER;
    e_no_salesper         EXCEPTION ;
    lv_receipt_method     VARCHAR2(60);
    lv_context_value      VARCHAR2(200);
    lv_attr3              VARCHAR2(240);
    lv_attr6              VARCHAR2(240);
    lv_attr8              VARCHAR2(240);
    lv_attr12             VARCHAR2(240);
    lv_attr14             VARCHAR2(240);
    lv_attr2              VARCHAR2(240);
    ln_cnt_desc           NUMBER:=0;
    ln_salesrep_return    NUMBER;
    lv_item               VARCHAR2(100);
    ln_inventory_item_id  NUMBER;
    lv_uom                VARCHAR2(80);
    ln_unit_price_ret     NUMBER;
    ln_tax                NUMBER;
    ln_selling_price_ret  NUMBER;
    ln_cust_count         NUMBER;
    lv_modifier           VARCHAR2(200);
    lv_return_flag_found  VARCHAR2(10):='TRUE';
    l_transaction_id      NUMBER;
    ln_adjust_amt_ret     NUMBER;
    ln_list_header_id_ret NUMBER;
    ln_list_line_id_ret   NUMBER;
    lv_uom_flag           VARCHAR2(10):='TRUE';
    ln_warehouse_id       NUMBER;
    ln_trans_type         NUMBER;
    lv_sales_yes_no       VARCHAR2(20);
    ln_order_source_id    NUMBER;
    lv_attr16             VARCHAR2(240);
    lv_attribute16        VARCHAR2(240);
    -- p_error_message       VARCHAR2(2000);
    --end
  BEGIN
    ln_unit_list_price    :=NULL;
    ln_tax_value          :=NULL;
    ln_unit_selling_price :=NULL;
    lv_new_curr_code      :=NULL;
    l_prog_loc            := 'getline_id';
    /* start wave 2 modification */
   


   BEGIN
      ln_trans_type:= get_transaction_type_id(p_order_head_rec.order_source, p_order_head_rec.order_type, p_order_head_rec.org_id, p_status_code, p_error_message);
      xxcu_common_log_rt.msglog ('INFO', 'transaction type id '||ln_trans_type, 1117, '1', 'get_transaction_type_id', '-1' );
    EXCEPTION
    WHEN OTHERS THEN
      xxcu_common_log_rt.msglog ('ERR', 'Failed to derive transaction type id 3 '||sqlerrm||dbms_utility.format_error_backtrace, 1117, '1', 'get_transaction_type_id', '-1' );
      ln_trans_type :=NULL;
    END;
	
	
	
    BEGIN
      SELECT warehouse_id
      INTO ln_warehouse_id
      FROM oe_transaction_types_all
      WHERE transaction_type_id= ln_trans_type;
      xxcu_common_log_rt.msglog ('INFO', 'warehouse id '||ln_warehouse_id, 1117, '1', 'get_transaction_type_id', '-1' );
    EXCEPTION
    WHEN OTHERS THEN
      ln_warehouse_id:=NULL;
    END;
	
	
	
	
    
    BEGIN
      
      xxcu_common_log_rt.msglog ('INFO', 'g_order_source_id'||g_order_source_id, 1117, '1', 'getinventory_item_id', '-1' );
      
	  
	  l_inventory_item_id := getinventory_item_id (p_order_line_rec.itemno,p_order_head_rec.order_source,p_order_head_rec.order_type,ln_warehouse_id);
      xxcu_common_log_rt.msglog ('INFO', 'inventory item id '||l_inventory_item_id, 1117, '1', 'getinventory_item_id', '-1' );
	  
    EXCEPTION
    WHEN OTHERS THEN
      l_inventory_item_id:=NULL;
    END;
	
	
  
    IF p_order_line_rec.ret_orderlineidsource IS NOT NULL THEN
      l_line_id := getline_id (p_header_id,p_order_line_rec.ret_orderlineidsource,p_org_id);
    ELSE
      l_line_id := NULL;
    END IF;
	
	
    
    BEGIN
      ln_customer_id := getcustomer_id (p_order_head_rec.customer_number);
    EXCEPTION
    WHEN OTHERS THEN
      ln_customer_id:=NULL;
    END;
	
	
    
    l_prog_loc := 'select count';
    
    BEGIN
      l_inventory_number    := getinventory_number (p_order_head_rec.order_source,p_order_head_rec.order_type,l_inventory_item_id,p_org_id); 
      IF(l_inventory_number IS NULL) THEN
        l_inventory_number  :=p_order_line_rec.itemno;
      END IF;
    EXCEPTION
    WHEN OTHERS THEN
      l_inventory_number:=p_order_line_rec.itemno;
    END;
    
    BEGIN
      SELECT NVL(upper(ffvv.attribute12),'N')
      INTO lv_price_flag
      FROM fnd_flex_value_sets ffvs,
        fnd_flex_values ffvv
      WHERE ffvs.flex_value_set_name='XXCU_OM_SOURCE_ORDER_TYPE'
      AND ffvs.flex_value_set_id    =ffvv.flex_value_set_id
      AND upper(ffvv.flex_value)    =upper(p_order_head_rec.order_source);
    EXCEPTION
    WHEN OTHERS THEN
      lv_price_flag:='N';
    END;
	
	
	
    IF (lv_price_flag='Y' AND p_order_line_rec.unit_list_price IS NULL OR p_order_line_rec.unit_selling_price IS NULL) THEN
      l_calcualte_price := 'Y';
    ELSE
      l_calcualte_price := 'N';
    END IF;
	dbms_output.put_line('l_line_id'|| l_line_id);
	
	
	
    BEGIN
      SELECT name
      INTO lv_org_name
      FROM hr_operating_units
      WHERE organization_id=p_org_id;
	  
      SELECT userid
      INTO g_user_id
      FROM xxcu_int_init_app_logons
      WHERE procedure_name   =upper('XXCU_ONT_CREATE_ORDER_PKG')
      AND operating_unit_name=lv_org_name;
    EXCEPTION
    WHEN OTHERS THEN
      g_user_id :=fnd_global.user_id;
    END;
	
	
    BEGIN
      SELECT lookup_code
      INTO l_return_reason
      FROM apps.fnd_lookup_values lv
      WHERE lv.language     = userenv('LANG')
      AND upper(lv.meaning) = upper(p_order_line_rec.reason_code)
      AND lookup_type       ='CREDIT_MEMO_REASON';
    EXCEPTION
    WHEN OTHERS THEN
      l_return_reason:='NO REASON';
      dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
    END;
	
	
	
    BEGIN
      SELECT DISTINCT ooha.header_id
      INTO v_return_attribute1
      FROM oe_order_headers_all ooha,
        oe_order_lines_all oola
      WHERE ooha.header_id      =oola.header_id
      AND oola.orig_sys_line_ref=p_order_line_rec.ret_orderlineidsource
      AND oola.header_id=p_header_id
      AND ooha.org_id = p_org_id;
    EXCEPTION
    WHEN OTHERS THEN
      v_return_attribute1:=NULL;
    END;
	

    dbms_output.put_line('l_return_reason'|| l_return_reason);
	
	
    BEGIN

	l_operation := 'INSERT'; 

	l_prog_loc          := 'insert into';
      p_num_orderlines    := p_num_orderlines + 1;
      p_orig_sys_line_ref := p_order_line_rec.orderlineidsource; 
	  
	  
      BEGIN
        ln_trans_type:= get_transaction_type_id(p_order_head_rec.order_source, p_order_head_rec.order_type, p_order_head_rec.org_id, p_status_code, p_error_message);
      EXCEPTION
      WHEN OTHERS THEN
        xxcu_common_log_rt.msglog ('ERR', 'Failed to derive transaction type id 4 '||sqlerrm||dbms_utility.format_error_backtrace, 1117, '1', 'get_transaction_type_id', '-1' );
        ln_trans_type:=NULL;
      END;
	  
	  
      BEGIN
        SELECT warehouse_id
        INTO ln_warehouse_id
        FROM oe_transaction_types_all
        WHERE transaction_type_id= ln_trans_type;
      EXCEPTION
      WHEN OTHERS THEN
        ln_warehouse_id:=NULL;
      END;
	  
	  
      
      BEGIN
        dbms_output.put_line(l_inventory_item_id || p_org_id);


        BEGIN
          SELECT COUNT(tax_rate_code)
          INTO ln_tax
          FROM zx_rates_b
          WHERE tax_rate_code=p_order_line_rec.tax_code
          AND effective_to  IS NULL
          AND active_flag    ='Y';
        EXCEPTION
        WHEN OTHERS THEN
          ln_tax:=0;
        END;
		
		
		
        IF(ln_tax=0) THEN
          BEGIN
            SELECT tag
            INTO lv_tax_code
            FROM fnd_lookup_values_vl
            WHERE lookup_type    ='PB_TAX_CODE_MAPPING'
            AND lookup_code      =p_order_line_rec.tax_code
            AND end_date_active IS NULL
            AND enabled_flag     ='Y';
          EXCEPTION
          WHEN OTHERS THEN
            lv_tax_code :=NULL;
          END;		  
		  
        ELSE
          lv_tax_code:=p_order_line_rec.tax_code;
        END IF;
		
      END;

      BEGIN
        SELECT warehouse_id
        INTO ln_warehouse_id
        FROM oe_transaction_types_all
        WHERE transaction_type_id= ln_trans_type;
      EXCEPTION
      WHEN OTHERS THEN
        ln_warehouse_id:=NULL;
      END;

      BEGIN
        SELECT ffvv.attribute11
        INTO lv_context_value
        FROM fnd_flex_value_sets ffvs,
          fnd_flex_values ffvv
        WHERE ffvs.flex_value_set_name='XXCU_OM_SOURCE_ORDER_TYPE'
        AND ffvs.flex_value_set_id    =ffvv.flex_value_set_id
        AND upper(ffvv.flex_value)    =upper(p_order_head_rec.order_source);
      EXCEPTION
      WHEN OTHERS THEN
        --xxcu_log_pkg.LOG (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled errors in the xxcu_invoice_spec_p > ::Contact your system administrator:: ' || SQLERRM );
        lv_context_value:=NULL;
      END;
	  
	  
      BEGIN
        SELECT COUNT(*)
        INTO ln_cnt_desc
        FROM fnd_descr_flex_contexts_vl
        WHERE descriptive_flex_context_name=lv_context_value
        AND descriptive_flexfield_name     ='OE_LINE_ATTRIBUTES';
      EXCEPTION
      WHEN OTHERS THEN
        ln_cnt_desc:=0;
      END;
	  
      --xxcu_common_log_rt.msglog ('INFO', 'lv context value  '||lv_context_value, 1117, '1', 'lv context value', '-1' );
      IF(lv_context_value IS NULL OR ln_cnt_desc=0) THEN
       
	   BEGIN
          SELECT DECODE(item_type,NULL,NULL,'TMS')
          INTO lv_context_value
          FROM mtl_system_items
          WHERE inventory_item_id=l_inventory_item_id
          AND item_type         IN
            (SELECT ffvv.flex_value
            FROM fnd_flex_value_sets ffvs,
              fnd_flex_values_vl ffvv
            WHERE ffvs.flex_value_set_name = 'XXCU_OM_TAX_ITEM_TYPE'
            AND ffvs.flex_value_set_id     =ffvv.flex_value_set_id
            )
          AND organization_id =ln_warehouse_id;
        EXCEPTION
        WHEN OTHERS THEN
          lv_context_value:=NULL;
        END;
      END IF;
	  
	  
      IF(p_order_line_rec.unit_weight IS NOT NULL) THEN
        lv_attr3                      :=p_order_line_rec.unit_weight;
      ELSE
        lv_attr3:=p_order_line_rec.ship_to;
      END IF;
	  
	  
	  
      IF(p_order_line_rec.price_zone IS NOT NULL) THEN
        lv_attr8                     :=p_order_line_rec.price_zone;
      END IF;
	  
	  
      IF(p_order_line_rec.gift_recipient IS NOT NULL) THEN
        lv_attr12                        :=p_order_line_rec.gift_recipient;
      ELSE
        lv_attr12 :=p_order_line_rec.assignment_number;
      END IF;
	  
	  
      IF(p_order_line_rec.gift_ship_to IS NOT NULL) THEN
        lv_attr14                      :=p_order_line_rec.gift_ship_to;
      END IF;
	  
	  
      IF(p_order_line_rec.weight_group IS NOT NULL) THEN
        lv_attr2                       :=p_order_line_rec.weight_group;
      END IF;
	  
	  
      IF(p_order_line_rec.combination_id IS NOT NULL) THEN
        lv_attr16                        :=p_order_line_rec.combination_id;
      END IF;
	  
	  
      
      BEGIN
        SELECT NVL(ffvv.attribute7,'N')
        INTO lv_sales_yes_no
        FROM fnd_flex_value_sets ffvs,
          fnd_flex_values ffvv
        WHERE ffvs.flex_value_set_name='XXCU_OM_SOURCE_ORDER_TYPE'
        AND ffvs.flex_value_set_id    =ffvv.flex_value_set_id
        AND upper(ffvv.flex_value)    =upper(p_order_head_rec.order_source);
      EXCEPTION
      WHEN OTHERS THEN
        lv_sales_yes_no := 'N';
      END;
      
	  
	  IF(lv_sales_yes_no='N') THEN
        
		BEGIN
          SELECT salesrep_id
          INTO ln_salesrep_return
          FROM oe_order_lines_all
          WHERE 1=1
          AND orig_sys_line_ref=p_order_line_rec.ret_orderlineidsource
          AND header_id=p_header_id
          AND org_id = p_org_id;
        EXCEPTION
        WHEN no_data_found THEN
          v_salesrep := upper(p_order_line_rec.salesperson);
        END ;
		
        BEGIN
          SELECT salesrep_id
          INTO v1_salesrep_id
          FROM jtf.jtf_rs_salesreps
            
          WHERE upper(salesrep_number)=upper(p_order_line_rec.salesperson) 
          AND org_id                  =p_org_id;                          
        EXCEPTION
        WHEN no_data_found THEN
          v_salesrep := upper(p_order_line_rec.salesperson);
      END IF;
	  
	  
	  
      BEGIN
        ln_trans_type:= get_transaction_type_id(p_order_head_rec.order_source, p_order_head_rec.order_type, p_order_head_rec.org_id, p_status_code, p_error_message);
      EXCEPTION
      WHEN OTHERS THEN
        xxcu_common_log_rt.msglog ('ERR', 'Failed to derive transaction type id 5 '||sqlerrm||dbms_utility.format_error_backtrace, 1117, '1', 'get_transaction_type_id', '-1' );
        ln_trans_type:=NULL;
      END;
	  
	  
      BEGIN
        SELECT warehouse_id
        INTO ln_warehouse_id
        FROM oe_transaction_types_all
        WHERE transaction_type_id=ln_trans_type;
      EXCEPTION
      WHEN OTHERS THEN
        ln_warehouse_id:=NULL;
      END;
	  
	  
      BEGIN
       
        SELECT primary_uom_code
        INTO v_uom
        FROM mtl_system_items_b
        WHERE inventory_item_id    =l_inventory_item_id
        AND enabled_flag           ='Y'
        AND organization_id        =ln_warehouse_id
        AND (end_date_active      IS NULL
        OR TRUNC(end_date_active) >=TRUNC(sysdate));
      EXCEPTION
      WHEN OTHERS THEN
        v_uom      :=NULL;
        lv_uom_flag:='FALSE';
      END;
      
      IF(p_order_line_rec.country_code_from IS NOT NULL) THEN
        BEGIN
          SELECT territory_code
          INTO v_country_from
          FROM fnd_territories_vl
          WHERE upper(territory_code)=upper(p_order_line_rec.country_code_from);
        EXCEPTION
        WHEN OTHERS THEN
          l_log_label := 'Invalid Country';
          l_message   := 'From Country Not Found';
          xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_proc_name || '.' || l_log_label , l_message, false);
        END;
      END IF;
	  
	  
      IF(p_order_line_rec.country_code_from IS NOT NULL) THEN
        BEGIN
          SELECT territory_code
          INTO v_country_to
          FROM fnd_territories_vl
          WHERE upper(territory_code)=upper(p_order_line_rec.country_code_to);
        EXCEPTION
        WHEN OTHERS THEN
          l_log_label := 'Invalid Country';
          l_message   := 'To Country Not Found';
          xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_proc_name || '.' || l_log_label , l_message, false);
        END;
      END IF;
	  
	  
      lv_return_flag_found:='TRUE';

      BEGIN
        SELECT attribute10,
          attribute4,
          attribute5,
          attribute6,
          attribute7,
          attribute2,
          attribute3,
          ordered_item,
          inventory_item_id,
          order_quantity_uom,
          unit_list_price,
          unit_selling_price,         
          attribute8,
          attribute12,
          attribute16,
          attribute17

		  INTO lv_attribute10,
          lv_attribute4,
          lv_attribute5,
          lv_attribute6,
          lv_attribute7,
          lv_attribute2,
          lv_attribute3,
          lv_item,
          ln_inventory_item_id,
          lv_uom,
          ln_unit_price_ret,
          ln_selling_price_ret,
          lv_attribute8 ,
          lv_attribute12,
          lv_attribute16,
          lv_attribute17
        FROM oe_order_lines_all
        WHERE 1=1
        AND orig_sys_line_ref=p_order_line_rec.ret_orderlineidsource
        AND header_id=p_header_id
        AND org_id = p_org_id; 
		
      EXCEPTION
      WHEN OTHERS THEN
        lv_return_flag_found:='FALSE';
        lv_attribute10      :=NULL;
        lv_attribute4       :=NULL;
        lv_attribute5       :=NULL;
        lv_attribute6       :=NULL;
        lv_attribute7       :=NULL;
        lv_attribute3       :=NULL;
        lv_item             :=NULL;
        ln_inventory_item_id:=NULL;
        lv_uom              :=NULL;
        ln_unit_price_ret   :=NULL;
        ln_selling_price_ret:=NULL;
        lv_attribute2       :=NULL;
        lv_attribute16      :=NULL;
        lv_attribute17      :=NULL;
      END;
      
      BEGIN
        SELECT gso.currency_code
        INTO lv_curr_code
        FROM hr_operating_units hou,
          gl_sets_of_books gso
        WHERE gso.set_of_books_id=hou.set_of_books_id
        AND hou.organization_id  =p_org_id;
      EXCEPTION
      WHEN OTHERS THEN
        lv_curr_code:=NULL;
      END;
	  
      BEGIN
        SELECT attribute15 ,
          transactional_curr_code
        INTO lv_credit_card,
          lv_header_curr
        FROM oe_headers_iface_all
        WHERE orig_sys_document_ref=p_orig_sys_document_ref;
      EXCEPTION
      WHEN OTHERS THEN
        lv_credit_card:=NULL;
        lv_header_curr:=NULL;
      END;
	  
	  
      IF(get_currencycode(p_cust_id,p_org_id) IS NOT NULL AND lv_credit_card IS NULL AND p_curr_code=lv_curr_code) THEN
        lv_new_curr_code :=get_currencycode(p_cust_id,p_org_id);
		
		
        BEGIN
          SELECT conversion_rate
          INTO ln_curr_rate
          FROM gl_daily_rates
          WHERE from_currency       =lv_curr_code
          AND to_currency           =lv_new_curr_code
          AND TRUNC(conversion_date)= TRUNC(p_pricing_date)
          AND conversion_type       ='Corporate';
        EXCEPTION
        WHEN OTHERS THEN
          ln_curr_rate :=1 ;
        END;
		
		ln_unit_selling_price:=ln_curr_rate* p_order_line_rec.unit_selling_price;
        ln_unit_list_price   :=ln_curr_rate* p_order_line_rec.unit_list_price;
        ln_tax_value         :=ln_curr_rate* p_order_line_rec.tax_value;
      END IF;
	  
	  
	  
      BEGIN
        SELECT getpayment_term(p_org_id,DECODE(lv_new_curr_code, NULL,p_curr_code,lv_new_curr_code),p_agreement_num,p_cust_id, p_order_head_rec.payment_term, p_order_head_rec.order_source
          )
        INTO l_payment_term
        FROM dual;
        IF(l_payment_term IS NULL) THEN
          l_log_label     := 'Payment Term Invalid';
          l_message       := 'Payment Term Not Found';
          xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_proc_name || '.' || l_log_label , l_message, false);
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        l_log_label := 'Payment Term Invalid';
        l_message   := 'Payment Term Not Found';
        xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_proc_name || '.' || l_log_label , l_message, false);
      END;
	  
	  
	  
      
      -------------------checkng if lv_context_value is not null and return order line id is null means regular order with TMS context-----------------
      IF(lv_context_value IS NOT NULL AND p_order_line_rec.ret_orderlineidsource IS NULL) THEN
        
		BEGIN
          INSERT
          INTO oe_lines_iface_all
            (
              order_source_id,
              org_id,
              sold_to_org_id,
              line_id,
              orig_sys_document_ref,
              orig_sys_line_ref,
              link_to_line_ref,
              top_model_line_ref,
              order_quantity_uom,
              unit_list_price,
              unit_selling_price,
              tax,
              customer_item_net_price,
              tax_value,
              calculate_price_flag,
              created_by,
              last_updated_by,
              inventory_item_id,
              ordered_quantity,
              context,
              attribute10,
              attribute4,
              attribute5,
              attribute6,
              attribute7,
              operation_code,
              creation_date,
              last_update_date,
              inventory_item,
              salesrep,
              salesrep_id,
              payment_term_id,
              pricing_date,
              attribute3,
              tax_code,
              global_attribute1,
              attribute8,
              attribute12,
              attribute14,
              attribute2,
              attribute16,
              attribute17,         
              shipping_method_code 
            )
            VALUES
            (
              g_order_source_id,
              p_org_id,
              ln_customer_id,          
              oe_order_lines_s.nextval,
              p_orig_sys_document_ref,
              p_order_line_rec.orderlineidsource,
              p_order_line_rec.link_to_line_ref,
              p_order_line_rec.top_line_ref,
              v_uom,
              ROUND(DECODE(ln_unit_list_price, NULL,p_order_line_rec.unit_list_price,ln_unit_list_price),5),
              ROUND(DECODE(ln_unit_selling_price, NULL,p_order_line_rec.unit_selling_price,ln_unit_selling_price),5),
              p_order_line_rec.tax,
              TO_CHAR(p_order_line_rec.quantity)*ROUND(DECODE(ln_unit_selling_price, NULL,p_order_line_rec.unit_selling_price,ln_unit_selling_price),2),--p_order_line_rec.customer_item_net_price,
              ROUND(DECODE(ln_tax_value, NULL,p_order_line_rec.tax_value,ln_tax_value),2),                                                              -- ((TO_CHAR(p_order_line_rec.quantity)*p_order_line_rec.unit_list_price)*TO_CHAR(p_order_line_rec.quantity))*p_order_line_rec.tax/100,
              l_calcualte_price,
              g_user_id,
              g_user_id,
              l_inventory_item_id,
              TO_CHAR(p_order_line_rec.quantity),
              lv_context_value,
              p_order_line_rec.discount_breakup,              
              p_order_line_rec.postal_code_from,
              upper(p_order_line_rec.country_code_from),
              p_order_line_rec.postal_code_to,
              upper(p_order_line_rec.country_code_to),
              l_operation,
              sysdate,
              sysdate,
              l_inventory_number,
              DECODE(lv_sales_yes_no,'N',upper(p_order_line_rec.salesperson),''),
              v1_salesrep_id,
              l_payment_term,
              p_pricing_date,
              lv_attr3,
              lv_tax_code,--p_order_line_rec.tax_code
              g_intf_inv_spec_seq,
              lv_attr8,
              lv_attr12 ,
              lv_attr14,
              lv_attr2,
              p_order_line_rec.itemno,
              lv_attr16,              
              p_order_line_rec.shipping_method
            );
        EXCEPTION
        WHEN OTHERS THEN
          p_status_code := 2;
          xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error while updating error code for invalid return order' || g_program_loc || '> ::Contact your system administrator:: ' || sqlerrm );
          p_error_message:=sqlerrm||dbms_utility.format_error_backtrace;
          xxcu_common_log_rt.msglog ('INFO', 'Error in insert of lines'||sqlerrm||dbms_utility.format_error_backtrace, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
        END ;
		
		
        ---------------------regular order with Non TMS context-----------------------------
      ELSE
        IF(lv_context_value IS NULL AND p_order_line_rec.ret_orderlineidsource IS NULL) THEN
          BEGIN
            INSERT
            INTO oe_lines_iface_all
              (
                order_source_id,
                org_id,
                sold_to_org_id,
                line_id,
                orig_sys_document_ref,
                orig_sys_line_ref,
                link_to_line_ref,
                top_model_line_ref,
                order_quantity_uom,
                unit_list_price,
                unit_selling_price,
                tax,
                customer_item_net_price,
                tax_value,
                calculate_price_flag,
                created_by,
                last_updated_by,
                inventory_item_id,
                ordered_quantity,
                context,
                attribute10,                
                attribute4,
                attribute5,
                attribute6,
                attribute7,                
                operation_code,
                creation_date,
                last_update_date,
                inventory_item,
                payment_term_id,
                salesrep, 
                salesrep_id,
                pricing_date,
                attribute3,
                tax_code,
                global_attribute1, 
                attribute8,
                attribute12,
                attribute14,
                attribute2,
                attribute16,         
                attribute17,         
                shipping_method_code 
              )
              VALUES
              (
                g_order_source_id,
                p_org_id,
                ln_customer_id,
                oe_order_lines_s.nextval,
                p_orig_sys_document_ref,
                p_order_line_rec.orderlineidsource,
                p_order_line_rec.link_to_line_ref,
                p_order_line_rec.top_line_ref,
                v_uom,
                ROUND(DECODE(ln_unit_list_price, NULL,p_order_line_rec.unit_list_price,ln_unit_list_price),3),          --added 3 instead of 2 to ROUND digit Version 1.30 kavita CR#2499
                ROUND(DECODE(ln_unit_selling_price, NULL,p_order_line_rec.unit_selling_price,ln_unit_selling_price),3), --added 3 instead of 2 to ROUND digit Version 1.30 kavita CR#2499
                p_order_line_rec.tax,
                TO_CHAR(p_order_line_rec.quantity)*ROUND(DECODE(ln_unit_selling_price, NULL,p_order_line_rec.unit_selling_price,ln_unit_selling_price),2),--p_order_line_rec.customer_item_net_price,
                ROUND(DECODE(ln_tax_value, NULL,p_order_line_rec.tax_value,ln_tax_value),2),                                                              -- ((TO_CHAR(p_order_line_rec.quantity)*p_order_line_rec.unit_list_price)*TO_CHAR(p_order_line_rec.quantity))*p_order_line_rec.tax/100,
                l_calcualte_price,
                g_user_id,
                g_user_id,
                l_inventory_item_id,
                TO_CHAR(p_order_line_rec.quantity),
                lv_context_value,
                p_order_line_rec.discount_breakup,
                p_order_line_rec.postal_code_from,
                upper(p_order_line_rec.country_code_from),
                p_order_line_rec.postal_code_to,
                upper(p_order_line_rec.country_code_to),                
                l_operation,
                sysdate,
                sysdate,
                l_inventory_number,
                l_payment_term,
                DECODE(lv_sales_yes_no,'N',upper(p_order_line_rec.salesperson),''),
                v1_salesrep_id,
                p_pricing_date,
                lv_attr3,  
                lv_tax_code,
                g_intf_inv_spec_seq , 
                lv_attr8,
                lv_attr12 ,
                lv_attr14,
                lv_attr2,
                p_order_line_rec.itemno,         
                lv_attr16,                       
                p_order_line_rec.shipping_method 
              );
          EXCEPTION
          WHEN OTHERS THEN
            p_status_code := 2;
            xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error while updating error code for invalid return order' || g_program_loc || '> ::Contact your system administrator:: ' || sqlerrm );
            p_error_message:=sqlerrm||dbms_utility.format_error_backtrace;
            xxcu_common_log_rt.msglog ('INFO', 'Error in insert of lines'||sqlerrm||dbms_utility.format_error_backtrace, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
          END;
		  
          ----------------------------return order with TMS context---------------------------------
        ELSE
          IF(lv_context_value IS NOT NULL AND p_order_line_rec.ret_orderlineidsource IS NOT NULL) THEN
            BEGIN
              INSERT
              INTO oe_lines_iface_all
                (
                  order_source_id,
                  org_id,
                  sold_to_org_id,
                  line_id,
                  orig_sys_document_ref,
                  orig_sys_line_ref,
                  link_to_line_ref,
                  top_model_line_ref,
                  order_quantity_uom,
                  unit_list_price,
                  unit_selling_price,
                  tax,
                  customer_item_net_price,
                  tax_value,
                  calculate_price_flag,
                  created_by,
                  last_updated_by,
                  inventory_item_id,
                  ordered_quantity,
                  context,
                  attribute10,
                  return_reason_code,
                  attribute4,
                  attribute5,
                  attribute6,
                  attribute7,
                  operation_code,
                  creation_date,
                  last_update_date,
                  inventory_item,
                  salesrep, 
                  salesrep_id,
                  return_context,
                  return_attribute1,
                  return_attribute2,
                  reference_header_id,
                  reference_line_id,
                  payment_term_id,
                  pricing_date,
                  attribute3,
                  attribute16,
                  attribute17,
                  tax_code,                  
                  return_attribute3,
                  return_attribute4,
                  global_attribute1,
                  shipping_method_code 
                )
                VALUES
                (
                  g_order_source_id,
                  p_org_id,
                  ln_customer_id,                  
                  oe_order_lines_s.nextval,
                  p_orig_sys_document_ref,
                  p_order_line_rec.orderlineidsource,
                  
                  p_order_line_rec.link_to_line_ref,
                  p_order_line_rec.top_line_ref,
                  
                  lv_uom,
                  ln_unit_price_ret,
                  
                  ln_selling_price_ret,
                  p_order_line_rec.tax,
                  TO_CHAR(p_order_line_rec.quantity)*ROUND(DECODE(ln_unit_selling_price, NULL,p_order_line_rec.unit_selling_price,ln_unit_selling_price),2),
                  ROUND(DECODE(ln_tax_value, NULL,p_order_line_rec.tax_value,ln_tax_value),2),                                                              
                  l_calcualte_price,                                                                                                                                                                                                                                                          --l_calcualte_price,
                  g_user_id,
                  g_user_id,
                  ln_inventory_item_id,
                  TO_CHAR(p_order_line_rec.quantity),
                  lv_context_value,    -- p_order_line_rec.orderlineidsource,
                  lv_attribute10,      --p_order_line_rec.discount_breakup,/*Artifact artf4721802*/
                  l_return_reason,     --p_order_line_rec.reason_code,
                  lv_attribute4,       --p_order_line_rec.postal_code_from,/*Artifact artf4721802*/
                  upper(lv_attribute5),--upper(p_order_line_rec.country_code_from),/*Artifact artf4721802*/
                  lv_attribute6,       --p_order_line_rec.postal_code_to,/*Artifact artf4721802*/
                  upper(lv_attribute7),--upper(p_order_line_rec.country_code_to),/*Artifact artf4721802*/
                  
                  l_operation,
                  sysdate,
                  sysdate,
                  lv_item,
                  DECODE(lv_sales_yes_no,'N',v_salesrep,''),
                  ln_salesrep_return,
                  'ORDER',
                  
                  DECODE(lv_return_flag_found,'TRUE',v_return_attribute1,NULL),
                  DECODE(lv_return_flag_found,'TRUE',l_line_id,NULL),
                  
                  v_return_attribute1,
                  l_line_id,
                  l_payment_term,
                  p_pricing_date,
                  
                  lv_attribute3,
                  lv_attribute16,
                  lv_attribute17,
                  
                  lv_tax_code,--p_order_line_rec.tax_code,
                  
                  DECODE(lv_return_flag_found,'FALSE',p_order_head_rec.return_order_reference,NULL),
                  DECODE(lv_return_flag_found,'FALSE',p_order_line_rec.ret_orderlineidsource,NULL),
                  g_intf_inv_spec_seq,          
                  p_order_line_rec.shipping_method 
                );
        
            EXCEPTION
            WHEN OTHERS THEN
              p_status_code := 2;
              xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error while updating error code for invalid return order' || g_program_loc || '> ::Contact your system administrator:: ' || sqlerrm );
              p_error_message:=sqlerrm||dbms_utility.format_error_backtrace;
              xxcu_common_log_rt.msglog ('INFO', 'Error in insert of lines'||sqlerrm||dbms_utility.format_error_backtrace, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
            END;
			
			
            ------------------------------return order with non TMS context--------------------------
          ELSE
            IF(lv_context_value IS NULL AND p_order_line_rec.ret_orderlineidsource IS NOT NULL) THEN
              BEGIN
                INSERT
                INTO oe_lines_iface_all
                  (
                    order_source_id,
                    org_id,
                    sold_to_org_id,
                    
                    line_id,
                    orig_sys_document_ref,
                    orig_sys_line_ref,
                    
                    link_to_line_ref,
                    top_model_line_ref,
                    
                    order_quantity_uom,
                    unit_list_price,
                    unit_selling_price,
                    tax,
                    customer_item_net_price,
                    tax_value,
                    calculate_price_flag,
                    created_by,
                    last_updated_by,
                    inventory_item_id,
                    ordered_quantity,
                    context,
                    attribute10,
                    return_reason_code,
                    
                    attribute4,
                    attribute5,
                    attribute6,
                    attribute7,
                    
                    operation_code,
                    creation_date,
                    last_update_date,
                    inventory_item,
                    return_context,
                    return_attribute1,
                    return_attribute2,
                    reference_header_id,
                    reference_line_id,
                    payment_term_id,
                    salesrep, 
                    salesrep_id,
                    pricing_date,
                    attribute3,
                    tax_code,
                    
                    return_attribute3,
                    return_attribute4,
                    global_attribute1 , 
                    attribute8,
                    attribute12,
                    attribute2,
                    attribute16,
                    attribute17,         
                    shipping_method_code 
                  )
                  VALUES
                  (
                    g_order_source_id,
                    p_org_id,
                    ln_customer_id,
                    
                    oe_order_lines_s.nextval,
                    p_orig_sys_document_ref,
                    p_order_line_rec.orderlineidsource,
                    
                    p_order_line_rec.link_to_line_ref,
                    p_order_line_rec.top_line_ref,
                    
                    lv_uom,
                    ln_unit_price_ret,
                    
                    ln_selling_price_ret,
                    p_order_line_rec.tax,
                    TO_CHAR(p_order_line_rec.quantity)*ROUND(DECODE(ln_unit_selling_price, NULL,p_order_line_rec.unit_selling_price,ln_unit_selling_price),2),--p_order_line_rec.customer_item_net_price,
                    ROUND(DECODE(ln_tax_value, NULL,p_order_line_rec.tax_value,ln_tax_value),2),                                                              -- ((TO_CHAR(p_order_line_rec.quantity)*p_order_line_rec.unit_list_price)*TO_CHAR(p_order_line_rec.quantity))*p_order_line_rec.tax/100,
                    l_calcualte_price,                                                                                                                        --'Y',  /* Version 1.18 */                                                                                                                                    --l_calcualte_price,
                    g_user_id,
                    g_user_id,
                    ln_inventory_item_id,
                    TO_CHAR(p_order_line_rec.quantity),
                    lv_context_value,    -- p_order_line_rec.orderlineidsource,
                    lv_attribute10,      --p_order_line_rec.discount_breakup,/*Artifact artf4721802*/
                    l_return_reason,     --p_order_line_rec.reason_code,
                    lv_attribute4,       --p_order_line_rec.postal_code_from,/*Artifact artf4721802*/
                    upper(lv_attribute5),--upper(p_order_line_rec.country_code_from),/*Artifact artf4721802*/
                    lv_attribute6,       --p_order_line_rec.postal_code_to,/*Artifact artf4721802*/
                    upper(lv_attribute7),--upper(p_order_line_rec.country_code_to),/*Artifact artf4721802*/
                   
                    l_operation,
                    sysdate,
                    sysdate,
                    lv_item,
                    'ORDER',
                    
                    DECODE(lv_return_flag_found,'TRUE',v_return_attribute1,NULL),
                    DECODE(lv_return_flag_found,'TRUE',l_line_id,NULL),
                    
                    v_return_attribute1,
                    l_line_id,
                    l_payment_term,
                    DECODE(lv_sales_yes_no,'N',v_salesrep,''),
                    ln_salesrep_return,
                    p_pricing_date,
                    
                    lv_attribute3,
                    
                    lv_tax_code,
                    
                    DECODE(lv_return_flag_found,'FALSE',p_order_head_rec.return_order_reference,NULL),
                    DECODE(lv_return_flag_found,'FALSE',p_order_line_rec.ret_orderlineidsource,NULL),
                   
                    g_intf_inv_spec_seq, 
                    lv_attribute8,
                    lv_attribute12,
                    lv_attribute2,
                    lv_attribute16,                  
                    lv_attribute17,                  
                    p_order_line_rec.shipping_method 
                  );
              EXCEPTION
              WHEN OTHERS THEN
                p_status_code := 2;
                xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error while updating error code for invalid return order' || g_program_loc || '> ::Contact your system administrator:: ' || sqlerrm );
                p_error_message:=sqlerrm||dbms_utility.format_error_backtrace;
                xxcu_common_log_rt.msglog ('INFO', 'Error in insert of lines'||sqlerrm||dbms_utility.format_error_backtrace, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
              END;
            END IF;
          END IF;
        END IF;
      END IF;
	  
      
      
      IF(lv_uom_flag='FALSE' AND upper(p_order_type) ='REGULAR') THEN
        BEGIN
          UPDATE oe_headers_iface_all
          SET error_flag             ='Y'
          WHERE orig_sys_document_ref=p_order_head_rec.order_reference;
          
          UPDATE oe_lines_iface_all
          SET error_flag           ='Y'
          WHERE orig_sys_line_ref  = p_order_line_rec.orderlineidsource
          AND orig_sys_document_ref=p_order_head_rec.order_reference;
          
          UPDATE oe_price_adjs_iface_all
          SET error_flag           ='Y'
          WHERE orig_sys_line_ref  = p_order_line_rec.orderlineidsource
          AND orig_sys_document_ref=p_order_head_rec.order_reference;
          
          SELECT oe_msg_id_s.nextval
          INTO l_transaction_id
          FROM dual;
          
          INSERT
          INTO oe_processing_msgs
            (
              transaction_id ,
              request_id ,
              entity_code ,
              entity_ref ,
              entity_id ,
              header_id ,
              line_id ,
              order_source_id ,
              original_sys_document_ref ,
              original_sys_document_line_ref ,
              orig_sys_shipment_ref ,
              change_sequence ,
              source_document_type_id ,
              source_document_id ,
              source_document_line_id ,
              attribute_code ,
              creation_date ,
              created_by ,
              last_update_date ,
              last_updated_by ,
              last_update_login ,
              program_application_id ,
              program_id ,
              program_update_date ,
              process_activity ,
              notification_flag ,
              type ,
              message_source_code ,
              message_status_code ,
              org_id
            )
            VALUES
            (
              l_transaction_id ,
              NULL,
              'LINE' ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              g_order_source_id ,
              p_order_head_rec.order_reference ,
              p_order_line_rec.orderlineidsource,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              sysdate ,
              g_user_id ,
              sysdate ,
              g_user_id ,
              fnd_global.login_id ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              'ERROR' ,
              'C' ,
              'OPEN' ,
              p_org_id
            );
          BEGIN
            INSERT
            INTO oe_processing_msgs_tl
              (
                transaction_id ,
                language ,
                source_lang ,
                message_text ,
                created_by ,
                creation_date ,
                last_updated_by ,
                last_update_date ,
                last_update_login
              )
            SELECT l_transaction_id ,
              l.language_code ,
              'US' ,
              (SELECT message_text
              FROM fnd_new_messages
              WHERE message_name='OE_INVALID_ITEM_UOM'
              AND language_code ='US'
              ) ,
              g_user_id ,
              sysdate ,
              g_user_id ,
              sysdate ,
              fnd_global.login_id
            FROM fnd_languages l
            WHERE l.installed_flag IN ('I','B')
            AND language_code       = 'US'
            AND NOT EXISTS
              (SELECT NULL
              FROM oe_processing_msgs_tl t
              WHERE t.transaction_id = l_transaction_id
              AND t.language         = l.language_code
              );



			INSERT
            INTO oe_processing_msgs_tl
              (
                transaction_id ,
                language ,
                source_lang ,
                message_text ,
                created_by ,
                creation_date ,
                last_updated_by ,
                last_update_date ,
                last_update_login
              )
            SELECT l_transaction_id ,
              l.language_code ,
              'N' ,
              (SELECT message_text
              FROM fnd_new_messages
              WHERE message_name='OE_INVALID_ITEM_UOM'
              AND language_code ='N'
              ) ,
              g_user_id ,
              sysdate ,
              g_user_id ,
              sysdate ,
              fnd_global.login_id
            FROM fnd_languages l
            WHERE l.installed_flag IN ('I','B')
            AND language_code       = 'N'
            AND NOT EXISTS
              (SELECT NULL
              FROM oe_processing_msgs_tl t
              WHERE t.transaction_id = l_transaction_id
              AND t.language         = l.language_code
              );
          END;
        EXCEPTION
        WHEN OTHERS THEN
          p_status_code := g_code_error;
          xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error while updating error code for invalid return order' || g_program_loc || '> ::Contact your system administrator:: ' || sqlerrm );
          dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
        END;
      END IF;
	  
     
      IF(lv_return_flag_found ='FALSE' AND upper(p_order_head_rec.order_type)='RETURN') THEN
        BEGIN
          UPDATE oe_headers_iface_all
          SET error_flag             ='Y'
          WHERE orig_sys_document_ref=p_order_head_rec.order_reference;

          UPDATE oe_lines_iface_all
          SET error_flag           ='Y'
          WHERE orig_sys_line_ref  = p_order_line_rec.orderlineidsource
          AND orig_sys_document_ref=p_order_head_rec.order_reference;

          UPDATE oe_price_adjs_iface_all
          SET error_flag           ='Y'
          WHERE orig_sys_line_ref  = p_order_line_rec.orderlineidsource
          AND orig_sys_document_ref=p_order_head_rec.order_reference;
         
          SELECT oe_msg_id_s.nextval
          INTO l_transaction_id
          FROM dual;
          
          INSERT
          INTO oe_processing_msgs
            (
              transaction_id ,
              request_id,
              entity_code ,
              entity_ref ,
              entity_id ,
              header_id ,
              line_id ,
              order_source_id ,
              original_sys_document_ref ,
              original_sys_document_line_ref ,
              orig_sys_shipment_ref ,
              change_sequence ,
              source_document_type_id ,
              source_document_id ,
              source_document_line_id ,
              attribute_code ,
              creation_date ,
              created_by ,
              last_update_date ,
              last_updated_by ,
              last_update_login ,
              program_application_id ,
              program_id ,
              program_update_date ,
              process_activity ,
              notification_flag ,
              type ,
              message_source_code ,
              message_status_code ,
              org_id
            )
            VALUES
            (
              l_transaction_id ,
              NULL,
              'LINE' ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              g_order_source_id ,
              p_order_head_rec.order_reference ,
              p_order_line_rec.orderlineidsource,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              sysdate ,
              g_user_id ,
              sysdate ,
              g_user_id ,
              fnd_global.login_id ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              NULL ,
              'ERROR' ,
              'C' ,
              'OPEN' ,
              p_org_id
            );
			
			
          BEGIN
            INSERT
            INTO oe_processing_msgs_tl
              (
                transaction_id ,
                language ,
                source_lang ,
                message_text ,
                created_by ,
                creation_date ,
                last_updated_by ,
                last_update_date ,
                last_update_login
              )
            SELECT l_transaction_id ,
              l.language_code ,
              'US' ,
              (SELECT message_text
              FROM fnd_new_messages
              WHERE message_name='OE_RETURN_INVALID_SO_LINE'
              AND language_code ='US'
              ) ,
              g_user_id ,
              sysdate ,
              g_user_id ,
              sysdate ,
              fnd_global.login_id
            FROM fnd_languages l
            WHERE l.installed_flag IN ('I','B')
            AND language_code       = 'US'
            AND NOT EXISTS
              (SELECT NULL
              FROM oe_processing_msgs_tl t
              WHERE t.transaction_id = l_transaction_id
              AND t.language         = l.language_code
              );
            
            INSERT
            INTO oe_processing_msgs_tl
              (
                transaction_id ,
                language ,
                source_lang ,
                message_text ,
                created_by ,
                creation_date ,
                last_updated_by ,
                last_update_date ,
                last_update_login
              )
            SELECT l_transaction_id ,
              l.language_code ,
              'N' ,
              (SELECT message_text
              FROM fnd_new_messages
              WHERE message_name='OE_RETURN_INVALID_SO_LINE'
              AND language_code ='N'
              ) ,
              g_user_id ,
              sysdate ,
              g_user_id ,
              sysdate ,
              fnd_global.login_id
            FROM fnd_languages l
            WHERE l.installed_flag IN ('I','B')
            AND language_code       = 'N'
            AND NOT EXISTS
              (SELECT NULL
              FROM oe_processing_msgs_tl t
              WHERE t.transaction_id = l_transaction_id
              AND t.language         = l.language_code
              );
            
          END;
          
        EXCEPTION
        WHEN OTHERS THEN
          p_status_code := g_code_error;
          xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error while updating error code for invalid return order' || g_program_loc || '> ::Contact your system administrator:: ' || sqlerrm );
          dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
        END;
      END IF;
      
      BEGIN
        IF((p_order_line_rec.discount_breakup        IS NOT NULL OR p_order_line_rec.price_adj_per_unit <>0) --CR 4799
          AND p_order_line_rec.ret_orderlineidsource IS NULL) THEN                                           --added for defect 8002
          BEGIN
            SELECT sold_to_org_id
            INTO ln_customer_id
            FROM oe_headers_iface_all
            WHERE orig_sys_document_ref=p_orig_sys_document_ref
            AND org_id                 =p_org_id;
          EXCEPTION
          WHEN OTHERS THEN
            l_log_label := 'Invalid Customer';
            l_message   := 'Customer Not Found';
            xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_proc_name || '.' || l_log_label , l_message, false);
          END;
          BEGIN
            SELECT list_header_id
            INTO lv_list_header_id
            FROM qp_list_headers_all
            WHERE upper(currency_code)=upper(DECODE(lv_new_curr_code, NULL,p_curr_code,lv_new_curr_code))
            AND upper(list_type_code) ='DLT';
          EXCEPTION
          WHEN OTHERS THEN
            l_log_label := 'Invalid Price List Header';
            l_message   := 'Price List Header Not Found';
            xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_proc_name || '.' || l_log_label , l_message, false);
          END;
          BEGIN
            SELECT list_line_id
            INTO lv_list_line_id
            FROM qp_pricing_attributes
            WHERE list_header_id         =lv_list_header_id
            AND upper(product_attr_value)= 'ALL';
          EXCEPTION
          WHEN OTHERS THEN
            l_log_label := 'Invalid Price List line';
            l_message   := 'Price List line Not Found';
            xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_proc_name || '.' || l_log_label , l_message, false);
          END;
          /* start defect 3195 */
          BEGIN
            SELECT description
            INTO lv_modifier
            FROM qp_secu_list_headers_vl
            WHERE list_header_id=lv_list_header_id
            AND currency_code   =upper(DECODE(lv_new_curr_code, NULL,p_curr_code,lv_new_curr_code));
          EXCEPTION
          WHEN OTHERS THEN
            xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error while fetching modifier ' || l_prog_loc || '> ::Contact your system administrator:: ' || sqlerrm );
            p_status_code  := 2;
            p_error_message:=sqlerrm||dbms_utility.format_error_backtrace;
          END;
          
          BEGIN
            SELECT lookup_code,
              meaning
            INTO lv_change_code,
              lv_change_reason
            FROM fnd_lookup_values_vl
            WHERE upper(lookup_type)='CHANGE_CODE'
            AND upper(lookup_code)  ='ORDER IMPORT';
          EXCEPTION
          WHEN OTHERS THEN
            l_log_label := 'Invalid Modified Change Code';
            l_message   := 'Modified Change Code not found';
            xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_proc_name || '.' || l_log_label , l_message, false);
          END;
          
          BEGIN
            SELECT oe_price_adjustments_s.nextval INTO l_price_id FROM dual;
          EXCEPTION
          WHEN OTHERS THEN
            l_price_id:=NULL;
          END;
          
          INSERT
          INTO oe_price_adjs_iface_all
            (
              price_adjustment_id,
              orig_sys_discount_ref,
              orig_sys_document_ref,
              order_source_id,
              
              orig_sys_line_ref,
              
              adjusted_amount,
              automatic_flag,
              creation_date,
              last_update_date,
              created_by,
              last_updated_by,
              operation_code,
              list_header_id,
              list_line_id,
              list_line_type_code,
              operand,
              operand_per_pqty,
              updated_flag,
              arithmetic_operator,
              adjusted_amount_per_pqty,
              applied_flag,
              change_reason_code,
              change_reason_text,
              org_id,
              
              sold_to_org_id,
             
              modifier_name
              
            )
            VALUES
            (
              l_price_id,
              'OE_PRICE_ADJUSTMENTS'
              ||(l_price_id+1),
              p_orig_sys_document_ref,
              g_order_source_id,
             
              p_order_line_rec.orderlineidsource,
              p_order_line_rec.price_adj_per_unit,
              'N',
              sysdate,
              sysdate,
              g_user_id,
              g_user_id,
              l_operation,
              lv_list_header_id,
              lv_list_line_id,
              'DIS',
              
              ABS((p_order_line_rec.price_adj_per_unit/p_order_line_rec.unit_list_price)*100),
              
              ABS(p_order_line_rec.price_adj_per_unit),
              'Y',
              '%',
              p_order_line_rec.price_adj_per_unit,
              'Y',
              lv_change_code,
              lv_change_reason,
              p_org_id,
              
              ln_customer_id,
              
              lv_modifier
              
            );
          
        END IF;
        
      EXCEPTION
      WHEN OTHERS THEN
        xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled errors in the insertion of the oe_lines_iface_all ( ' || p_order_line_rec.orderlineidsource || ') <' || l_prog_loc || '> ::Contact your system administrator:: ' || sqlerrm );
        p_status_code  := 2;
        p_error_message:=sqlerrm||dbms_utility.format_error_backtrace;
      END;
    EXCEPTION
    WHEN OTHERS THEN
      xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled errors in the insertion of the oe_lines_iface_all ( ' || p_order_line_rec.orderlineidsource || ') <' || l_prog_loc || '> ::Contact your system administrator:: ' || sqlerrm );
      p_status_code  := 2;
      p_error_message:=sqlerrm||dbms_utility.format_error_backtrace;
    END;
    
  EXCEPTION
  WHEN e_no_salesper THEN
    xxcu_log_pkg.log(p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Sales person not fount in order line ' || g_program_loc || ' ' || sqlerrm );
    p_status_code  := g_code_error;
    p_error_message:='Invalid Sales person in order lines.';
  WHEN OTHERS THEN
    xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled errors in the insertion of the oe_lines_iface_all ( ' || p_order_line_rec.orderlineidsource || ') <' || l_prog_loc || '> ::Contact your system administrator:: ' || sqlerrm );
    p_status_code  := 2;
    p_error_message:=sqlerrm||dbms_utility.format_error_backtrace;
  END;