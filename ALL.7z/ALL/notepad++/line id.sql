i/p--header id, orig sys line ref, order source id, org id
o/p- line id 

FUNCTION getline_id(
      p_header_id         IN NUMBER,
      p_orig_sys_line_ref IN VARCHAR2,
      p_org_id            IN NUMBER) --added org_id defect#2848
    RETURN NUMBER
  AS
    v_line_id NUMBER;
  BEGIN
    BEGIN
      SELECT line_id
      INTO v_line_id
      FROM oe_order_lines_all
      WHERE header_id       = p_header_id
      AND orig_sys_line_ref = p_orig_sys_line_ref
      AND order_source_id   = g_order_source_id
      AND org_id            = p_org_id;
    EXCEPTION
    WHEN no_data_found THEN
      v_line_id := NULL;
    END;
    RETURN v_line_id;
  END;