i/p--source

FUNCTION getinventory_number(
      p_source            IN VARCHAR2,
      p_order_type        IN VARCHAR2,
      p_inventory_item_id IN NUMBER,
      p_org_id NUMBER)
    RETURN VARCHAR2
  IS
    l_ret_val       VARCHAR2 (200);
    ln_warehouse_id NUMBER;
    p_status_code   NUMBER;
    p_error_message VARCHAR2(2000);
    ln_trans_type   NUMBER;
  
  
  BEGIN
   
   BEGIN
      ln_trans_type:= get_transaction_type_id(p_source, p_order_type, p_org_id, p_status_code, p_error_message);
    EXCEPTION
    WHEN OTHERS THEN
      xxcu_common_log_rt.msglog ('ERR', 'Failed to derive transaction type id 7 '||sqlerrm||dbms_utility.format_error_backtrace, 1117, '1', 'get_transaction_type_id', '-1' );
      ln_trans_type:=NULL;
    END;
   

   BEGIN
      SELECT warehouse_id
      INTO ln_warehouse_id
      FROM oe_transaction_types_all
      WHERE transaction_type_id= ln_trans_type;
    EXCEPTION
    WHEN OTHERS THEN
      ln_warehouse_id:=NULL;
    END;
    
	
	BEGIN
      SELECT DISTINCT segment1
      INTO l_ret_val
      FROM mtl_system_items_b
      WHERE inventory_item_id = p_inventory_item_id
      AND organization_id     =ln_warehouse_id;
      --AND ROWNUM              = 1;
    EXCEPTION
    WHEN no_data_found THEN
      xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'FEIL: Klarer ikke  finne artikkelnummer: ' || p_inventory_item_id || ' ::Artikkelnummeret m? legges inn i artikkelregisteret og m? samsvare med mappingtabell::  ' );
    END;
    
	RETURN l_ret_val;
  END;