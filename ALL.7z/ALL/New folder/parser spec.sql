
msgid-1117
usermsg- 1

terminal_rec
packageline_rec
priceline_rec
shipment_order_rec
 inv_spec_url_rec
customer_address_rec
inv_private_cust_rec
inv_spec_disc_rec
inv_custom_print_rec
inv_customer_address_rec
inv_spec_ref_rec
inv_spec_rec
orderline_rec
orderhead_rec
batch_order_rec

1)  type cursor_type IS   ref  CURSOR;

2)   type terminal_rec IS   record
  (
    terminal_name VARCHAR2(2000),
    terminal_id   VARCHAR2(2000) 
);

3)  type terminal_lines IS   TABLE OF terminal_rec;

4)  type packageline_rec IS   record
  (
    cargo_id_num  VARCHAR2(1000),
    weight        NUMBER,
    volume        NUMBER,
    volume_weight VARCHAR2(1000),
    received_time DATE,
    Freight_Calculated_Weight VARCHAR2(1000) ---- 5280
    );

5) type package_lines IS  TABLE OF packageline_rec;


6)type priceline_rec  IS  record
  (
    item_number         VARCHAR2(255),
    Cargo_ID_Number     VARCHAR2(250),      ---- 5280
    ordered_qty         NUMBER,
    unit_list_price     NUMBER,
    unit_net_price      NUMBER,
    price_adjs_per_unit NUMBER,
    tax_code            VARCHAR2(500),
    tax                 VARCHAR2(200),
    tax_value           NUMBER,
    country_from        VARCHAR2(255),
    country_to          VARCHAR2(255),
    disc_breakup_info   VARCHAR2(2000),
    quantity_uom        VARCHAR2(10),
    product_code        VARCHAR2(500),
    department          VARCHAR2(1000)-- defect 3702
    -- product_name        VARCHAR2(500) --defect 3702
  );



7)type price_lines IS   TABLE OF priceline_rec;

8)type shipment_order_rec IS  record
  (
    customer_num              VARCHAR2(50),
    trans_curr_code           VARCHAR2(10),
    ordered_date              DATE, --Batch Date
    payment_provider_trans_id VARCHAR2(100),
    reserved_amount           NUMBER,
    source                    VARCHAR2(400),
    sender_reference          VARCHAR2(2000),
    shipment_id_num           VARCHAR2(2000),
    returned                  VARCHAR2(200),
    freight_cal_wt            VARCHAR2(200),
    price_zone                VARCHAR2(1000),
    weight_group              VARCHAR2(500),
    num_of_pkgs               VARCHAR2(500),
    -- department                VARCHAR2(1000),--defect 3702
    sender_name           VARCHAR2(1000),
    ship_from_addr1       VARCHAR2(1000),
    ship_from_addr2       VARCHAR2(1000),
    ship_from_postal_code VARCHAR2(100),
    ship_from_city        VARCHAR2(500),
    ship_from_country     VARCHAR2(500),
    receiver_reference    VARCHAR2(2000),
    receiver_name         VARCHAR2(1000),
    ship_to_addr1         VARCHAR2(1000),
    ship_to_addr2         VARCHAR2(1000),
    ship_to_postal_code   VARCHAR2(100),
    ship_to_city          VARCHAR2(500),
    ship_to_country       VARCHAR2(500),
    delivery_point        VARCHAR2(1000),
    delivery_addr1        VARCHAR2(1000),
    delivery_addr2        VARCHAR2(1000),
    delivery_postal_code  VARCHAR2(100),
    delivery_city         VARCHAR2(500),
    delivery_country      VARCHAR2(500),
    volume_factor         VARCHAR2(1000),
    shipment_sum          VARCHAR2(1000),
    message_to_cust       VARCHAR2(2000),
    po_reference          VARCHAR2(200),
    agreement_name        VARCHAR2(200),
    postal_code_to        VARCHAR2(200),
    postal_code_from      VARCHAR2(200),
    lv_packagelines package_lines,
    lv_pricelines price_lines,
    department VARCHAR2(1000),--defect 3947
    /* start CR 4419 */
    lv_terminal terminal_lines
    /* end CR 4419 */
  );


9)type shipment_head  IS   TABLE OF shipment_order_rec;



  /* end wave 2 modification */
  /* version 1.7 CR 1929*/



10)type inv_spec_url_rec  IS  record
  (
    attachment_name VARCHAR2(240),
    link_url        VARCHAR2(2000),
    link_label      VARCHAR2(240),
    mime_type       VARCHAR2(240)
 );


11)type spec_url_line  IS  TABLE OF inv_spec_url_rec;


  /* start wave 2 modification */
  /* start artifact artf5962829 */


12) type customer_address_rec IS  record
  (
    address1    VARCHAR2(240),
    address2    VARCHAR2(240),
    address3    VARCHAR2(240),
    city        VARCHAR2(60),
    postal_code VARCHAR2(60),
    country     VARCHAR2(60),
    addr_type   VARCHAR2(50)
 );


13)type address_lines IS   TABLE OF customer_address_rec;


14)type inv_private_cust_rec  IS   record
  (
    customer_reference  VARCHAR2(50),
    private_cust_number VARCHAR2(30),
    digi_id             VARCHAR2(150),
    first_name          VARCHAR2(150),
    last_name           VARCHAR2(150),
    date_of_birth       VARCHAR2(150),
    distribution_flag VARCHAR2(10),-- CR 5144
    far_number          VARCHAR2(150),--CR 5026
    lv_addresslines address_lines );


15) type private_cust_line IS  TABLE OF inv_private_cust_rec;


  /* end artifact artf5962829 */


16)type inv_spec_disc_rec IS   record
  (
    descriptionno VARCHAR2(2000),
    descriptionus VARCHAR2(2000),
    percentage    VARCHAR2(2000)
 );


17)type spec_inv_disc IS  TABLE OF inv_spec_disc_rec;


  /* end wave 2 modification */
  /* start wave 2 modification */

18) type inv_custom_print_rec IS  record
  (
    messageid                    VARCHAR2(2000),
    inv_customer_group           VARCHAR2(2000),
    goods_total_value            VARCHAR2(2000),
    shipment_type                VARCHAR2(2000),
    total_num_items              VARCHAR2(100),
    commodity_classification     VARCHAR2(2000),
    custom_clearance_status_code VARCHAR2(2000),
    custom_clearance_date        VARCHAR2(200),
    inv_split                    VARCHAR2(2000),
    inv_mail                     VARCHAR2(2000),
    customer_enclosure           VARCHAR2(2000),
    adr_lev_deviation            VARCHAR2(2000),
    product                      VARCHAR2(2000),
    collie                       VARCHAR2(2000),
    shipper_goods_value          VARCHAR2(2000),
    invoice_type                 VARCHAR2(2000),
    receipt_reference            VARCHAR2(2000),
    preferred_language           VARCHAR2(2000),
    invoice_settlement           VARCHAR2(2000) 
);


19)type inv_custom_print   IS  TABLE OF inv_custom_print_rec;


  /* end wave 2 modification */
  /* start CR 4721 */


20)type inv_customer_address_rec IS  record
  (
    bill_to_addressee      VARCHAR2(2000),
    bill_to_address_1      VARCHAR2(2000),
    bill_to_address_2      VARCHAR2(2000),
    bill_to_address_3      VARCHAR2(2000),
    bill_to_postal_code    VARCHAR2(100),
    bill_to_city           VARCHAR2(2000),
    bill_to_country_code   VARCHAR2(2000),
    bill_to_country_name   VARCHAR2(200),
    bill_to_contact_person VARCHAR2(2000),
    bill_to_contact_email  VARCHAR2(2000),
    ship_to_addressee      VARCHAR2(2000),
    ship_to_address_1      VARCHAR2(2000),
    ship_to_address_2      VARCHAR2(2000),
    ship_to_address_3      VARCHAR2(2000),
    ship_to_postal_code    VARCHAR2(100),
    ship_to_city           VARCHAR2(2000),
    ship_to_country_code   VARCHAR2(2000),
    ship_to_country_name   VARCHAR2(200),
    ship_to_contact_person VARCHAR2(2000),
    ship_to_contact_email  VARCHAR2(2000) 
);



21)type inv_customer_address IS   TABLE OF inv_customer_address_rec;


  /* end CR 4721 */
  --------------------------------------------
  /* Start  CR 3118*/



22)type inv_spec_ref_rec IS   record
  (
    free_reference_code    VARCHAR2(240),
    free_reference_text    VARCHAR2(2000),
    free_reference_content VARCHAR2(2000),
    print_on_invoice_flag  VARCHAR2(10) 
);



23)type spec_ref_line IS   TABLE OF inv_spec_ref_rec;


  /* end CR 3118 */
  /* version 1.6 CR 1899*/


24)type inv_spec_rec IS   record
  (
    order_line_number         NUMBER,
    order_line_text           VARCHAR2(240),
    order_line_no_of_packages NUMBER,
    order_line_pallet         VARCHAR2(240),
    order_line_pp_price       NUMBER,
    order_line_net_weight     NUMBER,
    order_line_nop_uom        VARCHAR2(25),
    order_line_net_weight_uom VARCHAR2(25),
    order_line_length         NUMBER,
    order_line_width          NUMBER,
    order_line_height         NUMBER,
    order_line_dim_uom        VARCHAR2(25),
    /* version 1.8 CR 2468 */
    order_line_date            DATE,
    order_line_per_time_unit   VARCHAR2(1000),
    order_line_unit_price      NUMBER,
    order_line_unit_amount     NUMBER,
    order_line_cargo_type      VARCHAR2(1000),
    order_line_freight_calc_wt NUMBER,
    order_line_frt_calc_wt_uom VARCHAR2(100),
    order_line_volume          NUMBER,
    order_line_volume_uom      VARCHAR2(100),
    order_line_load_meter      NUMBER,
    order_line_cargo_label     VARCHAR2(1000),
    ---------------------------------------
    /* start CR 3118 */
    order_line_gross_weight     NUMBER,
    order_line_gross_weight_uom VARCHAR2(3)
    /* end CR 3118 */
  );


25)type spec_line IS  TABLE OF inv_spec_rec;

  --------------------------------------------
26)type orderline_rec IS   record
  (
    itemno VARCHAR2(255),
    /* Version 1.3 Defect # 553 */
    quantity           NUMBER,
    quantity_uom       VARCHAR2 (80 CHAR),---defect 3268
    unit_list_price    NUMBER,
    unit_selling_price NUMBER,
    tax                VARCHAR2 (50 CHAR),
    --Customer_Item_Net_Price VARCHAR2 (50 CHAR),
    tax_value             NUMBER,
    orderlineidsource     VARCHAR2 (50 CHAR),
    ret_orderlineidsource VARCHAR2 (50 CHAR),
    aggregateline         BOOLEAN,
    --orig_sys_line_ref       VARCHAR2(50 BYTE)
    discount_breakup  VARCHAR2 (50 CHAR),
    blanket_number     VARCHAR2 (50 CHAR),  --Added by Sayali for defect 5484
    reason_code       VARCHAR2 (50 CHAR),
    postal_code_from  VARCHAR2 (50 CHAR),
    postal_code_to    VARCHAR2 (50 CHAR),
    country_code_from VARCHAR2 (50 CHAR),
    country_code_to   VARCHAR2 (50 CHAR),
    --Ship_From          VARCHAR2 (50 CHAR),
    ship_to               VARCHAR2 (240 CHAR),
    salesperson           VARCHAR2 (50 CHAR),
    price_adj_per_unit    NUMBER,
    orig_sys_discount_ref VARCHAR2(80),
    tax_code              VARCHAR2(50),
    /* start wave 2 modification */
    link_to_line_ref  VARCHAR2(240),
    top_line_ref      VARCHAR2(240),
    gift_recipient    VARCHAR2(240),
    gift_ship_to      VARCHAR2(240),
    combination_id    VARCHAR2(240),
    weight_group      VARCHAR2(240),
    unit_weight       VARCHAR2(240),
    price_zone        VARCHAR2(240),
    assignment_number VARCHAR2(240),
    /* end wave 2 modification */
    /* version 1.5 */
    date_from           DATE,
    date_to             DATE,
    description         VARCHAR2(1000),
    order_date          DATE,
    spec_quantity       NUMBER,
    uom                 VARCHAR2(100),
    per_time_unit       VARCHAR2(100),
    unit_price          NUMBER,
    amount              NUMBER,
    waybill_number      VARCHAR2(240),
    sender_name         VARCHAR2(1000),
    receiver_name       VARCHAR2(1000),
    ship_from           VARCHAR2(1000),
    spec_ship_to        VARCHAR2(1000),
    number_of_packages  NUMBER,
    pallet              VARCHAR2(1000),
    volume              NUMBER,
    weight              NUMBER,
    freight_calc_weight NUMBER,
    responsible_person  VARCHAR2(100),
    pp_price            NUMBER,
    cargo_type          VARCHAR2(1000),
    /* version 1.7 CR 1929 */
    container_reference   VARCHAR2(240),
    pick_up_point         VARCHAR2(240),
    awb                   VARCHAR2(240),
    mawb                  VARCHAR2(240),
    hawb                  VARCHAR2(240),
    vessel                VARCHAR2(240),
    incoterm              VARCHAR2(240),
    sender_reference      VARCHAR2(240),
    receiver_reference    VARCHAR2(2000), --Modified for defect 5468
    agent_reference       VARCHAR2(240),
    load_carrier          VARCHAR2(240),
    transport_method      VARCHAR2(240),
    delivery_point        VARCHAR2(240),
    our_reference         VARCHAR2(240),
    cargo_id_number       VARCHAR2(240),
    position_number       VARCHAR2(240),
    load_meter            NUMBER,
    cargo_label           VARCHAR2(240),
    charteque_number      VARCHAR2(240),
    delivered_time        DATE,
    received_time         DATE,
    ship_from_address1    VARCHAR2(240),
    ship_from_address2    VARCHAR2(240),
    ship_from_address3    VARCHAR2(240),
    ship_from_country     VARCHAR2(60),
    ship_from_postal_code VARCHAR2(60),
    ship_to_address1      VARCHAR2(240),
    ship_to_address2      VARCHAR2(240),
    ship_to_address3      VARCHAR2(240),
    ship_to_postal_code   VARCHAR2(60),
    ship_to_country       VARCHAR2(60),
    ----------------------------------------------------------
    /* version 1.8 CR 2468 */
    volume_uom              VARCHAR2(50),
    weight_uom              VARCHAR2(50),
    freight_calc_weight_uom VARCHAR2(50) ,
    order_line_spec_hdr_cnt VARCHAR2(1000),--Added by Rahul
    -------------------------------------------------------------
    /*version 1.6 CR 1899*/
    /* start 1.10 CR 3006 */
    currency        VARCHAR2(10),
    currency_amount NUMBER,
    exchange_rate   NUMBER,
    exchange_date   DATE,
    /* end 1.10 CR 3006 */
    /* start CR 3118 */
    pick_up_address1     VARCHAR2(240),
    pick_up_address2     VARCHAR2(240),
    pick_up_address3     VARCHAR2(240),
    pick_up_postal_code  VARCHAR2(30),
    pick_up_city         VARCHAR2(30),
    pick_up_country      VARCHAR2(60),
    delivery_address1    VARCHAR2(240),
    delivery_address2    VARCHAR2(240),
    delivery_address3    VARCHAR2(240),
    delivery_postal_code VARCHAR2(30),
    delivery_city        VARCHAR2(30),
    delivery_country     VARCHAR2(60),
    -- UNLOADING_POINT       VARCHAR2(400),
    --LOADING_POINT         VARCHAR2(400),
    note CLOB,
    consignment_type_code VARCHAR2(10),
    consignment_type_text VARCHAR2(2000),
    transport_method_text VARCHAR2(2000),
    incoterm_text         VARCHAR2(2000),
    ship_to_fiscal_code   VARCHAR2(20),
    ship_from_fiscal_code VARCHAR2(20),
    /* start wave 2 modification */
    ordered_by           VARCHAR2(1000),
    ordered_by_addr1     VARCHAR2(2000),
    ordered_by_addr2     VARCHAR2(2000),
    ordered_by_addr3     VARCHAR2(2000),
    ordered_by_postal    VARCHAR2(1000),
    ordered_by_city      VARCHAR2(1000),
    ordered_by_country   VARCHAR2(1000),
    ordered_by_contact   VARCHAR2(1000),
    ordered_by_con_email VARCHAR2(1000),
    bill_to_con_person   VARCHAR2(1000),
    bill_to_con_email    VARCHAR2(1000),
    deviation            VARCHAR2(1000),
    franking_type        VARCHAR2(1000),
    price_table          VARCHAR2(1000),
    speed                VARCHAR2(1000),
    destination          VARCHAR2(1000),
    weight_spec          VARCHAR2(1000),
    unit_price_inc_vat   VARCHAR2(1000),
    total_inc_vat        VARCHAR2(1000),
    paid_amount          NUMBER,
    agreement_sum        NUMBER,
    shipment_id_number   NUMBER,
    unit_price_excl_vat  NUMBER,
    inv_spec_disc spec_inv_disc,
    /* end wave 2 modification */
    ref_spec_line spec_ref_line ,
    /* end CR 3118 */
    /* start CR 3374 */
    loading_point   VARCHAR2(240),
    unloading_point VARCHAR2(240),
    /* end CR 3374 */
    /* start CR 4475 */
    freight_payer VARCHAR2(240),
    /* end CR 4475 */
    shipping_method VARCHAR2(30), --CR 4813
    speclines spec_line ) ;



27)type order_line IS  TABLE OF orderline_rec;
 
28)type orderhead_rec  IS   record
  (
    --Organizational_Unit            NUMBER,
    customer_number VARCHAR2 (50 CHAR),----------------
    po_reference    VARCHAR2 (50 CHAR),
    sales_agmnt_no  VARCHAR2 (50 CHAR),---------------
    --Order_Source_Id        NUMBER,
    order_source           VARCHAR2 (50 CHAR),----------
    order_type             VARCHAR2 (30 CHAR),---------
    order_reference        VARCHAR2 (50 CHAR),-----------
    return_order_reference VARCHAR2 (50 CHAR),----------
    ordereddate            DATE,
    currency_code          VARCHAR2 (10 CHAR),----------
    cc_ref_id              VARCHAR2 (240 CHAR),
    org_id                 NUMBER,------------------------
    customer_ref           VARCHAR2 (240 CHAR),
    --Autotwist_Invoice      VARCHAR2 (240 CHAR),
    charteque_number VARCHAR2 (240 CHAR),-------------------
    --Source                         VARCHAR2 (50 CHAR),
    price_list                VARCHAR2 (50 CHAR),
    payment_type_code         VARCHAR2 (240 CHAR),
    payment_provider_trans_id VARCHAR2(100),---------------
    exclude_from_dunning      VARCHAR2(100),
    pricing_date              DATE,--------------------
    salesperson               VARCHAR2 (50 CHAR),
    invoice_attachment_file   VARCHAR2(100),
    aggregatehead             BOOLEAN,
    /* version 1.5 */
    message_to_customer VARCHAR2(240),
    agreement_name      VARCHAR2(240),
    prepayment_flag     VARCHAR2(30),
    settlement_flag     VARCHAR2(30),---added by vijay on 27-jun-2017 for defect 3528 ------------
    project_ref         VARCHAR2(240),
    order_number        NUMBER,
    /* version 1.8 CR 2224, 2043 */
    printed_order_number NUMBER,
    /* start wave 2 modification */
    contract_num          VARCHAR2(240),------------
    contract_modifier_num VARCHAR2(240),------------
    bill_details          VARCHAR2(240),------------
    waiting_date          VARCHAR2(240),----------
    handling_date         VARCHAR2(240),----------
    payment_method        VARCHAR2(240),----------
    invoice_text          VARCHAR2(240),----------
    info_ar               VARCHAR2(240),
    special_handling      VARCHAR2(240),-------------
    gift                  VARCHAR2(240),
    minisite_id           VARCHAR2(240),------------
    customs_id            VARCHAR2(240),-----------
    sender_name           VARCHAR2(240),------------
    master_consign_id     VARCHAR2(240),-----------
    consignment_num       VARCHAR2(240),-----------
    consign_item_num      VARCHAR2(240),-----------
    reserved_amount       VARCHAR2(240),
    /* end wave 2 modification */
    ----------------------------------------
    orderlines order_line,
    /* Version 1.7 CR 1929 */
    invspecurl spec_url_line,
    /* start wave 2 modification */
    invprint inv_custom_print ,
    invaddr inv_customer_address,-- CR 4721
    lv_private_cust private_cust_line
    /* end wave 2 modification */
    ,
    credit_card_source VARCHAR2(240) --defect 3937-----------
    ,
    prepaid_amount NUMBER --defect 3922
    ,
    invoice_kid VARCHAR2(240)--defect 4086
    ,
    payment_term VARCHAR2(30)--CR 4813
  );



29)type order_head IS  TABLE OF orderhead_rec;


30)type batch_order_rec IS   record
  (
    batchid      VARCHAR2(240),
    batchnototal NUMBER,---number of orders in batch----
    batchdate    DATE,   --Batch Date
    -- Orderlinetotal    NUMBER, --Total number of orderlines in batch
    messagesequenceno NUMBER, --messagenumner of batch
    -- MaximumOrderDate     Date,  --Date of the highest Order in message
    --  MinimumOrderDate     Date,  --Date of the Lowest Order Number
    batchdetailcount   NUMBER, --Total number of orderlines in batch
    messagedetailcount NUMBER, --Number of orderlines in one message
    ---Version 1.4----
    messagedetailordercount NUMBER,  ---number of order headers in one message
    numberofmessages        NUMBER, ----total number of messages in a batch
    --InvoiceLines mltiple nodes
    v_order_head order_head,
    lv_shipment_head shipment_head);