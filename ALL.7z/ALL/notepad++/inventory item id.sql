i/p-inventory no,org id, order source, order type
o/p- inventory item id, warehouse id

FUNCTION getinventory_item_id(
      p_inventory_number IN VARCHAR2,
      p_order_source     IN VARCHAR2,
      p_order_type       IN VARCHAR2,
      p_org_id NUMBER )
    RETURN NUMBER
  IS
    ln_ret_val mtl_cross_references.inventory_item_id%type;
    lv_order_source VARCHAR2(240);
    lv_item_cross_ref mtl_cross_references.cross_reference%type;
    ln_warehouse_id    NUMBER;
    ln_order_source_id NUMBER;
    lv_item_no         VARCHAR2(240);
    lv_order_type      VARCHAR2(240);
    p_status_code      NUMBER;
    p_error_message    VARCHAR2(2000);
    ln_trans_type      NUMBER;
    ln_org_id          NUMBER;
  BEGIN
    lv_item_no     :=p_inventory_number;
    ln_org_id      :=p_org_id;
    lv_order_source:=p_order_source;
    lv_order_type  :=p_order_type;
    
    BEGIN
      
      /**check if item cross reference is set for order source*/
     
      BEGIN
        SELECT NVL(ffvv.attribute5,'N')
        INTO lv_item_cross_ref
        FROM fnd_flex_value_sets ffvs,
          fnd_flex_values ffvv
        WHERE ffvs.flex_value_set_name='XXCU_OM_SOURCE_ORDER_TYPE'
        AND ffvs.flex_value_set_id    =ffvv.flex_value_set_id
        AND upper(ffvv.flex_value)    =upper(lv_order_source);
      EXCEPTION
      WHEN OTHERS THEN
        lv_item_cross_ref := 'N';
      END;
      
	  
	  
      BEGIN
        ln_trans_type:= get_transaction_type_id(lv_order_source, lv_order_type, ln_org_id, p_status_code, p_error_message);
        xxcu_common_log_rt.msglog ('INFO', 'lv_order_source '||lv_order_source, 1117, '1', 'get_transaction_type_id', '-1' );
        xxcu_common_log_rt.msglog ('INFO', 'ln_org_id '||ln_org_id, 1117, '1', 'get_transaction_type_id', '-1' );
        xxcu_common_log_rt.msglog ('INFO', 'lv_order_type '||lv_order_type, 1117, '1', 'get_transaction_type_id', '-1' );
      EXCEPTION
      WHEN OTHERS THEN
        xxcu_common_log_rt.msglog ('ERR', 'Failed to derive transaction type id 6 '||sqlerrm||dbms_utility.format_error_backtrace, 1117, '1', 'get_transaction_type_id', '-1' );
        ln_trans_type:=NULL;
      END;
	  
	  
      BEGIN
        SELECT warehouse_id
        INTO ln_warehouse_id
        FROM oe_transaction_types_all
        WHERE transaction_type_id= ln_trans_type;
      EXCEPTION
      WHEN OTHERS THEN
        ln_warehouse_id:=NULL;
      END;
	  
	  
	  
      BEGIN
       
	   IF lv_item_cross_ref <>'N' THEN

	   SELECT mcr.inventory_item_id item_no
          INTO ln_ret_val
          FROM mtl_cross_references mcr,
            mtl_system_items_b msi
          WHERE msi.inventory_item_id =mcr.inventory_item_id
          AND msi.organization_id     =ln_warehouse_id
          AND upper(mcr.cross_reference_type) =upper(lv_item_cross_ref)
          AND upper(mcr.cross_reference)=upper(lv_item_no)
          AND (mcr.end_date_active      IS NULL
          OR TRUNC(mcr.end_date_active) >=TRUNC(sysdate));
       
	   ELSE
          
		  SELECT inventory_item_id item_no
          INTO ln_ret_val
          FROM mtl_system_items_b
          WHERE upper(segment1)      =upper(lv_item_no)
          AND enabled_flag           ='Y'
          AND (end_date_active      IS NULL
          OR TRUNC(end_date_active) >=TRUNC(sysdate))
          AND organization_id        =ln_warehouse_id;
        END IF;
        RETURN ln_ret_val;
      EXCEPTION
      WHEN OTHERS THEN
        ln_ret_val:=NULL;
        xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error: cant found item number: ' || p_inventory_number || ' ::Varenummeret m? legges inn i mappingtabell:: ' );
      END ;
	    
    END; 
    RETURN ln_ret_val;
  END;