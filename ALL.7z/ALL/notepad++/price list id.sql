i/p--currency code
o/p---price list id
exception ---label, msg

FUNCTION getpricelistid(
      p_name IN VARCHAR2)
    RETURN NUMBER
  AS
    v_ret_val   NUMBER;
    l_log_label VARCHAR2(2000);
    l_message   VARCHAR2(2000);
    k_func_name VARCHAR2(100):='getpricelistid';
  BEGIN
   

   BEGIN
      SELECT price_list_id
      INTO v_ret_val
      FROM oe_price_lists_v
      WHERE upper(currency_code)   = upper(p_name)
      AND (TRUNC(end_date_active) IS NULL
      OR TRUNC(end_date_active)   >=TRUNC(sysdate));
      /*Defect# 160*/
    EXCEPTION
    WHEN no_data_found THEN
      v_ret_val   := NULL;
      l_log_label := 'Price List';
      l_message   := 'Price List Not Found';
      xxcu_log_pkg.log(xxcu_log_pkg.gk_error, k_log_module_prefix || '.' || k_func_name || '.' || l_log_label , l_message, false);
    END;
    RETURN v_ret_val;
  END;