always null
pname(doubt)

FUNCTION getordersourceid(
      p_name IN VARCHAR2)
    RETURN NUMBER
  AS
    ln_order_source_id NUMBER;
    lv_order_source    VARCHAR2(200);
  BEGIN
   
   BEGIN
      /* start wave 2 modification */
      /*  SELECT order_source_id
      INTO v_order_source_id
      FROM oe_order_sources
      WHERE upper(name) = upper(p_name)
      AND enabled_flag  ='Y';*/
      SELECT NVL(upper(ffv.attribute1),upper(ffv.flex_value))
      INTO lv_order_source
      FROM fnd_flex_value_sets ffvs,
        fnd_flex_values ffv
      WHERE ffvs.flex_value_set_name='XXCU_OM_SOURCE_ORDER_TYPE'
      AND ffvs.flex_value_set_id    =ffv.flex_value_set_id
      AND upper(ffv.flex_value)     =upper(p_name)
      AND ffv.enabled_flag          ='Y';
    EXCEPTION
    WHEN no_data_found THEN
      lv_order_source := NULL;-----------------o/p null
    END;
   



   BEGIN
      SELECT order_source_id
      INTO ln_order_source_id
      FROM oe_order_sources
      WHERE upper(name) = upper(lv_order_source)
      AND enabled_flag  ='Y';
    EXCEPTION
    WHEN no_data_found THEN
      ln_order_source_id := NULL;
    END;
    /* end wave 2 modification */
   


   RETURN ln_order_source_id;
  END;