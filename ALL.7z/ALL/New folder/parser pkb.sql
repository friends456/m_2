create or replace PACKAGE body xxcu_ont_create_order_parser
  /* ===========================================================================================
  -- Module         : ONT
  -- Type           : PL/SQL - Package Body
  -- Filename       : $XXCU_TOP/admin/sql/XXCU_ONT_CREATE_ORDER_PARSER.pkb
  -- Author         : Rahul Kumar Singh
  -- Version        : 1.34
  -- Description    : This package contains parser for Create Order XML message.
  -- History
  Date         Name                 Version         Description
  21.12.2015  Rahul Kumar Singh        1.1          Initial Version - Inherited from PNAS
  22.02.2016  Vedangi Bagwe            1.2          Modified to handle multiple lines within single order header
  26.04.2016  Vedangi Bagwe            1.3          Change artf4774289 - Added pricing_date to order record type and removed conversion_date
  27.04.2016  Vaidehi Chobe            1.4          OU, Common Header and NFR changes
  27.06.2016  Vedangi Bagwe            1.5          Modified for Defect# 949 OM: OM: Order Import + Reconciliation Report: Reconciliation Fields require update. Plus XML tags need to be in sync with AN.100
  26.07.2016  Vedangi Bagwe            1.6          Modified for CR # 1093 Order Import: Additional Import Fields
  21.09.2016  Vedangi Bagwe            1.7          Modified for invoice specification CR 1899,1449
  09.10.2016  Vedangi Bagwe            1.8          Modified for CR 1929
  08.11.2016  Vedangi Bagwe            1.9          Modified for CR 2224, CR 2043, CR 2468
  20.11.2016  Rahul Singh              1.10         Modified for Invoice Specification Chnages.If no Inv Spec Node then Donot Insert in Custom Table
  07.02.2017  Vedangi Bagwe            1.11         Modified for Invoice Specification changes CR 3006
  16.02.2017  Vedangi Bagwe            1.12         Modified for Invoice Specification changes CR 3118
  31.03.2017  Vedangi Bagwe            1.13         Modified for CR 3374 Invoice Specification
  27.06.2017  Vijay Nambiar            1.14         Modified for Defect # 3528
  06.08.2017  Ankur Agrawal            1.15         Modified for Q2Q Propagation
  26.09.2017  Vedangi Bagwe            1.16         Modified for wave 2  artf5715512
  13.11.2017  Vedangi Bagwe            1.17         Modified for Defect 3702
  13.11.2017  Snehal Narkhede         1.17         Modified as per Defect -8523 ,Incident E2-IM014117169 --used substring to avoid data issue
  07.12.2017  Vedangi Bagwe            1.18         Modified for Defect 3937,3947
  14.12.2017  Vedangi Bagwe            1.19         Modified for Defect 3922,4086
  09.01.2018  Vedangi Bagwe            1.20         Modified for CR Private Customers artf5962829
  18.01.2018  Vedangi Bagwe            1.21         Modified for CR 4419
  24.01.2018  Vedangi Bagwe            1.22         Modified for CR 4475
  16.02.2018  Vedangi Bagwe            1.23         Modified for CR 4813
  20.02.2018  Vedangi Bagwe            1.24         Modified for CR 4721
  28.02.2018  Vedangi Bagwe            1.25         Modified for CR 5026
  05.03.2018  Vedangi Bagwe            1.26         Modified for CR 5144
  05.04.2018  Vedangi Bagwe            1.27         Modified for Defect 5344
  18.04.2018  Adi Narayana Reddy       1.28         Modified for CR 5280
  23.04.2018  Sayali Jog               1.29         Modified for defect 5484
  26.04.2018  Sayali Jog               1.30         Modified for defect 5439
  30.04.2018  Nikhil Gole              1.31         Modified for defect 5666
  30.04.2018  Nikhil Gole              1.32         Modified for defect 5649
  03.05.2018  Sayali Jog               1.33         MOdified for defect 5701 
  09.05.2018  Sayali Jog               1.33         MOdified for defect 5766 
  =============================================================================================== */
  /*$Header: XXCU_ONT_CREATE_ORDER_PARSER.pkb 115.svn-rev yyyy/mm/dd mi:ss CustomizationManager noship $*/
AS
  /* ----------------------------------------------------------------------------------------
  * parse_xmlmessage
  *
  *   Procedure     : parse_xmlmessage
  *   description   : procedure to parse the XML message
  *   scope         : public
  *   arguments
  *        in                    : ip_lob : lob data
  *                                ip_msgid : Message ID
  *
  *        in/out                :
  *
  *        out                   :op_status_code : Interface Status
  *                               op_error_message : Error Message
  *
  *  Date               Author              Description
  *  ---------         -------------        -------------------------------------------------------
  *  21.12.2015        Rahul Kumar Singh     Created
  ----------------------------------------------------------------------------------------*/
  PROCEDURE parse_xmlmessage(
      ip_lob   IN CLOB,
      ip_msgid IN VARCHAR2,
      op_status_code OUT NUMBER,
      op_error_message OUT nocopy VARCHAR2)
  IS
    txtstr            VARCHAR2 (32767);
    v_rootelementname VARCHAR2 (200 CHAR);
    header_exists     BOOLEAN := true;
    v_orderhead_rec orderhead_rec;
    v_orderline_rec orderline_rec;
    v_inv_spec_rec inv_spec_rec;
    v_inv_url_rec inv_spec_url_rec;
    v_inv_ref_rec inv_spec_ref_rec;
    /* start wave 2 modification */
    lv_inv_disc_spec inv_spec_disc_rec;
    lv_inv_custom_print_rec inv_custom_print_rec;
    lv_inv_customer_addr_rec inv_customer_address_rec;-- CR 4721
    lv_inv_private_cust_rec inv_private_cust_rec;
    lv_customer_address_rec customer_address_rec;
    lv_shipment_order_rec shipment_order_rec;
    lv_packagelines_rec packageline_rec;
    lv_terminal_rec terminal_rec;--CR 4419
    lv_pricelines_rec priceline_rec;
    /* end wave 2 modification */
    v_batch_order_rec batch_order_rec;
    --v_InvLines_rec           InvoiceLine_rec;
    --v_RevDistrib_rec         InvoiceDistribution_rec;
    --v_TaxDistrib_rec         InvoiceDistribution_rec;
    v_sbdhshort xxcu_intf_message_header.sbdh_rec;
    v_ec_header_object xxcu_intf_message_header.xxcu_header_objtype;
    v_inxmldom xdb.dbms_xmldom.domdocument;
    parser xdb.dbms_xmlparser.parser;
    style xdb.dbms_xslprocessor.stylesheet;
    curnode0 xdb.dbms_xmldom.domnode;
    curnode1 xdb.dbms_xmldom.domnode;
    curnode2 xdb.dbms_xmldom.domnode;
    curnode3 xdb.dbms_xmldom.domnode;
    curnode4 xdb.dbms_xmldom.domnode;
    curnode6 xdb.dbms_xmldom.domnode;
    curnode101 xdb.dbms_xmldom.domnode;
    curnode1234 xdb.dbms_xmldom.domnode;
    curnode2123 xdb.dbms_xmldom.domnode;
    curnode21235 xdb.dbms_xmldom.domnode;
    curnode2123778 xdb.dbms_xmldom.domnode;-- CR 4419
    curnode76543 xdb.dbms_xmldom.domnode;  -- CR 4721
    /* version 1.8 CR 1929 */
    curnode7 xdb.dbms_xmldom.domnode;
    curnode8 xdb.dbms_xmldom.domnode;
    curnode9 xdb.dbms_xmldom.domnode;
    curnode911 xdb.dbms_xmldom.domnode;
    curnode918766 xdb.dbms_xmldom.domnode;
    curnode91876611 xdb.dbms_xmldom.domnode;
    curnode10 xdb.dbms_xmldom.domnode;
    ----------------------------------------------------
    curnode xdb.dbms_xmldom.domnode;
    subinvnode xdb.dbms_xmldom.domnode;
    curnodename VARCHAR2 (300);
    childnodes xdb.dbms_xmldom.domnodelist;
    msg_msgheader xdb.dbms_xmldom.domnodelist;
    batch_order_proplist xdb.dbms_xmldom.domnodelist;
    shipment_order_proplist xdb.dbms_xmldom.domnodelist;
    order_head_proplist xdb.dbms_xmldom.domnodelist;
    package_lines_proplist xdb.dbms_xmldom.domnodelist;
    terminal_lines_proplist xdb.dbms_xmldom.domnodelist;-- CR 4419
    price_lines_proplist xdb.dbms_xmldom.domnodelist;
    order_lines_proplist xdb.dbms_xmldom.domnodelist;
    spec_lines_proplist xdb.dbms_xmldom.domnodelist;
    spec_lines_proplist_new xdb.dbms_xmldom.domnodelist;
    /* version 1.8 CR 1929 */
    spec_url_proplist xdb.dbms_xmldom.domnodelist;
    spec_url_proplist_to xdb.dbms_xmldom.domnodelist;
    inv_attachment_proplist xdb.dbms_xmldom.domnodelist;
    inv_custom_print_proplist xdb.dbms_xmldom.domnodelist;
    inv_customer_addr_proplist xdb.dbms_xmldom.domnodelist;-- CR 4721
    inv_private_cust_proplist xdb.dbms_xmldom.domnodelist;
    inv_private_cust_addr_proplist xdb.dbms_xmldom.domnodelist;
    spec_ref_proplist xdb.dbms_xmldom.domnodelist;
    spec_inv_disc_proplist xdb.dbms_xmldom.domnodelist;
    --------------------------------------------------------------------------
    -- inv_spec_lines_proplist xdb.DBMS_XMLDOM.domnodelist;
    thedocelt xdb.dbms_xmldom.domelement;
    msg_msgheader_url VARCHAR2 (200 CHAR) := '/OEOrderImport/Header';
    msg_bo_root_url   VARCHAR2 (200 CHAR) := '/OEOrderImport/Order/Batch';
    /* start wave 2 modification */
    msg_shipment_order_url VARCHAR2(200 CHAR):='/OEOrderImport/Order/Batch/Shipment';
    msg_pkg_lines_url      VARCHAR2(200 CHAR):='/OEOrderImport/Order/Batch/Shipment/Package';
    msg_price_lines_url    VARCHAR2(200 CHAR):='/OEOrderImport/Order/Batch/Shipment/PriceLine';
    /* end wave 2 modification */
    --      msg_orderhead_url     VARCHAR2 (200 CHAR)               := '/OECreateOrder/CreateOrder/OrderHeads/OrderHead';
    --      msg_orderline_url       VARCHAR2 (200 CHAR)               := '/OECreateOrder/CreateOrder/OrderHeads/OrderHead/OrderLines/OrderLine';
    msg_orderhead_url   VARCHAR2 (200 CHAR) := '/OEOrderImport/Order/Batch/OrderHeader';
    msg_orderline_url   VARCHAR2 (200 CHAR) := '/OEOrderImport/Order/Batch/OrderHeader/OrderLine';
    msg_invspec_url     VARCHAR2(200 CHAR)  :='/OEOrderImport/Order/Batch/OrderHeader/OrderLine/InvoiceSpecification';
    msg_invspecline_url VARCHAR2(200 CHAR)  :='/OEOrderImport/Order/Batch/OrderHeader/OrderLine/InvoiceSpecification/InvoiceSpecificationLines';
    c_recou_xpath       VARCHAR2(200 CHAR)  := '/OEOrderImport/OperatingUnit'; --ADDED FOR OU CHANGE
    -------------------------------------------------------------
    -- ERR_CODE, ERR_MESSAGE
    --------------------------------------------------------------
    v_msgid          VARCHAR2 (20 CHAR) := '1117';
    v_msgid_rcv      VARCHAR2 (20 CHAR);
    v_sentfrom       VARCHAR2 (20 CHAR);
    v_job_id         VARCHAR2 (20 CHAR);
    v_retry_attempts VARCHAR2 (20 CHAR) := '1';
    v_dboperation    VARCHAR2 (20 CHAR);
    v_trpartnerid    VARCHAR2 (30 CHAR);
    v_trpartnername  VARCHAR2 (100 CHAR) := 'eConnect';
    v_db_timestamp   VARCHAR2 (30 CHAR);
    v_dbtstamp       VARCHAR2 (30 CHAR);
    v_xdijobdate     DATE;
    v_msg_version    VARCHAR2 (30 CHAR) := '0.1';
    dummydate        DATE;
    dummychar        VARCHAR2 (80 CHAR);
    dummyocmchar     VARCHAR2 (80 CHAR);
    dummycode        NUMBER;
    invline_no       NUMBER             := 0;
    revline_no       NUMBER             := 0;
    taxline_no       NUMBER             := 0;
    v_null_value     VARCHAR2 (30 CHAR) := NULL;
    olob CLOB;
    v_order_line order_line        := order_line ();
    v_order_head order_head        := order_head ();
    lv_shipment_head shipment_head :=shipment_head();
    v_spec_line spec_line          := spec_line ();
    v_spec_url spec_url_line       := spec_url_line ();
    /* start wave 2 modification */
    lv_inv_custom_print inv_custom_print      :=inv_custom_print();
    lv_inv_customer_addr inv_customer_address :=inv_customer_address(); -- CR 4721
    lv_private_cust private_cust_line         :=private_cust_line();
    lv_private_cust_addr address_lines        :=address_lines();
    lv_packagelines package_lines             :=package_lines();
    lv_terminal terminal_lines                :=terminal_lines();-- CR 4419
    lv_pricelines price_lines                 :=price_lines();
    /* end wave 2 modification */
    v_status_code   NUMBER          := 0;
    v_error_message VARCHAR2 (2000) := 'none';
    v_aggregate     VARCHAR2 (1);
    l_message_header xxcu_intf_ec411gheader_pkg.ec411gmessageheader_type;
    l_timestamp_start TIMESTAMP;
    l_timestamp_end   TIMESTAMP;
    pragma autonomous_transaction;
    startdate      DATE := sysdate;
    v_node         VARCHAR2 (2000);
    v_customerno   VARCHAR2 (100);
    v_po_reference VARCHAR2 (100);
    v_order_source VARCHAR2 (100);
    --v_order_source_id     NUMBER;
    v_order_type              VARCHAR2 (100);
    v_order_reference         VARCHAR2 (100);
    v_ret_order_reference     VARCHAR2 (100);
    v_cc_ref_id               VARCHAR2 (100);
    v_org_id                  VARCHAR2 (100);
    v_invoice_attachment_file VARCHAR2(100);
    v_customer_ref            VARCHAR2 (100);
    v_autotwist_invoice       VARCHAR2 (100);
    v_charteque_number        VARCHAR2 (100);
    v_date                    DATE;
    v_valuta_code             VARCHAR2 (100);
    --v_source               VARCHAR2 (100);
    v_price_list_id             VARCHAR2 (100);
    v_payment_type_code         VARCHAR2 (100);
    v_sales_agmnt_no            VARCHAR2 (100);
    v_stamps_agreement_type   VARCHAR2 (240);  --Added by Sayali for defect 5766
    v_pricing_date              DATE;
    v_msg_detail_order          NUMBER;
    v_order_num                 NUMBER;
    v_total_msg                 NUMBER;
    v_agreement_name            VARCHAR2(240);
    v_msg_to_cust               VARCHAR2(240);
    v_payment_provider_trans_id VARCHAR2(100);
    -- v_org_id number;
    v_exclude_from_dunning VARCHAR2(100);
    v_last_customerno      VARCHAR2 (100) := '-1';
    v_last_date            DATE           := to_date('01011900','ddmmyyyy');
    v_last_valuta_code     VARCHAR2 (100) := '-1';
    v_last_source          VARCHAR2 (100) := '-1';
    /*v_bulk_head           BOOLEAN := false;*/
    v_indexh    NUMBER                       := 0;
    v_indexl    NUMBER                       := 0;
    c_proc_name CONSTANT VARCHAR2 (200 CHAR) := 'parsexml_message';
    v_aggr_order_head order_head             := order_head ();
    --CHANGED FOR OU
    l_recou_nlist xdb.dbms_xmldom.domnodelist;
    r_ou_exp_rec xxcu_int_opr_unit_pkg.xxcu_int_operating_unit;
    ln_org_id           NUMBER;--collects org_id from ankur's procedure
    e_error             EXCEPTION;
    l_proc_loc          VARCHAR2 (2000 CHAR) := 'declare';
    l_msg_job_id        VARCHAR2 (100);
    v_prepay_flag       VARCHAR2(100);
    v_settle_flag       VARCHAR2(100);---added by vijay on 27-jun-2017 for defect 3528
    v_date_from         DATE;
    v_date_to           DATE;
    v_description       VARCHAR2(1000);
    v_order_date        DATE;
    v_quantity          NUMBER;
    c_payload_xpath     VARCHAR2(200);
    v_uom               VARCHAR2(100);
    v_per_time_unit     VARCHAR2(100);
    v_unit_price        NUMBER;
    v_amount            NUMBER;
    v_waybill           NUMBER;
    v_sender            VARCHAR2(1000);
    v_receiver          VARCHAR2(1000);
    v_ship_from         VARCHAR2(1000);
    v_ship_to           VARCHAR2(1000);
    v_no_pkg            NUMBER;
    v_pallet            VARCHAR2(1000);
    v_volume            VARCHAR2(1000);
    v_weight            NUMBER;
    v_freight           VARCHAR2(1000);
    v_person            VARCHAR2(1000);
    v_pp_price          NUMBER;
    v_cargo_type        VARCHAR2(1000);
    lv_project_ref      VARCHAR2(240);
    lv_printed_order_no NUMBER;
    lv_addr_type        VARCHAR2(40);
    lv_payment_term     VARCHAR2(30);
    /* start wave 2 modification */
    lv_contract_num          VARCHAR2(240);
    lv_contract_modifier_num VARCHAR2(240);
    lv_bill_details          VARCHAR2(240);
    lv_waiting_date          VARCHAR2(240);
    lv_handling_date         VARCHAR2(240);
    lv_payment_method        VARCHAR2(240);
    lv_inv_text              VARCHAR2(240);
    lv_info_ar               VARCHAR2(240);
    lv_special_handling      VARCHAR2(240);
    lv_gift                  VARCHAR2(240);
    lv_minisite_id           VARCHAR2(240);
    lv_customs_id            VARCHAR2(240);
    lv_sender_name           VARCHAR2(240);
    lv_master_consign_id     VARCHAR2(240);
    lv_consignment_num       VARCHAR2(240);
    lv_consign_item_num      VARCHAR2(240);
    lv_reserved_amount       VARCHAR2(240);
    lv_credit_card_source    VARCHAR2(240);--defect 3937
    ln_prepaid_amount        NUMBER;       --defect 3922
    lv_invoice_kid           VARCHAR2(240);--defect 4086
--    v_blanket_number         VARCHAR2(50); --added by sayali for defect 5484
    /* end wave 2 modification */
    /* start CR 3118 */
    v_ref_line spec_ref_line:=spec_ref_line();
    /* end CR 3118 */
    /* start wave 2 modification */
    lv_inv_spec_disc spec_inv_disc:=spec_inv_disc();
    /* end wave 2 modification */
    -------------------------------------------------------------------------------------------------------------------------
    --c_recou_xpath
    --CHANGED FOR OU
    -------------------------------------------------------------
  BEGIN
  
    --- Changes by Ankur for Q2Q
	
    IF ip_msgid               = '1255' THEN
      msg_msgheader_url      := '/PPOrderImport/Header';
      msg_bo_root_url        := '/PPOrderImport/Order/Batch';
      msg_orderhead_url      := '/PPOrderImport/Order/Batch/OrderHeader';
      msg_orderline_url      := '/PPOrderImport/Order/Batch/OrderHeader/OrderLine';
      msg_invspec_url        :='/PPOrderImport/Order/Batch/OrderHeader/OrderLine/InvoiceSpecification';
      msg_invspecline_url    :='/PPOrderImport/Order/Batch/OrderHeader/OrderLine/InvoiceSpecification/InvoiceSpecificationLines';
      c_recou_xpath          := '/PPOrderImport/OperatingUnit'; --ADDED FOR OU CHANGE
      msg_shipment_order_url :='/PPOrderImport/Order/Batch/Shipment';
      msg_pkg_lines_url      :='/PPOrderImport/Order/Batch/Shipment/Package';
      msg_price_lines_url    :='/PPOrderImport/Order/Batch/Shipment/PriceLine';
      msgid                  := '1255';
    END IF;
    
	-----End Q2Q change
	
    v_msgid := ip_msgid;
    msgsrc  := 'xxcu_ont_create_order_parser BODY.parse_xmlmessage';

    --<mhs:MsgId>203</mhs:MsgId> for LM order
    --IF ( SUBSTR(ip_lob, INSTR(ip_lob, 'mhs:MsgId')+(LENGTH('mhs:MsgId')+1),3) = '203') THEN
    --Code for LM

    msgjobid := xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => v_msgid, ip_source => msgsrc, ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL );
    --
    -- create tmp CLOB for message body
    olob := xxcu_common_util.createtmpclob;
    dbms_lob.open (olob, 1);
    olob := ip_lob;
	
    ---   supress header's schema declaration
    --xxcu_common_util_xml.removelmxmlschemas (ip_msgid => v_msgid, ip_xmlwschems => olob, rsstatus => header_exists);--CHANGED FOR OU
    xxcu_common_util_xml.removexmlschemasec4 (ip_msgid => v_msgid, ip_xmlwschems => olob, rsstatus => header_exists);--ADDED FOR OU CHANGE
    -- test only
    -- Msggen.saveclobout ('-1', 'test', olob);
    -----------------------------------------------------------------------------------------------------------------------------------------------------
    msgtext := 'parsing Event description';
	
    ----xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
	
    msgtext := 'Calling XDB.DBMS_XMLPARSER.newparser';
    parser  := xdb.dbms_xmlparser.newparser;
    msgtext := 'Calling XDB.DBMS_XMLPARSER.parseclob';
    xdb.dbms_xmlparser.parseclob (parser, olob);
    msgtext    := 'Calling XDB.DBMS_XMLPARSER.getdocument';
    v_inxmldom := xdb.dbms_xmlparser.getdocument (parser);
    msgtext    := 'Calling XDB.DBMS_XMLPARSER.freeparser';
    xdb.dbms_xmlparser.freeparser (parser);
    -- 0
    msgtext           := 'Calling XDB.DBMS_XMLDOM.getdocumentelement';
    thedocelt         := xdb.dbms_xmldom.getdocumentelement(v_inxmldom);
    msgtext           := 'Calling XDB.DBMS_XMLDOM.getlocalname';
    v_rootelementname := xdb.dbms_xmldom.getlocalname(thedocelt);
    msgtext           := 'Calling xxcu_common_util_xml.selectnodes';
    msg_msgheader     := xxcu_common_util_xml.selectnodes(v_inxmldom, msg_msgheader_url);
	
    --CHANGED FOR OU
    msgtext := 'Calling XXCU_INTF_EC411GHEADER_PKG.parse_header';
    dbms_output.put_line('In  xxcu_intf_ec411gheader_pkg.parse_header');
    xxcu_intf_ec411gheader_pkg.parse_header( header_in => msg_msgheader, msgid_in => v_msgid, jobid_in => v_job_id, header_out => l_message_header);
    msgtext := 'source system ' || l_message_header.sourcesystem;
    xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => msgtext, msgcode => v_msgid, usermsg => '1', -- not sure what this is, maps to user_id in log table
    msgsrc => msgsrc || '.' || c_proc_name, msgjobid => v_job_id);
	
    -- Log results of message header parsing
    msgtext := 'Called XXCU_INTF_EC411GHEADER_PKG.parse_header, Message ID is: ' || l_message_header.messageid;
    xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => msgtext, msgcode => v_msgid, usermsg => '1', -- not sure what this is, maps to user_id in log table
    msgsrc => msgsrc || '.' || c_proc_name, msgjobid => v_job_id);
    -- Log progress
    l_timestamp_end := systimestamp;
    msgtext         := 'Parsing message header completed (seconds elapsed: ' || extract(second FROM (l_timestamp_end - l_timestamp_start)) || ')';
    xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => msgtext, msgcode => v_msgid, usermsg => '1', -- not sure what this is, maps to user_id in log table
    msgsrc => msgsrc || '.' || c_proc_name, msgjobid => v_job_id);
    l_timestamp_start := systimestamp;
    --CHANGED FOR OU
    ----  Generic call
    --msgtext := 'Calling xxcu_intf_mhparser.get_sbdh';
    --xxcu_intf_mhparser.get_sbdh (ip_msgheader => msg_msgheader, ip_msgid => v_msgid, ip_jobid => v_job_id, op_sbdhshort => v_sbdhshort);
    /* v_ec_header_object.ecmessageid := v_msgid;
    v_ec_header_object.sourceref := v_sbdhshort.job_id;
    v_ec_header_object.VERSION := v_msg_version;
    v_ec_header_object.username := v_trpartnername;
    v_ec_header_object.securitytoken := NULL;
    v_ec_header_object.systemcode := 'ECONOMY';
    v_ec_header_object.timestamppublish := TO_DATE (NVL (v_sbdhshort.db_date_change, SYSDATE), xxcu_intf_sys.gc_longdatetimeformat);
    v_ec_header_object.timestampecin := TO_DATE (NVL (v_sbdhshort.db_date_change, SYSDATE), xxcu_intf_sys.gc_longdatetimeformat);
    v_ec_header_object.timestampecout := TO_DATE (SYSDATE, xxcu_intf_sys.gc_longdatetimeformat);
    v_ec_header_object.timestampsubscribe := TO_DATE (SYSDATE, xxcu_intf_sys.gc_longdatetimeformat);
    /*--------------------------------------------------------------------------------------------------------------------------------------------------------------
    List of message /objects nodes
    --------------------------------------------------------------------------------------------------------------------------------------------------------------
    1 '/ECOClientInvoice/ClientInvoice';
    2 '/ECOClientInvoice/ClientInvoice/ReceivablesDistribution';
    3 '/ECOClientInvoice/ClientInvoice/InvoiceLines/InvoiceLine';
    4 '/ECOClientInvoice/ClientInvoice/InvoiceLines/RevenueDistribution';
    5 '/ECOClientInvoice/ClientInvoice/InvoiceLines/TaxDistribution';
    --------------------------------------------------------------------------------------------------------------------------------------------------------------
    header_exists := TRUE;
    IF header_exists THEN
    */
    ------------------------------------------------------------------------------------------------------------------------------------------------------------------ node 1
    --CHANGED FOR OU
    msgtext := 'parsing selectnodes';
    IF(l_message_header.sourcesystem LIKE '%LM%') THEN
      batch_order_proplist := xxcu_common_util_xml.selectnodes (v_inxmldom, '/OEOrderImport/Order/Batch');
    ELSE
      batch_order_proplist := xxcu_common_util_xml.selectnodes (v_inxmldom, msg_bo_root_url);
    END IF;
    --CHANGED FOR OU
    --ADDED FOR OU
    -------Deriving OU information
    l_proc_loc    := 'Getting OU information nodes';
    l_recou_nlist := xxcu_common_util_xml.selectnodes (v_inxmldom, c_recou_xpath);
    --l_recou_nlist := xmldom.getelementsbytagname(v_inxmldom, 'OperatingUnit');
    -- Parse the org information
    l_proc_loc := 'Calling XXCU_INTF_EC411GHEADER_PKG.parse_org_info';
    xxcu_intf_ec411gheader_pkg.parse_org_info( p_org_info_in => l_recou_nlist, p_msgid_in => v_msgid, p_jobid_in => l_msg_job_id, p_org_rec_out => r_ou_exp_rec);
    -- Log results of org parsing
    l_proc_loc := 'Called XXCU_INTF_EC411GHEADER_PKG.parse_org_info '||r_ou_exp_rec.ou_unit_number ;                                --added by Subhrakant on 9th Sep
    xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => l_proc_loc, msgcode => v_msgid, usermsg => '1', -- not sure what this is, maps to user_id in log table
    msgsrc => msgsrc || '.' || c_proc_name, msgjobid => l_msg_job_id);
    -- Log progress
    l_timestamp_end := systimestamp;
    l_proc_loc      := 'Parsing message org completed (seconds elapsed: ' || extract(second FROM (l_timestamp_end - l_timestamp_start)) || ')';
    ln_org_id       := to_number(xxcu_int_opr_unit_pkg.get_ou_inbound(r_ou_exp_rec, v_msgid));
    --Log Process
    xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => 'Org-id -'||ln_org_id, msgcode => v_msgid, usermsg => '1', -- not sure what this is, maps to user_id in log table
    msgsrc => msgsrc || '.' || c_proc_name, msgjobid => l_msg_job_id);
    IF ln_org_id IS NULL THEN
      l_proc_loc := 'Error deriving OU information';
      raise e_error;
    END IF;
    --ADDED FOR OU
    FOR b IN 1 .. xdb.dbms_xmldom.getlength (batch_order_proplist)
    LOOP
      curnode1 := xdb.dbms_xmldom.item (batch_order_proplist, b - 1);
      msgsrc   := 'xxcu_ont_create_order_parser BODY.parse_xmlmessage';
      msgtext  := 'parsing Create Order Header node';
      ----xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
      v_batch_order_rec.batchid      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1, 'BatchID'))), v_null_value);
      v_batch_order_rec.batchnototal := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1, 'BatchNoTotal'))), v_null_value);
      -- v_batch_order_rec.Batchdate    := to_date(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1, 'BatchDate'))),'DD-MON-YY HH24:MI:SS');
      v_batch_order_rec.batchdate :=to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode1,'BatchDate'))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
      -- v_batch_order_rec.Orderlinetotal := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1, 'OrderLineTotal'))), v_null_value);
      /* v_batch_order_rec.Maximumorderdate :=
      to_date(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1, 'MaximumOrderDate'))),'DD-MON-YY HH24:MI:SS');
      v_batch_order_rec.Minimumorderdate :=
      to_date(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1, 'MinimumOrderDate'))),'DD-MON-YY HH24:MI:SS');
      */
      v_batch_order_rec.messagesequenceno  := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1, 'MessageSequenceNo'))), v_null_value);
      v_batch_order_rec.batchdetailcount   := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1, 'OrderLineTotal'))), v_null_value);
      v_batch_order_rec.messagedetailcount := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1, 'MessageDetailCount'))), v_null_value);
      ---version 0.5-------
      v_batch_order_rec.messagedetailordercount := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1, 'MessageDetailOrderCount'))), v_null_value);
      v_batch_order_rec.numberofmessages        := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1, 'NumberOfMessages'))), v_null_value);
      msgsrc                                    := 'xxcu_ont_create_order_parser BODY.parse_xmlmessage';
      msgtext                                   := 'Create Batch Order Header parsed :' || '  v_batch_order_rec.BatchID : ' || v_batch_order_rec.batchid || '; v_batch_order_rec.Batchnototal : ' || v_batch_order_rec.batchnototal || '; v_batch_order_rec.Batchdate : ' || v_batch_order_rec.batchdate || '; v_batch_order_rec.BatchDetailCount : ' || v_batch_order_rec.batchdetailcount || ';v_batch_order_rec.Messagesequenceno : ' || v_batch_order_rec.messagesequenceno || ';v_batch_order_rec.messagedetailcount : ' || v_batch_order_rec.messagedetailcount;
      xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
      -- node 2, continue: ReceivablesDistribution
      order_head_proplist := xxcu_common_util_xml.selectnodes (v_inxmldom, msg_orderhead_url);
      msgtext             := 'antall ordrehoder: ' || xdb.dbms_xmldom.getlength (order_head_proplist);
      xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
      v_order_head := order_head ();
      v_order_head.extend (xdb.dbms_xmldom.getlength (order_head_proplist));
     
	 FOR c IN 1 .. xdb.dbms_xmldom.getlength (order_head_proplist)
      LOOP
        curnode2    := xdb.dbms_xmldom.item (order_head_proplist, c - 1);
        v_aggregate := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'AggregateHead'))), v_null_value);
		
        /* v_organizational_unit :=
        NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'OrganizationalUnit'))), v_null_value);*/
		
        v_customerno := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'CustomerNumber'))), v_null_value);
        /* version 1.9 CR 2224*/
        lv_printed_order_no := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'PrintedOrderNumber'))), v_null_value);
        ---------------------------------------------------------------------------------------------------------------------------------------------------------------
        msgtext := 'customer number ' || v_customerno;
        xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
        v_po_reference := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'POReference'))), v_null_value);
		
        --Can be derived from the ordered date and customer number(Order number is the return value)
        v_sales_agmnt_no := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'SalesAgreementNumber'))), v_null_value);
        v_stamps_agreement_type := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'StampsAgreementType'))), v_null_value); --Added by Sayali for defect 5766
		
        --v_order_source   := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'OrderSource'))), v_null_value);
        --v_order_source_id     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'OrderSourceId'))), v_null_value);
        v_order_type          := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'OrderType'))), v_null_value);
        v_order_reference     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'OrderReference'))), v_null_value);
        v_ret_order_reference := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'ReturnOrderReference'))), v_null_value);
	
	
        --v_date                      := TO_DATE (NVL (REPLACE (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'Date'))), 'T', ''), v_null_value ), 'DD-MON-YY HH24:MI:SS' );
     /* Start of 5439*/
     IF v_msgid                   = '1255' THEN
      v_date        := to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode2,'OrderDate'))), v_null_value),'T',' '), 'RRRR-MM-DD HH24:MI:SS');--xxcu_intf_sys.gc_xmldatetimeformat);--modified for defect 5439--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); 
      ELSE
       v_date        := to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode2,'OrderedDate'))), v_null_value),'T',' '), 'RRRR-MM-DD HH24:MI:SS');
        END IF;
        /* End of 5439*/
        v_valuta_code := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'TransactionalCurrencyCode'))), v_null_value);
        v_cc_ref_id   := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'CreditCardReferenceID'))), v_null_value);
        --v_org_id                    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'OperatingUnit'))), v_null_value);
        v_customer_ref      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'CustomerReference'))), v_null_value);
        v_autotwist_invoice := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'AutoTwistInvoice'))), v_null_value);
        v_charteque_number  := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'ChartequeNumber'))), v_null_value);
        v_price_list_id     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'PriceList'))), v_null_value);
        v_payment_type_code := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'PaymentTypeCode'))), v_null_value);
        /* version 0.3  Change artf4774289 */
        -- v_pricing_Date           := TO_DATE (NVL (REPLACE (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'PricingDate'))), 'T', ''), v_null_value ), 'DD-MON-YY HH24:MI:SS' );
        v_pricing_date :=to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode2,'PricingDate'))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
        msgtext        := 'pricing date ' || v_pricing_date;
        xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
        v_payment_provider_trans_id := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'PaymentProviderTransID'))), v_null_value);
        v_exclude_from_dunning      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'ExcludeFromDunning'))), v_null_value);
        --v_invoice_attachment_file   := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'InvoiceAttachmentFile'))), v_null_value);
        /* version 0.6 */
        v_msg_to_cust    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'MessageToCustomer'))), v_null_value);
        v_agreement_name := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'AgreementName'))), v_null_value);
        lv_project_ref   :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'ProjectReference'))), v_null_value);
        v_prepay_flag    :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'PrePaymentFlag'))), v_null_value);
        msgtext          := 'Prepay:'||v_prepay_flag;
        xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
        v_settle_flag :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'SettlementFlag'))), v_null_value);---added by vijay on 27-jun-2017 for defect 3528
        msgtext       := 'Settlement:'||v_settle_flag;                                                                                         ---added by vijay on 27-jun-2017 for defect 3528
        /* start CR 4813 */
        lv_payment_term:=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'PaymentTerm'))), v_null_value);
        msgtext        := 'Payment Term:'||lv_payment_term;
        /* end CR 4813 */
        /* start wave 2 modification */
        lv_contract_num          :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'ContractNumber'))), v_null_value);
        msgtext                  := 'ContractNumber:'||lv_contract_num;
        lv_contract_modifier_num :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'ContractModifierNumber'))), v_null_value);
        msgtext                  := 'ContractModifierNumber:'||lv_contract_modifier_num;
        lv_bill_details          :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'BillInstallmentDetails'))), v_null_value);
        msgtext                  := 'BillInstallmentDetails:'||lv_bill_details;
        lv_waiting_date          :=to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode2,'WaitingDate'))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
        msgtext                  := 'WaitingDate:'||lv_waiting_date;
        lv_handling_date         :=to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode2,'HandlingDate'))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
        msgtext                  := 'HandlingDate:'||lv_handling_date;
        lv_payment_method        :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'PaymentMethod'))), v_null_value);
        msgtext                  := 'PaymentMethod:'||lv_payment_method;
        lv_inv_text              :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'InvoiceText'))), v_null_value);
        msgtext                  := 'InvoiceText:'||lv_inv_text;
        lv_info_ar               :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'InformationAR'))), v_null_value);
        msgtext                  := 'InformationAR:'||lv_info_ar;
        lv_special_handling      :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'SpecialHandling'))), v_null_value);
        msgtext                  := 'SpecialHandling:'||lv_special_handling;
        lv_gift                  :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'Gift'))), v_null_value);
        msgtext                  := 'Gift:'||lv_gift;
        lv_minisite_id           :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'MinisiteID'))), v_null_value);
        msgtext                  := 'MinisiteID:'||lv_minisite_id;
        lv_customs_id            :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'CustomsID'))), v_null_value);
        msgtext                  := 'CustomsID:'||lv_customs_id;
        lv_sender_name           :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'SenderName'))), v_null_value);
        msgtext                  := 'SenderName:'||lv_sender_name;
        lv_master_consign_id     :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'MasterConsignmentId'))), v_null_value);
        msgtext                  := 'MasterConsignmentId:'||lv_master_consign_id;
        xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
        lv_consignment_num :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'ConsignmentNumber'))), v_null_value);
        msgtext            := 'ConsignmentNumber:'||lv_consignment_num;
        xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
        lv_consign_item_num :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'ConsignmentItemNumber'))), v_null_value);
        msgtext             := 'ConsignmentItemNumber:'||lv_consign_item_num;
        xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
        lv_reserved_amount :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'ReservedAmount'))), v_null_value);
        msgtext            := 'ReservedAmount:'||lv_reserved_amount;
        /* start defect 3937 */
        lv_credit_card_source :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'CreditCardSource'))), v_null_value);
        msgtext               := 'Credit card Source:'||lv_credit_card_source;
        /* end */
        /* start defect 3922,4086 */
        ln_prepaid_amount :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'PrepaidAmount'))), v_null_value);
        msgtext           := 'Prepaid Amount:'||ln_prepaid_amount;
        lv_invoice_kid    :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'InvoiceKID'))), v_null_value);
        if lv_invoice_kid is null then
        lv_invoice_kid    :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'PaymentId'))), v_null_value);  --Added by Nikhil for defect 5666
        end if;
        
        msgtext           := 'Invoice Kid:'||lv_invoice_kid;
        /* end*/
        /* end wave 2 modification */
        xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
        /* start wave 2 modification */
        /* start artifact artf5962829 */
        lv_private_cust             := private_cust_line ();
        IF v_msgid                   = '1255' THEN
          inv_private_cust_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/PPOrderImport/Order/Batch/OrderHeader['||c||']/CreateCustomer'); -- Q2Q change
        ELSE
          inv_private_cust_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/OEOrderImport/Order/Batch/OrderHeader['||c||']/CreateCustomer');
        END IF;
        lv_private_cust.extend (xdb.dbms_xmldom.getlength (inv_private_cust_proplist));
        FOR priv_cust IN 1 .. xdb.dbms_xmldom.getlength (inv_private_cust_proplist)
        LOOP
          curnode918766                               := xdb.dbms_xmldom.item (inv_private_cust_proplist, priv_cust - 1);
          v_node                                      := 'CustomerReference';
          lv_inv_private_cust_rec.customer_reference  := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode918766, 'CustomerReference'))), v_null_value );
          v_node                                      := 'PrivateCustomerNumber';
          lv_inv_private_cust_rec.private_cust_number := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode918766, 'PrivateCustomerNumber'))), v_null_value );
          v_node                                      := 'DigiID';
          lv_inv_private_cust_rec.digi_id             := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode918766, 'DigiID'))), v_null_value );
          --   msgtext                                    := 'goods_total_value:'||lv_inv_custom_print_rec.goods_total_value;
          --  xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
          v_node                             := 'PersonFirstName';
          lv_inv_private_cust_rec.first_name := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode918766, 'PersonFirstName'))), v_null_value );
          msgtext                            := 'PersonFirstName:'||lv_inv_private_cust_rec.first_name;
          xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
          v_node                                := 'PersonLastName';
          lv_inv_private_cust_rec.last_name     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode918766, 'PersonLastName'))), v_null_value );
          v_node                                := 'PersonDateofBirth';
          lv_inv_private_cust_rec.date_of_birth := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode918766, 'PersonDateofBirth'))), v_null_value );--to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode918766,'PersonDateofBirth'))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
          /* CR 5144 */
          v_node                                := 'DistributionFlag';
          lv_inv_private_cust_rec.distribution_flag := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode918766, 'DistributionFlag'))), v_null_value );--to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode918766,'PersonDateofBirth'))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
          /* end CR 5144 */
          /* start CR 5026 */
          v_node                             := 'FARNumber';
          lv_inv_private_cust_rec.far_number := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode918766, 'FARNumber'))), v_null_value );--to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode918766,'PersonDateofBirth'))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
          /* end CR 5026 */
          IF v_msgid                        = '1255' THEN
            inv_private_cust_addr_proplist := xxcu_common_util_xml.selectnodes (curnode918766, '/PPOrderImport/Order/Batch/OrderHeader['||c||']/CreateCustomer['||priv_cust||']/Address'); -- Q2Q change
          ELSE
            inv_private_cust_addr_proplist := xxcu_common_util_xml.selectnodes (curnode918766, '/OEOrderImport/Order/Batch/OrderHeader['||c||']/CreateCustomer['||priv_cust||']/Address');
          END IF;
          lv_private_cust_addr:=address_lines();
          lv_private_cust_addr.extend (xdb.dbms_xmldom.getlength (inv_private_cust_addr_proplist));
          FOR priv_cust_addr IN 1 .. xdb.dbms_xmldom.getlength (inv_private_cust_addr_proplist)
          LOOP
            curnode91876611                  := xdb.dbms_xmldom.item (inv_private_cust_addr_proplist, priv_cust_addr - 1);
            v_node                           := 'Address1';
            lv_customer_address_rec.address1 := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode91876611, 'Address1'))), v_null_value );
            msgtext                          := 'Address1:'||lv_customer_address_rec.address1;
            xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
            v_node                              := 'Address2';
            lv_customer_address_rec.address2    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode91876611, 'Address2'))), v_null_value );
            v_node                              := 'Address3';
            lv_customer_address_rec.address3    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode91876611, 'Address3'))), v_null_value );
            v_node                              := 'City';
            lv_customer_address_rec.city        := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode91876611, 'City'))), v_null_value );
            v_node                              := 'PostalCode';
            lv_customer_address_rec.postal_code := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode91876611, 'PostalCode'))), v_null_value );
            v_node                              := 'Country';
            lv_customer_address_rec.country     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode91876611, 'Country'))), v_null_value );
            msgtext                             := 'Country:'||lv_customer_address_rec.country;
            xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
            IF(v_msgid        ='1255') THEN
              c_payload_xpath:='/PPOrderImport/Order/Batch/OrderHeader['||c||']/CreateCustomer['||priv_cust||']/Address';
            ELSE
              c_payload_xpath:='/OEOrderImport/Order/Batch/OrderHeader['||c||']/CreateCustomer['||priv_cust||']/Address';
            END IF;
            BEGIN
              SELECT extractvalue(xml_data, c_payload_xpath
                ||'['
                ||priv_cust_addr
                ||']'--defect 3450
                ||'/@AddressType[1]') attr_value
              INTO lv_addr_type
              FROM
                ( SELECT xmltype( olob) xml_data FROM dual
                );
            EXCEPTION
            WHEN OTHERS THEN
              lv_addr_type:=NULL;
            END;
            msgtext := 'Address Type:'||lv_addr_type;
            xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
            lv_customer_address_rec.addr_type      :=lv_addr_type;
            lv_private_cust_addr (priv_cust_addr)  := lv_customer_address_rec;
            lv_inv_private_cust_rec.lv_addresslines:=lv_private_cust_addr;
          END LOOP;
          lv_private_cust(priv_cust):=lv_inv_private_cust_rec;
        END LOOP;
        /* end artifact artf5962829 */
        /* start  CR 4721 */
        lv_inv_customer_addr         := inv_customer_address ();
        IF v_msgid                    = '1255' THEN
          inv_customer_addr_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/PPOrderImport/Order/Batch/OrderHeader['||c||']/CustomerAddress'); -- Q2Q change
        ELSE
          inv_customer_addr_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/OEOrderImport/Order/Batch/OrderHeader['||c||']/CustomerAddress');
        END IF;
        lv_inv_customer_addr.extend (xdb.dbms_xmldom.getlength (inv_customer_addr_proplist));
        FOR njj IN 1 .. xdb.dbms_xmldom.getlength (inv_customer_addr_proplist)
        LOOP
          curnode76543                               := xdb.dbms_xmldom.item (inv_customer_addr_proplist, njj - 1);
          v_node                                     := 'BillToAddressee';
          lv_inv_customer_addr_rec.bill_to_addressee := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'BillToAddressee'))), v_null_value );
          v_node                                     := 'BillToAddress1';
          lv_inv_customer_addr_rec.bill_to_address_1 := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'BillToAddress1'))), v_null_value );
          v_node                                     := 'BillToAddress2';
          lv_inv_customer_addr_rec.bill_to_address_2 := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'BillToAddress2'))), v_null_value );
          msgtext                                    := 'BillToAddress2:'||lv_inv_customer_addr_rec.bill_to_address_2;
          xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
          v_node                                     := 'BillToAddress3';
          lv_inv_customer_addr_rec.bill_to_address_3 := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'BillToAddress3'))), v_null_value );
          msgtext                                    := 'BillToAddress3:'||lv_inv_customer_addr_rec.bill_to_address_3;
          xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
          v_node                                          := 'BillToPostalCode';
          lv_inv_customer_addr_rec.bill_to_postal_code    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'BillToPostalCode'))), v_null_value );
          v_node                                          := 'BillToCity';
          lv_inv_customer_addr_rec.bill_to_city           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'BillToCity'))), v_null_value );
          v_node                                          := 'BillToCountryCode';
          lv_inv_customer_addr_rec.bill_to_country_code   := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'BillToCountryCode'))), v_null_value );
          v_node                                          := 'BillToCountryName';
          lv_inv_customer_addr_rec.bill_to_country_name   := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'BillToCountryName'))), v_null_value );---defect 5344
          v_node                                          := 'BillToContactPerson';
          lv_inv_customer_addr_rec.bill_to_contact_person := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'BillToContactPerson'))), v_null_value );
          v_node                                          := 'BillToContactEmail';
          lv_inv_customer_addr_rec.bill_to_contact_email  := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'BillToContactEmail'))), v_null_value );
          v_node                                          := 'ShipToAdressee';
          lv_inv_customer_addr_rec.ship_to_addressee      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'ShipToAdressee'))), v_null_value );
          v_node                                          := 'ShipToAddress1';
          lv_inv_customer_addr_rec.ship_to_address_1      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'ShipToAddress1'))), v_null_value );
          v_node                                          := 'ShipToAddress2';
          lv_inv_customer_addr_rec.ship_to_address_2      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'ShipToAddress2'))), v_null_value );
          v_node                                          := 'ShipToAddress3';
          lv_inv_customer_addr_rec.ship_to_address_3      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'ShipToAddress3'))), v_null_value );
          v_node                                          := 'ShipToPostalCode';
          lv_inv_customer_addr_rec.ship_to_postal_code    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'ShipToPostalCode'))), v_null_value );
          v_node                                          := 'ShipToCity';
          lv_inv_customer_addr_rec.ship_to_city           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'ShipToCity'))), v_null_value );
          v_node                                          := 'ShipToCountryCode';
          lv_inv_customer_addr_rec.ship_to_country_code   := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'ShipToCountryCode'))), v_null_value );
          v_node                                          := 'ShipToCountryName';
          lv_inv_customer_addr_rec.ship_to_country_name   := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'ShipToCountryName'))), v_null_value );
          v_node                                          := 'ShipToContactPerson';
          lv_inv_customer_addr_rec.ship_to_contact_person := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'ShipToContactPerson'))), v_null_value );
          v_node                                          := 'ShipToContactEmail';
          lv_inv_customer_addr_rec.ship_to_contact_email  := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode76543, 'ShipToContactEmail'))), v_null_value );
          lv_inv_customer_addr (njj)                      := lv_inv_customer_addr_rec;
        END LOOP;
        /* end wave 2 modification */
        /* end CR 4721 */
        lv_inv_custom_print         := inv_custom_print ();
        IF v_msgid                   = '1255' THEN
          inv_custom_print_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/PPOrderImport/Order/Batch/OrderHeader['||c||']/PrintCriteria'); -- Q2Q change
        ELSE
          inv_custom_print_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/OEOrderImport/Order/Batch/OrderHeader['||c||']/PrintCriteria');
        END IF;
        lv_inv_custom_print.extend (xdb.dbms_xmldom.getlength (inv_custom_print_proplist));
        FOR bjj IN 1 .. xdb.dbms_xmldom.getlength (inv_custom_print_proplist)
        LOOP
          curnode911                                 := xdb.dbms_xmldom.item (inv_custom_print_proplist, bjj - 1);
          v_node                                     := 'MessageID';
          lv_inv_custom_print_rec.messageid          := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'MessageID'))), v_null_value );
          v_node                                     := 'InvoiceCustomerGroup';
          lv_inv_custom_print_rec.inv_customer_group := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'InvoiceCustomerGroup'))), v_null_value );
          v_node                                     := 'GoodsTotalValue';
          lv_inv_custom_print_rec.goods_total_value  := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'GoodsTotalValue'))), v_null_value );
          msgtext                                    := 'goods_total_value:'||lv_inv_custom_print_rec.goods_total_value;
          xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
          v_node                                := 'ShipmentType';
          lv_inv_custom_print_rec.shipment_type := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'ShipmentType'))), v_null_value );
          msgtext                               := 'ShipmentType:'||lv_inv_custom_print_rec.shipment_type;
          xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
          v_node                                               := 'TotalNumberofItems';
          lv_inv_custom_print_rec.total_num_items              := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'TotalNumberofItems'))), v_null_value );
          v_node                                               := 'CommodityClassification';
          lv_inv_custom_print_rec.commodity_classification     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'CommodityClassification'))), v_null_value );
          v_node                                               := 'CustomsClearanceStatusCode';
          lv_inv_custom_print_rec.custom_clearance_status_code := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'CustomsClearanceStatusCode'))), v_null_value );
          v_node                                               := 'CustomsClearanceDate';
          lv_inv_custom_print_rec.custom_clearance_date        := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'CustomsClearanceDate'))), v_null_value );
          v_node                                               := 'InvoiceSplit';
          lv_inv_custom_print_rec.inv_split                    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'InvoiceSplit'))), v_null_value );
          v_node                                               := 'InvoiceMail';
          lv_inv_custom_print_rec.inv_mail                     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'InvoiceMail'))), v_null_value );
          v_node                                               := 'CustomerEnclosure';
          lv_inv_custom_print_rec.customer_enclosure           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'CustomerEnclosure'))), v_null_value );
          v_node                                               := 'AdrLevDeviation';
          lv_inv_custom_print_rec.adr_lev_deviation            := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'AdrLevDeviation'))), v_null_value );
          v_node                                               := 'InvoiceType';
          lv_inv_custom_print_rec.invoice_type                 := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'InvoiceType'))), v_null_value );
          v_node                                               := 'ReceiptReference';
          lv_inv_custom_print_rec.receipt_reference            := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'ReceiptReference'))), v_null_value );
          v_node                                               := 'PreferredLanguage';
          lv_inv_custom_print_rec.preferred_language           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'PreferredLanguage'))), v_null_value );
          v_node                                               := 'InvoiceSettlement';
          lv_inv_custom_print_rec.invoice_settlement           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode911, 'InvoiceSettlement'))), v_null_value );
          lv_inv_custom_print (bjj)                            := lv_inv_custom_print_rec;
        END LOOP;
        /* end wave 2 modification */
        /* version 1.8 CR 1929 */
        v_spec_url                := spec_url_line ();
        IF v_msgid                 = '1255' THEN
          inv_attachment_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/PPOrderImport/Order/Batch/OrderHeader['||c||']/InvoiceAttachmentFile'); -- Q2Q change
        ELSE
          inv_attachment_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/OEOrderImport/Order/Batch/OrderHeader['||c||']/InvoiceAttachmentFile');
        END IF;
        v_spec_url.extend (xdb.dbms_xmldom.getlength (inv_attachment_proplist));
        FOR b IN 1 .. xdb.dbms_xmldom.getlength (inv_attachment_proplist)
        LOOP
          curnode9                      := xdb.dbms_xmldom.item (inv_attachment_proplist, b - 1);
          v_node                        := 'FileReference';
          v_inv_url_rec.attachment_name := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode9, 'FileReference'))), v_null_value );
          v_node                        := 'DocumentName';
          v_inv_url_rec.link_label      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode9, 'DocumentName'))), v_null_value );
          msgtext                       := 'Document Name:'||v_inv_url_rec.attachment_name;
          xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
          v_node                 := 'URL';
          v_inv_url_rec.link_url := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode9, 'URL'))), v_null_value );
          msgtext                := 'URL:'||v_inv_url_rec.link_url;
          xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
          v_node                  := 'MIMEType';
          v_inv_url_rec.mime_type := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode9, 'MIMEType'))), v_null_value );
          v_spec_url (b)          := v_inv_url_rec;
		  
        END LOOP;
        --------------------------------------------------------------------------------------------------------------------------------
        -- v_order_num      :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'OrderNumber'))), v_null_value);
        --  v_org_id  := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2, 'OrgID'))), v_null_value);
        --  v_bulk_head := false;
        --  IF ((v_aggregate = '1') AND (v_last_customerno != v_customerno OR v_last_date != v_date
        --     OR v_last_source != v_source or v_last_valuta_code != v_valuta_code)) OR (v_aggregate = '0')THEN
        --      v_bulk_Head := true;
        -- END IF;
        --  v_last_valuta_code := v_valuta_code;
        --  v_last_source := v_source;
        --   v_last_customerno := v_customerno;
        --   v_last_date := v_date;
        --v_bulk_head := true;
        --IF v_bulk_head THEN
        --v_orderhead_rec.organizational_unit := v_organizational_unit;
		
        v_orderhead_rec.ordereddate   := v_date;
        v_orderhead_rec.currency_code := v_valuta_code;
        v_orderhead_rec.order_source  := l_message_header.sourcesystem;
        --v_orderhead_rec.order_source_id        := v_order_source_id;
        v_orderhead_rec.customer_number        := v_customerno;
        v_orderhead_rec.po_reference           := v_po_reference;
        v_orderhead_rec.sales_agmnt_no         := v_sales_agmnt_no;
        v_orderhead_rec.stamps_agreement_type  := v_stamps_agreement_type;  -- Added by Sayali for defect 5766
        v_orderhead_rec.order_type             := v_order_type;
        v_orderhead_rec.order_reference        := v_order_reference;
        v_orderhead_rec.return_order_reference := v_ret_order_reference;
        v_orderhead_rec.cc_ref_id              := v_cc_ref_id;
        v_orderhead_rec.org_id                 := ln_org_id;--Added for OU changes
        v_orderhead_rec.customer_ref           := v_customer_ref;
        -- v_orderhead_rec.autotwist_invoice      := v_autotwist_invoice;
        v_orderhead_rec.charteque_number  := v_charteque_number;
        v_orderhead_rec.price_list        := v_price_list_id;
        v_orderhead_rec.payment_type_code := v_payment_type_code;
        /* version 0.3  Change artf4774289 */
        v_orderhead_rec.pricing_date              := v_pricing_date;
        v_orderhead_rec.payment_provider_trans_id := v_payment_provider_trans_id;
        v_orderhead_rec.exclude_from_dunning      := v_exclude_from_dunning;
        -- v_orderhead_rec.invoice_attachment_file   := v_invoice_attachment_file;
        /* version 0.6 */
        v_orderhead_rec.message_to_customer:=v_msg_to_cust;
        v_orderhead_rec.agreement_name     :=v_agreement_name;
        v_orderhead_rec.project_ref        :=lv_project_ref;
        v_orderhead_rec.prepayment_flag    :=v_prepay_flag;
        v_orderhead_rec.settlement_flag    :=v_settle_flag;---added by vijay on 27-jun-2017 for defect 3528
        /* start wave 2 modification */
        v_orderhead_rec.contract_num         :=lv_contract_num;
        v_orderhead_rec.contract_modifier_num:=lv_contract_modifier_num;
        v_orderhead_rec.bill_details         :=lv_bill_details;
        v_orderhead_rec.waiting_date         :=lv_waiting_date;
        v_orderhead_rec.handling_date        :=lv_handling_date;
        v_orderhead_rec.payment_method       :=lv_payment_method;
        v_orderhead_rec.invoice_text         :=lv_inv_text;
        v_orderhead_rec.info_ar              :=lv_info_ar;
        v_orderhead_rec.special_handling     :=lv_special_handling;
        v_orderhead_rec.gift                 :=lv_gift;
        v_orderhead_rec.minisite_id          :=lv_minisite_id;
        v_orderhead_rec.customs_id           :=lv_customs_id;
        v_orderhead_rec.sender_name          :=lv_sender_name;
        v_orderhead_rec.master_consign_id    :=lv_master_consign_id;
        v_orderhead_rec.consignment_num      :=lv_consignment_num;
        v_orderhead_rec.consign_item_num     :=lv_consign_item_num;
        v_orderhead_rec.reserved_amount      :=lv_reserved_amount;
        v_orderhead_rec.credit_card_source   :=lv_credit_card_source;--defect 3937
        v_orderhead_rec.prepaid_amount       :=ln_prepaid_amount;    --defect 3922
        v_orderhead_rec.invoice_kid          :=lv_invoice_kid;       --defect 4086
        /* end wave 2 modification */
        /* start CR 4813 */
        v_orderhead_rec.payment_term:=lv_payment_term;
        /* end CR */
        /* version 1.9 CR 2224*/
        v_orderhead_rec.printed_order_number :=lv_printed_order_no;
        --v_orderhead_rec.org_id        := v_org_id;
        IF v_aggregate                   = '1' THEN
          v_orderhead_rec.aggregatehead := true;
        ELSE
          v_orderhead_rec.aggregatehead := false;
        END IF;
        msgsrc  := 'xxcu_ont_create_order_parser BODY.parse_xmlmessage';
        msgtext := 'Orderhead parsed' || '  v_orderhead_rec.OrderedDate : ' || v_orderhead_rec.ordereddate
        /*|| '; v_orderhead_rec.organizational_unit: '
        || v_orderhead_rec.organizational_unit*/
        || '; v_orderhead_rec.Code_Valuta : ' || v_orderhead_rec.currency_code || '; v_orderhead_rec.order_source : ' || v_orderhead_rec.order_source || '; v_orderhead_rec.customer_number : ' || v_orderhead_rec.customer_number || '; v_orderhead_rec.po_reference : ' || v_orderhead_rec.po_reference || ';v_orderhead_rec.order_type  : ' || v_orderhead_rec.order_type || '; v_orderhead_rec.order_reference : ' || v_orderhead_rec.order_reference || '; v_orderhead_rec.return_order_reference : ' || v_orderhead_rec.return_order_reference || '; v_orderhead_rec.cc_ref_id  : ' || v_orderhead_rec.cc_ref_id || '; v_orderhead_rec.org_id : ' || v_orderhead_rec.org_id || '; v_orderhead_rec.customer_ref : ' || v_orderhead_rec.customer_ref || '; v_orderhead_rec.charteque_number : ' || v_orderhead_rec.charteque_number || '; v_orderhead_rec.price_list : ' || v_orderhead_rec.price_list;
        xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
        --  END IF;
        -- node 3: Order Lines
        msgtext := 'order_lines_proplist';
        xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
        IF v_msgid              = '1255' THEN
          order_lines_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/PPOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine');--Path changed for OU changes , -- Q2Q change
        ELSE
          order_lines_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/OEOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine');--Path changed for OU changes ,
        END IF;
        --  msg_orderline_url:='/Envelope/Body/OrderImport/DataArea/Order/Batch/OrderHeader['||c||']/OrderLine';
        msgtext := 'Order Lines Length: ' || xdb.dbms_xmldom.getlength (order_lines_proplist);
        xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
        v_order_line := order_line ();
        v_order_line.extend (xdb.dbms_xmldom.getlength (order_lines_proplist));
        FOR d IN 1 .. xdb.dbms_xmldom.getlength (order_lines_proplist)
        LOOP
          BEGIN
            curnode3 := xdb.dbms_xmldom.item (order_lines_proplist, d - 1);
            msgsrc   := 'xxcu_ont_create_order_parser BODY.parse_xmlmessage';
            msgtext  := 'parsing Order Lines node';
            ----xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
            v_node                             := 'BlanketNumber';--added by sayali  defect 5484
            v_orderline_rec.blanket_number     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'BlanketNumber'))), v_null_value); --added by sayali for defect 5484
            v_node                             := 'ItemNo';
            v_orderline_rec.itemno             := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'ItemNumber'))), v_null_value);
            v_node                             := 'Quantity';
            v_orderline_rec.quantity           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'OrderedQuantity'))), v_null_value);
            v_node                             := 'QuantityUOM';
            v_orderline_rec.quantity_uom       := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'QuantityUOM'))), v_null_value );
            v_node                             := 'UnitListPrice';
            v_orderline_rec.unit_list_price    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'UnitListPrice'))), v_null_value );
            v_node                             := 'UnitSellingPrice';
            v_orderline_rec.unit_selling_price := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'UnitNetPrice '))), v_null_value);
            v_node                             := 'TAX';
            v_orderline_rec.tax                := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'Tax'))), v_null_value);
            /* v_node                                  := 'CustomerItemNetPrice';
            v_orderline_rec.customer_item_net_price := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'CustomerItemNetPrice'))), v_null_value);
            */
            v_node                                := 'Tax_Value';
            v_orderline_rec.tax_value             := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'TaxValue'))), v_null_value);
            v_node                                := 'OrderlineIDSource';
            v_orderline_rec.orderlineidsource     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'OrderLineReference'))), v_null_value );
            v_node                                := 'ReturnOrderlineIDSource';
            v_orderline_rec.ret_orderlineidsource := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'ReturnOrderLineReference'))), v_null_value );
            v_node                                := 'DiscountBreakup';
            v_orderline_rec.discount_breakup      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'DiscountBreakupInfo'))), v_null_value );
            v_node                                := 'ReasonCode';
            v_orderline_rec.reason_code           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'ReturnReasonCode'))), v_null_value );
            v_node                                := 'PostalCodeFrom';
            v_orderline_rec.postal_code_from      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'PostalCodeFrom'))), v_null_value );
            v_node                                := 'PostalCodeTo';
            v_orderline_rec.postal_code_to        := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'PostalCodeTo'))), v_null_value );
            v_node                                := 'CountryCodeFrom';
            v_orderline_rec.country_code_from     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'CountryCodeFrom'))), v_null_value );
            v_node                                := 'CountryCodeTo';
            v_orderline_rec.country_code_to       := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'CountryCodeTo'))), v_null_value );
            v_node                                := 'AccountingUnit';
            --  v_orderline_rec.ship_from             := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'ShipFrom'))), v_null_value );
            --  v_node                                := 'Ship_To';
            -- v_orderline_rec.ship_to               := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'ShipTo'))), v_null_value );
            -- v_node                                := 'AccountingUnit';
            v_orderline_rec.salesperson := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'AccountingUnit'))), v_null_value );
            /* version 0.7 CR 1449*/
            v_node                   := 'TaxCode';
            v_orderline_rec.tax_code := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'TaxCode'))), v_null_value );
            msgtext                  := 'Tax Code: ' || v_orderline_rec.tax_code ;
            xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
            v_node                             := 'PriceAdjustmentPerUnit';
            v_orderline_rec.price_adj_per_unit := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'PriceAdjustmentPerUnit'))), v_null_value );
            v_orderline_rec.shipping_method    :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'ShippingMethod'))), v_null_value );--CR 4813
            /* start wave 2 modification */
            v_node                            := 'LinkToLineRef';
            v_orderline_rec.link_to_line_ref  := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'LinkToLineRef'))), v_null_value );
            v_node                            := 'TopLineRef';
            v_orderline_rec.top_line_ref      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'TopLineRef'))), v_null_value );
            v_node                            := 'GiftRecipient';
            v_orderline_rec.gift_recipient    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'GiftRecipient'))), v_null_value );
            v_node                            := 'GiftShipTo';
            v_orderline_rec.gift_ship_to      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'GiftShipTo'))), v_null_value );
            v_node                            := 'CombinationID';
            v_orderline_rec.combination_id    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'CombinationID'))), v_null_value );
            v_node                            := 'WeightGroup';
            v_orderline_rec.weight_group      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'WeightGroup'))), v_null_value );
            v_node                            := 'PriceZone';
            v_orderline_rec.price_zone        := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'PriceZone'))), v_null_value );
            v_node                            := 'UnitWeight';
            v_orderline_rec.unit_weight       := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'UnitWeight'))), v_null_value );
            v_node                            := 'AssignmentNumbers';
            v_orderline_rec.assignment_number := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'AssignmentNumbers'))), v_null_value );
            /* end wave 2 modification */
            v_node := 'ShipTo';
            /* version 0.7 CR 1899*/
            v_orderline_rec.ship_to   := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'ShipTo'))), v_null_value );
            v_node                            := 'MachineReference';  --Included new tag by Nikhil for defect 5649
            v_orderline_rec.machine_reference := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'MachineReference'))), v_null_value );  --Included new tag by Nikhil for defect 5649
            IF v_msgid                 = '1255' THEN
              spec_lines_proplist_new := xxcu_common_util_xml.selectnodes (curnode2, '/PPOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine['||d||']/InvoiceSpecification'); -- Q2Q
            ELSE
              spec_lines_proplist_new := xxcu_common_util_xml.selectnodes (curnode2, '/OEOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine['||d||']/InvoiceSpecification');
            END IF;
            -- v_order_line := order_line ();
            --  v_order_line.EXTEND (xdb.DBMS_XMLDOM.getlength (spec_lines_proplist_new));
            --
            v_orderline_rec.order_line_spec_hdr_cnt               :=0;
            IF xdb.dbms_xmldom.getlength (spec_lines_proplist_new) >0 THEN
              v_orderline_rec.order_line_spec_hdr_cnt             :=1;
              msgtext                                             := 'v_orderline_rec.order_line_spec_hdr_cnt' || v_orderline_rec.order_line_spec_hdr_cnt ;
              xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
            END IF;
            FOR f IN 1 .. xdb.dbms_xmldom.getlength (spec_lines_proplist_new)
            LOOP
              curnode6                    := xdb.dbms_xmldom.item (spec_lines_proplist_new, f - 1);
              v_node                      := 'DateFrom';
              v_orderline_rec.date_from   := to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode6,'DateFrom '))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
              v_node                      := 'DateTo';
              v_orderline_rec.date_to     := to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode6,'DateTo '))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat); --to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
              v_node                      := 'Description';
              v_orderline_rec.description :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Description'))), v_null_value);
              v_node                      := 'OrderDate';
              v_orderline_rec.order_date  := to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode6,'OrderDate'))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
              /* start CR 4475 */
              v_node                        := 'FreightPayer';
              v_orderline_rec.freight_payer :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'FreightPayer'))), v_null_value);
              /* end CR 4475 */
              /*Start of defect 5701*/
              v_node                         := 'PlantId';
              v_orderline_rec.PlantId       :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PlantId'))), v_null_value);
            /*End of defect 5701*/
              v_node                        := 'Quantity';
              v_orderline_rec.spec_quantity :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Quantity'))), v_null_value);
              v_node                        := 'PackagesUOM';
              v_orderline_rec.uom           :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PackagesUOM'))), v_null_value);
              /* version 1.9 CR 2468 */
              /* v_node                         := 'PerTimeUnit';
              v_orderline_rec.per_time_unit  :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PerTimeUnit'))), v_null_value);
              v_node                         := 'UnitPrice';
              v_orderline_rec.unit_price     :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'UnitPrice'))), v_null_value);
              v_node                         := 'Amount';
              v_orderline_rec.amount         :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Amount '))), v_null_value);
              */
              --------------------------------------------------------------------------------------------------------------------------------------------------------------------
              v_node                         := 'WaybillNumber';
              v_orderline_rec.waybill_number :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'WaybillNumber'))), v_null_value);
              v_node                         := 'SenderName';
              v_orderline_rec.sender_name    :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'SenderName'))), v_null_value);
              v_node                         := 'ReceiverName';
              v_orderline_rec.receiver_name  :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'ReceiverName'))), v_null_value);
              /* version 1.8 1929 */
              IF v_msgid           = '1255' THEN
                spec_url_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/PPOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine['||d||']/InvoiceSpecification/ShipFrom'); -- Q2Q
              ELSE
                spec_url_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/OEOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine['||d||']/InvoiceSpecification/ShipFrom');
              END IF;
              -- v_order_line := order_line ();
              --  v_order_line.EXTEND (xdb.DBMS_XMLDOM.getlength (spec_lines_proplist_new));
              FOR g IN 1 .. xdb.dbms_xmldom.getlength (spec_url_proplist)
              LOOP
                curnode7                              := xdb.dbms_xmldom.item (spec_url_proplist, g - 1);
                v_node                                := 'Address1';
                v_orderline_rec.ship_from_address1    :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode7, 'Address1'))), 0,240), v_null_value);--Defect -8523 ,Incident E2-IM014117169
                v_node                                := 'Address2';
                v_orderline_rec.ship_from_address2    :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode7, 'Address2'))), 0,240),v_null_value);--Defect -8523 ,Incident E2-IM014117169
                v_node                                := 'Address3';
                v_orderline_rec.ship_from_address3    :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode7, 'Address3'))), 0,240), v_null_value);--Defect -8523 ,Incident E2-IM014117169
                v_node                                := 'City';
                v_orderline_rec.ship_from             :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode7, 'City'))), v_null_value);
                v_node                                := 'PostalCode';
                v_orderline_rec.ship_from_postal_code :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode7, 'PostalCode'))), 0,60),v_null_value);--Defect -8523 ,Incident E2-IM014117169
                v_node                                := 'Country';
                v_orderline_rec.ship_from_country     :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode7, 'Country'))), 0,60), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              END LOOP;
              IF v_msgid              = '1255' THEN
                spec_url_proplist_to := xxcu_common_util_xml.selectnodes (curnode2, '/PPOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine['||d||']/InvoiceSpecification/ShipTo'); -- Q2Q
              ELSE
                spec_url_proplist_to := xxcu_common_util_xml.selectnodes (curnode2, '/OEOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine['||d||']/InvoiceSpecification/ShipTo');
              END IF;
              -- v_order_line := order_line ();
              --  v_order_line.EXTEND (xdb.DBMS_XMLDOM.getlength (spec_lines_proplist_new));
              FOR h IN 1 .. xdb.dbms_xmldom.getlength (spec_url_proplist_to)
              LOOP
                curnode8                            := xdb.dbms_xmldom.item (spec_url_proplist_to, h - 1);
                v_node                              := 'Address1';
                v_orderline_rec.ship_to_address1    :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode8, 'Address1'))), 0,240),v_null_value);--Defect -8523 ,Incident E2-IM014117169
                v_node                              := 'Address2';
                v_orderline_rec.ship_to_address2    :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode8, 'Address2'))), 0,240), v_null_value);--Defect -8523 ,Incident E2-IM014117169
                v_node                              := 'Address3';
                v_orderline_rec.ship_to_address3    :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode8, 'Address3'))), 0,240), v_null_value);--Defect -8523 ,Incident E2-IM014117169
                v_node                              := 'City';
                v_orderline_rec.spec_ship_to        :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode8, 'City'))), v_null_value);
                v_node                              := 'PostalCode';
                v_orderline_rec.ship_to_postal_code :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode8, 'PostalCode'))),0,60), v_null_value);--Defect -8523 ,Incident E2-IM014117169
                v_node                              := 'Country';
                v_orderline_rec.ship_to_country     :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode8, 'Country'))),0,60), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              END LOOP;
              -------------------------------------------------------------------------------------------------------------------------------------
              v_node                              := 'NoOfPackages';
              v_orderline_rec.number_of_packages  :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'NoOfPackages'))), v_null_value);
              v_node                              := 'Pallet';
              v_orderline_rec.pallet              :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Pallet'))), v_null_value);
              v_node                              := 'Volume';
              v_orderline_rec.volume              :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Volume'))), v_null_value);
              v_node                              := 'Weight';
              v_orderline_rec.weight              :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Weight'))), v_null_value);
              v_node                              := 'FreightCalcWeight';
              v_orderline_rec.freight_calc_weight :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'FreightCalcWeight'))), v_null_value);
              v_node                              := 'ResponsiblePerson';
              v_orderline_rec.responsible_person  :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'ResponsiblePerson'))), v_null_value);
              v_node                              := 'PPPrice';
              v_orderline_rec.pp_price            :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PPPrice'))), v_null_value);
              v_node                              := 'CargoType';
              v_orderline_rec.cargo_type          :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'CargoType'))), v_null_value);
              /* version 1.8 CR 1929 */
              v_node                              := 'ContainerReference';
              v_orderline_rec.container_reference :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'ContainerReference'))),0,240), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                              := 'PickUpPoint';
              v_orderline_rec.pick_up_point       :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PickUpPoint'))), 0,240),v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                              := 'AirWaybillNumber';
              v_orderline_rec.awb                 :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'AirWaybillNumber'))), v_null_value);
              v_node                              := 'MasterAWB';
              v_orderline_rec.mawb                :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'MasterAWB'))), v_null_value);
              v_node                              := 'HouseAWB';
              v_orderline_rec.hawb                :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'HouseAWB'))), v_null_value);
              v_node                              := 'Vessel';
              v_orderline_rec.vessel              :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Vessel'))), v_null_value);
              v_node                              := 'Incoterm';
              v_orderline_rec.incoterm            :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Incoterm'))), v_null_value);
              v_node                              := 'SenderReference';
              v_orderline_rec.sender_reference    :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'SenderReference'))),0,240), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                              := 'ReceiverReference';
              v_orderline_rec.receiver_reference  :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'ReceiverReference'))),0,2000), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                              := 'AgentReference';
              v_orderline_rec.agent_reference     :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'AgentReference'))), 0,240),v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                              := 'LoadCarrier';
              v_orderline_rec.load_carrier        :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'LoadCarrier'))), v_null_value);
              v_node                              := 'TransportMethod';
              v_orderline_rec.transport_method    :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'TransportMethod'))), v_null_value);
              v_node                              := 'DeliveryPoint';
              v_orderline_rec.delivery_point      :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'DeliveryPoint'))), v_null_value);
              v_node                              := 'OurReference';
              v_orderline_rec.our_reference       :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'OurReference'))), v_null_value);
              v_node                              := 'CargoIdNumber';
              v_orderline_rec.cargo_id_number     :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'CargoIdNumber'))), v_null_value);
              v_node                              := 'PositionNumber';
              v_orderline_rec.position_number     :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PositionNumber'))), v_null_value);
              v_node                              := 'LoadMeter';
              v_orderline_rec.load_meter          :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'LoadMeter'))), v_null_value);
              v_node                              := 'CargoLabel';
              v_orderline_rec.cargo_label         :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'CargoLabel'))), v_null_value);
              v_node                              := 'ChartequeNumber';
              v_orderline_rec.charteque_number    :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'ChartequeNumber'))), v_null_value);
              v_node                              := 'DeliveredTime';
              v_orderline_rec.delivered_time      :=to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode6,'DeliveredTime '))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
              v_node                              := 'ReceivedTime';
              v_orderline_rec.received_time       :=to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode6,'ReceivedTime '))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
              ------------------------------------------------------------------------------------------------------------------------
              /* version 1.9 CR 2468 */
              v_node                                  := 'VolumeUOM';
              v_orderline_rec.volume_uom              :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'VolumeUOM'))), v_null_value);
              v_node                                  := 'WeightUOM';
              v_orderline_rec.weight_uom              :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'WeightUOM'))), v_null_value);
              v_node                                  := 'FreightCalcWeightUOM';
              v_orderline_rec.freight_calc_weight_uom :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'FreightCalcWeightUOM'))), v_null_value);
              /* start 1.11 CR 3006 */
              v_node                          := 'Currency';
              v_orderline_rec.currency        :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Currency'))), v_null_value);
              v_node                          := 'CurrencyAmount';
              v_orderline_rec.currency_amount :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'CurrencyAmount'))), v_null_value);
              v_node                          := 'ExchangeRate';
              v_orderline_rec.exchange_rate   :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'ExchangeRate'))), v_null_value);
              v_node                          := 'ExchangeDate';
              v_orderline_rec.exchange_date   :=to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode6,'ExchangeDate '))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
              /* end 1.11 CR 3006 */
              /* start 1.11 CR 3118 */
              v_node                               := 'PickUpAddress1';
              v_orderline_rec.pick_up_address1     :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PickUpAddress1'))),0,240), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                               := 'PickUpAddress2';
              v_orderline_rec.pick_up_address2     :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PickUpAddress2'))),0,240), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                               := 'PickUpAddress3';
              v_orderline_rec.pick_up_address3     :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PickUpAddress3'))),0,240), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                               := 'PickUpPostalCode';
              v_orderline_rec.pick_up_postal_code  :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PickUpPostalCode'))),0,30), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                               := 'PickUpCity';
              v_orderline_rec.pick_up_city         :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PickUpCity'))),0,30), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                               := 'PickUpCountry';
              v_orderline_rec.pick_up_country      :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PickUpCountry'))),0,60) ,v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                               := 'DeliveryAddress1';
              v_orderline_rec.delivery_address1    :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'DeliveryAddress1'))),0,240), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                               := 'DeliveryAddress2';
              v_orderline_rec.delivery_address2    :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'DeliveryAddress2'))),0,240), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                               := 'DeliveryAddress3';
              v_orderline_rec.delivery_address3    :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'DeliveryAddress3'))),0,240), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                               := 'DeliveryPostalCode';
              v_orderline_rec.delivery_postal_code :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'DeliveryPostalCode'))),0,30), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                               := 'DeliveryCity';
              v_orderline_rec.delivery_city        :=NVL(SUBSTR (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'DeliveryCity'))),0,30), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              v_node                               := 'DeliveryCountry';
              v_orderline_rec.delivery_country     :=NVL (SUBSTR(xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'DeliveryCountry'))),0,60), v_null_value);--Defect -8523 ,Incident E2-IM014117169
              /* start CR 3374 */
              v_node                          := 'UnloadingPoint';
              v_orderline_rec.unloading_point :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'UnloadingPoint'))), v_null_value);
              v_node                          := 'LoadingPoint';
              v_orderline_rec.loading_point   :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'LoadingPoint'))), v_null_value);
              /* end CR 3374 */
              v_node                                := 'Note';
              v_orderline_rec.note                  :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Note'))), v_null_value);
              v_node                                := 'ConsignmentType';
              v_orderline_rec.consignment_type_code :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'ConsignmentTypeCode'))), v_null_value);
              v_node                                := 'ConsignmentTypeText';
              v_orderline_rec.consignment_type_text :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'ConsignmentTypeText'))), v_null_value);
              v_node                                := 'TransportMethodText';
              v_orderline_rec.transport_method_text :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'TransportMethodText'))), v_null_value);
              v_node                                := 'IncotermText';
              v_orderline_rec.incoterm_text         :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'IncotermText'))), v_null_value);
              v_node                                := 'ShipToFiscalCode';
              v_orderline_rec.ship_to_fiscal_code   :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'ShipToFiscalCode'))), v_null_value);
              v_node                                := 'ShipFromFiscalCode';
              v_orderline_rec.ship_from_fiscal_code :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'ShipFromFiscalCode'))), v_null_value);
              /* start wave 2 modification */
              v_node                               := 'OrderedBy';
              v_orderline_rec.ordered_by           :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'OrderedBy'))), v_null_value);
              v_node                               := 'OrderedByAddress1';
              v_orderline_rec.ordered_by_addr1     :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'OrderedByAddress1'))), v_null_value);
              v_node                               := 'OrderedByAddress2';
              v_orderline_rec.ordered_by_addr2     :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'OrderedByAddress2'))), v_null_value);
              v_node                               := 'OrderedByAddress3';
              v_orderline_rec.ordered_by_addr3     :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'OrderedByAddress3'))), v_null_value);
              v_node                               := 'OrderedByPostal';
              v_orderline_rec.ordered_by_postal    :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'OrderedByPostal'))), v_null_value);
              v_node                               := 'OrderedByCity';
              v_orderline_rec.ordered_by_city      :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'OrderedByCity'))), v_null_value);
              v_node                               := 'OrderedByCountry';
              v_orderline_rec.ordered_by_country   :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'OrderedByCountry'))), v_null_value);
              v_node                               := 'OrderedByContactPerson';
              v_orderline_rec.ordered_by_contact   :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'OrderedByContactPerson'))), v_null_value);
              v_node                               := 'OrderedByContactEmail';
              v_orderline_rec.ordered_by_con_email :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'OrderedByContactEmail'))), v_null_value);
              v_node                               := 'BillToContactPerson';
              v_orderline_rec.bill_to_con_person   :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'BillToContactPerson'))), v_null_value);
              v_node                               := 'BillToContactEmail';
              v_orderline_rec.bill_to_con_email    :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'BillToContactEmail'))), v_null_value);
              v_node                               := 'Deviation';
              v_orderline_rec.deviation            :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Deviation'))), v_null_value);
              v_node                               := 'FrankingType';
              v_orderline_rec.franking_type        :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'FrankingType'))), v_null_value);
              v_node                               := 'PriceTable';
              v_orderline_rec.price_table          :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PriceTable'))), v_null_value);
              v_node                               := 'Speed';
              v_orderline_rec.speed                :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Speed'))), v_null_value);
              v_node                               := 'Destination';
              v_orderline_rec.destination          :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Destination'))), v_null_value);
              v_node                               := 'Weight';
              v_orderline_rec.weight_spec          :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'Weight'))), v_null_value);
              v_node                               := 'UnitPriceInclVAT';
              v_orderline_rec.unit_price_inc_vat   :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'UnitPriceInclVAT'))), v_null_value);
              v_node                               := 'UnitPriceExclVAT';
              v_orderline_rec.unit_price_excl_vat  :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'UnitPriceExclVAT'))), v_null_value);
              v_node                               := 'TotalPrice';
              v_orderline_rec.total_inc_vat        :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'TotalPrice'))), v_null_value);
              v_node                               := 'PaidAmount';
              v_orderline_rec.paid_amount          :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'PaidAmount'))), v_null_value);
              v_node                               := 'AgreementSum';
              v_orderline_rec.agreement_sum        :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'AgreementSum'))), v_null_value);
              v_node                               := 'ShipmentIDNumber';
              v_orderline_rec.shipment_id_number   :=NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode6, 'ShipmentIDNumber'))), v_null_value);
              /* end wave 2 modification */
              ------------------------------------------------------------------------------------------------------------------------------------------------
              /* start CR 3118 */
              v_ref_line          := spec_ref_line ();
              IF v_msgid           = '1255' THEN
                spec_ref_proplist := xxcu_common_util_xml.selectnodes (curnode6, '/PPOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine['||d||']/InvoiceSpecification/FreeReference'); -- Q2Q
              ELSE
                spec_ref_proplist := xxcu_common_util_xml.selectnodes (curnode6, '/OEOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine['||d||']/InvoiceSpecification/FreeReference');
              END IF;
              v_ref_line.extend (xdb.dbms_xmldom.getlength (spec_ref_proplist));
              FOR kj IN 1 .. xdb.dbms_xmldom.getlength (spec_ref_proplist)
              LOOP
                curnode10                            := xdb.dbms_xmldom.item (spec_ref_proplist, kj - 1);
                v_node                               := 'FreeReferenceCode';
                v_inv_ref_rec.free_reference_code    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode10, 'FreeReferenceCode'))), v_null_value );
                v_node                               := 'FreeReferenceText';
                v_inv_ref_rec.free_reference_text    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode10, 'FreeReferenceText'))), v_null_value );
                v_node                               := 'FreeReferenceContent';
                v_inv_ref_rec.free_reference_content := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode10, 'FreeReferenceContent'))), v_null_value );
                v_node                               := 'PrintOnInvoiceFlag';
                v_inv_ref_rec.print_on_invoice_flag  := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode10, 'PrintOnInvoiceFlag'))), v_null_value );
                msgtext                              := 'FreeReferenceContent:'||v_inv_ref_rec.free_reference_content;
                xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
                v_ref_line (kj) := v_inv_ref_rec;
              END LOOP;
              /* end CR 3118 */
              ------------------------------------------------------------------------------------------------------------------------------------------------
              /* start wave 2 modification */
              lv_inv_spec_disc         := spec_inv_disc();
              IF v_msgid                = '1255' THEN
                spec_inv_disc_proplist := xxcu_common_util_xml.selectnodes (curnode6, '/PPOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine['||d||']/InvoiceSpecification/InvoiceSpecificationDiscount'); -- Q2Q
              ELSE
                spec_inv_disc_proplist := xxcu_common_util_xml.selectnodes (curnode6, '/OEOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine['||d||']/InvoiceSpecification/InvoiceSpecificationDiscount');
              END IF;
              lv_inv_spec_disc.extend (xdb.dbms_xmldom.getlength (spec_inv_disc_proplist));
              FOR kjj IN 1 .. xdb.dbms_xmldom.getlength (spec_inv_disc_proplist)
              LOOP
                curnode101                     := xdb.dbms_xmldom.item (spec_inv_disc_proplist, kjj - 1);
                v_node                         := 'DiscountDescriptionNO';
                lv_inv_disc_spec.descriptionno := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode101, 'DiscountDescriptionNO'))), v_null_value );
                v_node                         := 'DiscountDescriptionUS';
                lv_inv_disc_spec.descriptionus := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode101,'DiscountDescriptionUS'))), v_null_value );
                v_node                         := 'Percentage';
                lv_inv_disc_spec.percentage    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode101, 'Percentage'))), v_null_value );
                lv_inv_spec_disc (kjj)         := lv_inv_disc_spec;
              END LOOP;
              /* end wave 2 modification*/
              IF v_msgid             = '1255' THEN
                spec_lines_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/PPOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine['||d||']/InvoiceSpecification/InvoiceSpecificationLines');-- Q2Q
              ELSE
                spec_lines_proplist := xxcu_common_util_xml.selectnodes (curnode2, '/OEOrderImport/Order/Batch/OrderHeader['||c||']/OrderLine['||d||']/InvoiceSpecification/InvoiceSpecificationLines');
              END IF;
              --  msg_orderline_url:='/Envelope/Body/OrderImport/DataArea/Order/Batch/OrderHeader['||c||']/OrderLine';
              msgtext := 'Spec Lines Length: ' || xdb.dbms_xmldom.getlength (spec_lines_proplist);
              xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
              v_spec_line := spec_line ();
              v_spec_line.extend (xdb.dbms_xmldom.getlength (spec_lines_proplist));
              FOR e IN 1 .. xdb.dbms_xmldom.getlength (spec_lines_proplist)
              LOOP
                curnode4 := xdb.dbms_xmldom.item (spec_lines_proplist, e - 1);
                msgtext  := 'inside loop spec';
                xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
                v_node                                   := 'OrderLineNumber';
                v_inv_spec_rec.order_line_number         := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineNumber'))), v_null_value );
                v_node                                   := 'OrderLineText';
                v_inv_spec_rec.order_line_text           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineText'))), v_null_value );
                v_node                                   := 'OrderLineNoOfPackages';
                v_inv_spec_rec.order_line_no_of_packages := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineNoOfPackages'))), v_null_value );
                v_node                                   := 'OrderLinePallet';
                v_inv_spec_rec.order_line_pallet         := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLinePallet'))), v_null_value );
                v_node                                   := 'OrderLinePPPrice';
                v_inv_spec_rec.order_line_pp_price       := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLinePPPrice'))), v_null_value );
                v_node                                   := 'OrderLineNetWeight';
                v_inv_spec_rec.order_line_net_weight     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineNetWeight'))), v_null_value );
                /* version 1.8 CR 1929 */
                v_node                                   := 'OrderLineNetWeightUOM';
                v_inv_spec_rec.order_line_net_weight_uom := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineNetWeightUOM'))), v_null_value );
                v_node                                   := 'OrderLinePackagesUOM';
                v_inv_spec_rec.order_line_nop_uom        := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLinePackagesUOM'))), v_null_value );
                v_node                                   := 'OrderLineLength';
                v_inv_spec_rec.order_line_length         := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineLength'))), v_null_value );
                v_node                                   := 'OrderLineWidth';
                v_inv_spec_rec.order_line_width          := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineWidth'))), v_null_value );
                v_node                                   := 'OrderLineHeight';
                v_inv_spec_rec.order_line_height         := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineHeight'))), v_null_value );
                v_node                                   := 'OrderLineDimensionUOM';
                v_inv_spec_rec.order_line_dim_uom        := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineDimensionUOM'))), v_null_value );
                ------------------------------------------------------------------------------------------------------------------------
                /* version 1.9 CR 2468 */
                v_node                                    := 'OrderLineDate';
                v_inv_spec_rec.order_line_date            := to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode4,'OrderLineDate '))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
                v_node                                    := 'OrderLinePerTimeUnit';
                v_inv_spec_rec.order_line_per_time_unit   := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLinePerTimeUnit'))), v_null_value );
                v_node                                    := 'OrderLineUnitPrice';
                v_inv_spec_rec.order_line_unit_price      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineUnitPrice'))), v_null_value );
                v_node                                    := 'OrderLineAmount';
                v_inv_spec_rec.order_line_unit_amount     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineAmount'))), v_null_value );
                v_node                                    := 'OrderLineCargoType';
                v_inv_spec_rec.order_line_cargo_type      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineCargoType'))), v_null_value );
                v_node                                    := 'OrderLineFreightCalcWeight';
                v_inv_spec_rec.order_line_freight_calc_wt := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineFreightCalcWeight'))), v_null_value );
                v_node                                    := 'OrderLineFreightCalcWeightUOM';
                v_inv_spec_rec.order_line_frt_calc_wt_uom := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineFreightCalcWeightUOM'))), v_null_value );
                v_node                                    := 'OrderLineVolume';
                v_inv_spec_rec.order_line_volume          := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineVolume'))), v_null_value );
                v_node                                    := 'OrderLineVolumeUOM';
                v_inv_spec_rec.order_line_volume_uom      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineVolumeUOM'))), v_null_value );
                v_node                                    := 'OrderLineLoadMeter';
                v_inv_spec_rec.order_line_load_meter      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineLoadMeter'))), v_null_value );
                v_node                                    := 'OrderLineCargoLabel';
                v_inv_spec_rec.order_line_cargo_label     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineCargoLabel'))), v_null_value );
                ----------------------------------------------------------------------------------------------------------------------------------------------
                /* start CR 3118 */
                v_node                                     := 'OrderLineGrossWeight';
                v_inv_spec_rec.order_line_gross_weight     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineGrossWeight'))), v_null_value );
                v_node                                     := 'OrderLineGrossWeightUOM';
                v_inv_spec_rec.order_line_gross_weight_uom := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode4, 'OrderLineGrossWeightUOM'))), v_null_value );
                /* end CR 3118 */
                v_spec_line (e) := v_inv_spec_rec;
                msgtext         := 'Spec Details: ' ||v_inv_spec_rec.order_line_number || v_inv_spec_rec.order_line_text|| v_inv_spec_rec.order_line_no_of_packages || v_inv_spec_rec.order_line_pallet||v_inv_spec_rec.order_line_pp_price||v_inv_spec_rec.order_line_net_weight;
                xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
              END LOOP;
            END LOOP;
            ----------------------------------------------------------------------------------------------------------
            v_node                          := 'xxAggregateLine';
            v_aggregate                     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, 'AggregateLine'))), v_null_value);
            IF v_aggregate                   = '1' THEN
              v_orderline_rec.aggregateline := true;
            ELSE
              v_orderline_rec.aggregateline := false;
            END IF;
            invline_no               := invline_no + 1;
            v_orderline_rec.speclines:=v_spec_line;
            /* start CR 3118 */
            v_orderline_rec.ref_spec_line:=v_ref_line;
            /* end CR 3118 */
            /* start wave 2 modification */
            v_orderline_rec.inv_spec_disc:=lv_inv_spec_disc;
            /* end wave 2 modification */
            v_order_line (d) := v_orderline_rec;
            msgtext          := 'line invoice Details: ' || v_orderline_rec.description;
            xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
          EXCEPTION
          WHEN OTHERS THEN
            msgid   := SQLCODE;
            msgtext := msgtext || '; Error parsing lines: ' || v_node || ' value=' || NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode3, v_node))), v_null_value) || ' ';
            raise;
          END;
        END LOOP;
        v_orderhead_rec.orderlines     := v_order_line;
        v_orderhead_rec.invspecurl     :=v_spec_url;
        v_orderhead_rec.invprint       :=lv_inv_custom_print;
        v_orderhead_rec.invaddr        :=lv_inv_customer_addr;
        v_orderhead_rec.lv_private_cust:=lv_private_cust;
        v_order_head (c)               := v_orderhead_rec;
      END LOOP;
      -- Til slutt putter jeg ordrehodetabellen inn i kollonnen p? batchordrerec'en
      v_batch_order_rec.v_order_head := v_order_head;
    END LOOP;
    /* start wave 2 modification */
    
	lv_shipment_head := shipment_head ();
    lv_shipment_head.extend (xdb.dbms_xmldom.getlength (shipment_order_proplist));
    shipment_order_proplist := xxcu_common_util_xml.selectnodes (v_inxmldom, msg_shipment_order_url);
    msgtext                 := 'antall ordrehoder shipments: ' || xdb.dbms_xmldom.getlength (shipment_order_proplist);
    xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
    FOR bjjj IN 1 .. xdb.dbms_xmldom.getlength (shipment_order_proplist)
    LOOP
      lv_shipment_head.extend;
      curnode1234 := xdb.dbms_xmldom.item (shipment_order_proplist, bjjj - 1);
      msgsrc      := 'xxcu_ont_create_order_parser BODY.parse_xmlmessage';
      msgtext     := 'parsing Shipment order head node';
      xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
      ----xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
      lv_shipment_order_rec.customer_num              := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'CustomerNumber'))), v_null_value);
      lv_shipment_order_rec.trans_curr_code           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'TransactionalCurrencyCode'))), v_null_value);
      lv_shipment_order_rec.ordered_date              := to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode1234,'OrderedDate '))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
      lv_shipment_order_rec.payment_provider_trans_id := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'PaymentProviderTransID'))), v_null_value);
      lv_shipment_order_rec.reserved_amount           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ReservedAmount'))), v_null_value);
      lv_shipment_order_rec.source                    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'Source'))), v_null_value);
      lv_shipment_order_rec.sender_reference          := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'SenderReference'))), v_null_value);
      lv_shipment_order_rec.shipment_id_num           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ShipmentIDNumber'))), v_null_value);
      lv_shipment_order_rec.returned                  := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'Returned'))), v_null_value);
      lv_shipment_order_rec.freight_cal_wt            := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'FreightCalculatedWeight'))), v_null_value);
      lv_shipment_order_rec.price_zone                := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'PriceZone'))), v_null_value);
      lv_shipment_order_rec.weight_group              := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'WeightGroup'))), v_null_value);
      lv_shipment_order_rec.num_of_pkgs               := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'NumberofPackages'))), v_null_value);
      lv_shipment_order_rec.sender_name               := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'SenderName'))), v_null_value);
      lv_shipment_order_rec.ship_from_addr1           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ShipFromAddress1'))), v_null_value);
      lv_shipment_order_rec.ship_from_addr2           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ShipFromAddress2'))), v_null_value);
      lv_shipment_order_rec.ship_from_postal_code     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ShipFromPostalCode'))), v_null_value);
      lv_shipment_order_rec.ship_from_city            := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ShipFromCity'))), v_null_value);
      lv_shipment_order_rec.ship_from_country         := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ShipFromCountry'))), v_null_value);
      lv_shipment_order_rec.receiver_reference        := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ReceiverReference'))), v_null_value);
      lv_shipment_order_rec.receiver_name             := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ReceiverName'))), v_null_value);
      lv_shipment_order_rec.ship_to_addr1             := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ShipToAddress1'))), v_null_value);
      lv_shipment_order_rec.ship_to_addr2             := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ShipToAddress2'))), v_null_value);
      lv_shipment_order_rec.ship_to_postal_code       := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ShipToPostalCode'))), v_null_value);
      lv_shipment_order_rec.ship_to_city              := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ShipToCity'))), v_null_value);
      lv_shipment_order_rec.ship_to_country           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ShipToCountry'))), v_null_value);
      lv_shipment_order_rec.delivery_point            := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'DeliveryPoint'))), v_null_value);
      lv_shipment_order_rec.delivery_addr1            := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'DeliveryAddress1'))), v_null_value);
      lv_shipment_order_rec.delivery_addr2            := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'DeliveryAddress2'))), v_null_value);
      lv_shipment_order_rec.delivery_postal_code      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'DeliveryPostalCode'))), v_null_value);
      lv_shipment_order_rec.delivery_city             := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'DeliveryCity'))), v_null_value);
      lv_shipment_order_rec.delivery_country          := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'DeliveryCountry'))), v_null_value);
      lv_shipment_order_rec.volume_factor             := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'VolumeFactor'))), v_null_value);
      lv_shipment_order_rec.shipment_sum              := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'ShipmentSum'))), v_null_value);
      lv_shipment_order_rec.message_to_cust           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'MessageToCustomer'))), v_null_value);
      lv_shipment_order_rec.po_reference              := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'POReference'))), v_null_value);
      lv_shipment_order_rec.agreement_name            := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'AgreementName'))), v_null_value);
      lv_shipment_order_rec.postal_code_to            := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'PostalCodeTo'))), v_null_value);
      lv_shipment_order_rec.postal_code_from          := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'PostalCodeFrom'))), v_null_value);
      lv_shipment_order_rec.department                := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode1234, 'Department'))), v_null_value);
      /* start CR 4419 */
      IF v_msgid                 = '1255' THEN
        terminal_lines_proplist := xxcu_common_util_xml.selectnodes (curnode1234, '/PPOrderImport/Order/Batch/Shipment['||bjjj||']/Terminals');--Path changed for OU changes , -- Q2Q change
      ELSE
        terminal_lines_proplist := xxcu_common_util_xml.selectnodes (curnode1234, '/OEOrderImport/Order/Batch/Shipment['||bjjj||']/Terminals');--Path changed for OU changes ,
      END IF;
      msgtext := 'antall ordrehoder terminal lines: ' || xdb.dbms_xmldom.getlength (terminal_lines_proplist);
      xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
      lv_terminal := terminal_lines ();
      lv_terminal.extend (xdb.dbms_xmldom.getlength (terminal_lines_proplist));
      FOR cjjll IN 1 .. xdb.dbms_xmldom.getlength (terminal_lines_proplist)
      LOOP
        --lv_packagelines.extend;
        curnode2123778                   := xdb.dbms_xmldom.item (terminal_lines_proplist, cjjll - 1);
        lv_terminal_rec.terminal_name    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2123778, 'TerminalName'))), v_null_value);
        lv_terminal_rec.terminal_id      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2123778, 'TerminalID'))), v_null_value);
        lv_terminal(cjjll)               :=lv_terminal_rec;
        lv_shipment_order_rec.lv_terminal:=lv_terminal;
      END LOOP;
      /* end CR 4419 */
      --package_lines_proplist                          := xxcu_common_util_xml.selectnodes (v_inxmldom, msg_pkg_lines_url);
      --  msgtext                                         := 'antall ordrehoder shipment lines: ' || xdb.dbms_xmldom.getlength (package_lines_proplist);
      --xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
      IF v_msgid                = '1255' THEN
        package_lines_proplist := xxcu_common_util_xml.selectnodes (curnode1234, '/PPOrderImport/Order/Batch/Shipment['||bjjj||']/Package');--Path changed for OU changes , -- Q2Q change
      ELSE
        package_lines_proplist := xxcu_common_util_xml.selectnodes (curnode1234, '/OEOrderImport/Order/Batch/Shipment['||bjjj||']/Package');--Path changed for OU changes ,
      END IF;
      msgtext := 'antall ordrehoder package lines: ' || xdb.dbms_xmldom.getlength (package_lines_proplist);
      xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
      lv_packagelines := package_lines ();
      lv_packagelines.extend (xdb.dbms_xmldom.getlength (package_lines_proplist));
      FOR cjj IN 1 .. xdb.dbms_xmldom.getlength (package_lines_proplist)
      LOOP
        --lv_packagelines.extend;
        curnode2123                          := xdb.dbms_xmldom.item (package_lines_proplist, cjj - 1);
        lv_packagelines_rec.cargo_id_num     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2123, 'CargoIDNumber'))), v_null_value);
        lv_packagelines_rec.weight           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2123, 'Weight'))), v_null_value);
        lv_packagelines_rec.volume           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2123, 'Volume'))), v_null_value);
        lv_packagelines_rec.volume_weight    := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2123, 'VolumeWeight'))), v_null_value);
        lv_packagelines_rec.received_time    := to_date(REPLACE(NVL(xxcu_common_util_txt.removestrbrakes((xxcu_common_util_xml.valueof(curnode2123,'ReceivedTime '))), v_null_value),'T',' '), xxcu_intf_sys.gc_xmldatetimeformat);--to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')) ,XXCU_INTF_SYS.gc_xmldatetimeformat);--to_date(to_char(to_date(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'TrxDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY'); --to_date(to_date(to_char(xxcu_common_util_txt.removestrbrakes(xxcu_common_util_xml.valueof(l_node, 'GlDate')),'YYYY-MM-DD'),'DD-MON-YY'),'DD-MON-YY');
        lv_packagelines_rec.Freight_Calculated_Weight  := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode2123, 'FreightCalculatedWeight'))), v_null_value);  ---CR 5280
        lv_packagelines(cjj)                 :=lv_packagelines_rec;
        lv_shipment_order_rec.lv_packagelines:=lv_packagelines;
      END LOOP;
      IF v_msgid              = '1255' THEN
        price_lines_proplist := xxcu_common_util_xml.selectnodes (curnode1234, '/PPOrderImport/Order/Batch/Shipment['||bjjj||']/PriceLine');--Path changed for OU changes , -- Q2Q change
      ELSE
        price_lines_proplist := xxcu_common_util_xml.selectnodes (curnode1234, '/OEOrderImport/Order/Batch/Shipment['||bjjj||']/PriceLine');--Path changed for OU changes ,
      END IF;
      --price_lines_proplist := xxcu_common_util_xml.selectnodes (v_inxmldom, msg_price_lines_url);
      msgtext := 'antall ordrehoder price lines: ' || xdb.dbms_xmldom.getlength (price_lines_proplist);
      xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
      lv_pricelines := price_lines ();
      lv_pricelines.extend (xdb.dbms_xmldom.getlength (price_lines_proplist));
      FOR cjjk IN 1 .. xdb.dbms_xmldom.getlength (price_lines_proplist)
      LOOP
        --lv_pricelines.extend;
        curnode21235                          := xdb.dbms_xmldom.item (price_lines_proplist, cjjk - 1);
        lv_pricelines_rec.item_number         := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'ItemNumber'))), v_null_value);
        lv_pricelines_rec.Cargo_ID_Number     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'CargoIDNumber'))), v_null_value); --CR 5280
        lv_pricelines_rec.ordered_qty         := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'OrderedQuantity'))), v_null_value);
        lv_pricelines_rec.unit_list_price     := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'UnitListPrice'))), v_null_value);
        lv_pricelines_rec.unit_net_price      := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'UnitNetPrice'))), v_null_value);
        lv_pricelines_rec.price_adjs_per_unit := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'PriceAdjustmentPerUnit'))), v_null_value);
        lv_pricelines_rec.tax_code            := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'TaxCode'))), v_null_value);
        lv_pricelines_rec.tax                 := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'Tax'))), v_null_value);
        lv_pricelines_rec.tax_value           := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'TaxValue'))), v_null_value);
        lv_pricelines_rec.country_from        := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'CountryCodeFrom'))), v_null_value);
        lv_pricelines_rec.country_to          := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'CountryCodeTo'))), v_null_value);
        lv_pricelines_rec.disc_breakup_info   := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'DiscountBreakupInfo'))), v_null_value);
        lv_pricelines_rec.quantity_uom        := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'QuantityUOM'))), v_null_value);
        lv_pricelines_rec.product_code        := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'ProductCode'))), v_null_value);
        /* start defect 3702*/
        --  lv_pricelines_rec.product_name        := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'ProductName'))), v_null_value);
        lv_pricelines_rec.department := NVL (xxcu_common_util_txt.removestrbrakes ((xxcu_common_util_xml.valueof (curnode21235, 'Department'))), v_null_value);
        /* end defect 3702 */
        lv_pricelines(cjjk)                 :=lv_pricelines_rec;
        lv_shipment_order_rec.lv_pricelines :=lv_pricelines;
      END LOOP;
      lv_shipment_head (bjjj) := lv_shipment_order_rec;
      -- Til slutt putter jeg ordrehodetabellen inn i kollonnen p? batchordrerec'en
      v_batch_order_rec.lv_shipment_head := lv_shipment_head;
      --  msgtext                              := 'antall ordrehode end ' || xdb.dbms_xmldom.getlength (price_lines_proplist);
      --xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
      --:=lv_shipment_order_rec;
    END LOOP;
    /* end wave 2 modification */
    msgsrc  := 'xxcu_ont_create_order_parser BODY.parse_xmlmessage';
    msgtext := 'Order Message parsed :' || '  v_batch_order_rec.BatchID : ' || v_batch_order_rec.batchid || '  Parsetid: ' || trim (TO_CHAR ((sysdate - startdate) * 1440, '999990.99')) || ' minutes on the ' || invline_no || ' Order Lines';
    xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
    xxcu_common_util.closetmpclob (olob);
    msgtext := '';
    --Removes similar orderheads
    /*---commented
    xxcu_common_log_rt.msglog (msgtype, 'To start with aggregating', msgid, usermsg, msgsrc, msgjobid);
    v_indexh := 0;
    v_indexL := 0;
    txtstr   := 'start' ;
    FOR aH IN 1..v_batch_order_rec.v_order_head.count
    LOOP
    IF (v_last_customerno != v_batch_order_rec.v_order_head(ah).customer_number OR v_last_date != v_batch_order_rec.v_order_head(ah).ordereddate OR v_last_valuta_code != v_batch_order_rec.v_order_head(ah).currency_code OR v_last_source != v_batch_order_rec.v_order_head(ah).order_source) AND v_batch_order_rec.v_order_head(ah).Aggregatehead THEN
    txtstr              := 'in if';
    v_aggr_order_head.extend(1);
    v_indexH                                    := v_indexH +1;
    txtstr                                      := 'extend';
    v_aggr_order_head(v_indexh).customer_number :=v_batch_order_rec.v_order_head(ah).customer_number;
    v_aggr_order_head(v_indexh).ordereddate     := v_batch_order_rec.v_order_head(ah).ordereddate;
    v_aggr_order_head(v_indexh).currency_code     := v_batch_order_rec.v_order_head(ah).currency_code;
    v_aggr_order_head(v_indexh).order_source    := v_batch_order_rec.v_order_head(ah).order_source;
    txtstr                                      := 'order_line()';
    v_aggr_order_head(v_indexh).orderlines      := order_line ();
    v_indexL                                    := 1;
    --   ----xxcu_common_log_rt.msglog (msgtype, 'NYTT HODE:'||v_last_customerno, msgid, usermsg, msgsrc, msgjobid);
    END IF;
    --Order lines
    txtstr := 'for AL'|| ah;
    v_aggr_order_head(v_indexh).orderlines.extend;--(1);
    FOR aL IN 1..v_batch_order_rec.v_order_head(ah).Orderlines.count
    LOOP
    txtstr := 'extend line';
    --v_aggr_order_head(v_indexh).orderlines.extend;--(1);
    v_aggr_order_head(v_indexh).orderlines(v_indexl) := v_batch_order_rec.v_order_head(ah).orderlines(aL);
    --   --xxcu_common_log_rt.msglog (msgtype, 'Aggr articleno: '||v_batch_order_rec.v_order_head(ah).Orderlines(AL).articleno,msgid, usermsg, msgsrc, msgjobid);
    txtstr   := 'orderlines(v_indexl)';
    v_indexL := v_indexL +1;
    END LOOP;
    v_last_customerno  := v_batch_order_rec.v_order_head(ah).customer_number;
    v_last_date        := v_batch_order_rec.v_order_head(ah).ordereddate;
    v_last_valuta_code := v_batch_order_rec.v_order_head(ah).currency_code;
    v_last_source      := v_batch_order_rec.v_order_head(ah).order_source;
    txtstr             := 'end';
    END LOOP;
    msgtext :='Finished with aggregating';
    xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
    v_batch_order_rec.v_order_head := v_aggr_order_head;
    */
    ------------------------------------------------------------------------------------------------------------------------
    msgsrc  := 'xxcu_ont_create_order_parser BODY.parse_xmlmessage';
    msgtext := 'Parsing completed. Calling business API : apps.xxcu_ont_create_order_pkg.createorder;';
    xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
    xxcu_common_log_rt.msglog (msgtype, 'batch_id:'||v_batch_order_rec.batchid, msgid, usermsg, msgsrc, msgjobid);
    msgtext := 'xdb.dbms_xmldom.getlength (shipment_order_proplist) ' || xdb.dbms_xmldom.getlength (shipment_order_proplist);
    xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
    IF(xdb.dbms_xmldom.getlength (shipment_order_proplist)>=1) THEN
      msgtext                                             := 'calling create lm order ' || xdb.dbms_xmldom.getlength (price_lines_proplist);
      xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
      apps.xxcu_ont_create_order_pkg.create_lm_order (p_batch_order => v_batch_order_rec,p_shipment_order=> lv_shipment_order_rec,p_org_id=>ln_org_id,p_status_code => v_status_code, p_error_message => v_error_message );
    ELSE
      apps.xxcu_ont_create_order_pkg.createorder (p_batch_order => v_batch_order_rec, p_status_code => v_status_code, p_error_message => v_error_message );
    END IF;
	
    ------------------------------------------------------------------------------------------------------------------------
    xxcu_common_util_xml.freedocument (v_inxmldom);
    -----------------------------------------------------------------
    xxcu_common_util.closetmpclob (olob);
    msgsrc  := 'xxcu_ont_create_order_parser.parse_xmlmessage';
    msgtext := 'parsing inbound XML message  finished.  API status received: ' || ' status code: ' || v_status_code || '; status message: ' || v_error_message;
    xxcu_common_log_rt.msglog (msgtype, msgtext, v_msgid, usermsg, msgsrc, msgjobid);
    msgtext := '3';
    xxcu_common_log_rt.set_eventjoblogstop (ip_status => msgtext, ip_job_id => msgjobid);
    op_status_code   := v_status_code;
    op_error_message := v_error_message;
	
    --END IF;
    --End of OrderSource
  EXCEPTION
  WHEN e_error THEN
    xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_exception, msgtext => l_proc_loc, msgcode => v_msgid, usermsg => '1', -- not sure what this is, maps to user_id in log table
    msgsrc => msgsrc || '.' || c_proc_name, msgjobid => l_msg_job_id);
    op_status_code   := 2;
    op_error_message := l_proc_loc;
  WHEN OTHERS THEN
    msgtype := 'ERR';
    msgid   := SQLCODE;
    msgtext := msgtext || ' location: '||l_proc_loc || ' Error: ' || sqlerrm (msgid);
    msgsrc  := 'xxcu_ont_create_order_parser.parse_xmlmessage';
    xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
    op_status_code   := 2;
    op_error_message := msgtext;
    xxcu_common_util_xml.freedocument (v_inxmldom);
  END parse_xmlmessage;
/* ----------------------------------------------------------------------------------------
* dynconverter
*
*   Procedure     : dynconverter
*   description   : Procedure dynamic converter
*   scope         : public
*   arguments
*        in                    : extfilename : file name
*                                logdirin : log dir in
*                                logdirout : log dir out
*                                loadrefjobid : job id
*                                curref : cursor ref
*
*        in/out                :
*
*        out                   :outstatus : Interface Status
*
*
*  Date               Author              Description
*  ---------         -------------        -------------------------------------------------------
*  21.12.2015        Rahul Kumar Singh     Created
----------------------------------------------------------------------------------------*/
 
 PROCEDURE dynconverter(
      extfilename  IN VARCHAR2 DEFAULT NULL,
      logdirin     IN VARCHAR2 DEFAULT NULL,
      logdirout    IN VARCHAR2 DEFAULT NULL,
      loadrefjobid IN VARCHAR2,
      curref       IN VARCHAR2 DEFAULT NULL,
      outstatus OUT NUMBER )
  IS
    outfiletag utl_file.file_type;
    infiletag utl_file.file_type;
    txtbfile bfile;
    logtxtdir   VARCHAR2 (100) := 'EDITXTFILES';
    defxmldir   VARCHAR2 (100) := 'INTFIIN';
    logerrdir   VARCHAR2 (100) := 'INTFPENDING';
    logxmldir   VARCHAR2 (100);
    logdir_err  VARCHAR2 (100) := NULL;
    txtstr      VARCHAR2 (32767);
    outfilename VARCHAR2 (100);
    logdir      VARCHAR2 (100);
    infilename  VARCHAR2 (100);
    decpos      INTEGER;
    logdir_in   VARCHAR2 (100) := 'EDITXTFILES';
    logdir_out  VARCHAR2 (100) := 'XMLWEBFILES';
    xmllob CLOB;
    cvtstatus       NUMBER;
    inmsg_statdesc  VARCHAR2 (200) := NULL;
    v_paramvaltring VARCHAR2 (1000);
    v_msgid         VARCHAR2 (20);
    v_event_rec xxcu_intf_event.basicevent_rec;
    v_status_code   NUMBER;
    v_error_message VARCHAR2 (2000);
  BEGIN
    IF logdirin IS NULL THEN
      logdir_in := 'EDITXTFILES';
    ELSE
      logdir_in := logdirin;
    END IF;
    IF logdirout IS NULL THEN
      logdir_out := 'XMLWEBFILES';
    ELSE
      logdir_out := logdirout;
    END IF;
    IF logdir_out IS NULL THEN
      logxmldir   := xxcu_common_util.get_oradirpath (defxmldir);
    ELSE
      logxmldir := xxcu_common_util.get_oradirpath (logdir_out);
    END IF;
    IF logdir_err IS NULL THEN
      logerrdir   := 'INTFPENDING';
    ELSE
      logerrdir := logdir_in;
    END IF;
    msgid           := '1117';
    v_paramvaltring := extfilename || ',' || logdir_in || ',' || logdir_out || ',' || loadrefjobid || ',' || curref || ',' || outstatus;
	
    --msgtext := 'STARTED';
    --msgjobid := --xxcu_common_log_rt.set_eventjoblogstart (msgtext, msgid, msgsrc, v_paramvaltring);
    --msgtext := 'Loading into buffer, incoming file name ' || extfilename || ' Job ID :' || msgjobid;
    ----xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid);
    ----------------------------------------------------------------------------------------------------
    -- loading incoming file into  CLOB
	
    xxcu_common_util.get_filetoclob (extfilename => extfilename, logdirin => logdirin, logdirout => logdirout, xmllob => xmllob);
	
    ----------------------------------------------------------------------------------------------------
    ---------------------Parsing phaze----------------------------
    parse_xmlmessage (ip_lob => xmllob, ip_msgid => v_msgid, op_status_code => v_status_code, op_error_message => v_error_message);
	
    ---------------------business logic------------------------------
    xxcu_common_util.closetmpclob (xmllob);
    msgtext := 'FINISHED';
    ----xxcu_common_log_rt.set_eventjoblogstop (msgtext, msgjobid);
    outstatus := 0;
  EXCEPTION
  WHEN OTHERS THEN
    outstatus := -1;
    msgtype   := 'ERR';
    msgid     := SQLCODE;
    msgtext   := sqlerrm (msgid);
    msgsrc    := 'xxcu_ont_create_order_parser.DynConverter';
	
    --xxcu_common_log_rt.msglog (msgtype, msgtext, msgid, usermsg, msgsrc, msgjobid, 4);
	
  END dynconverter;
  
-------------------------end package------------------------------------
END xxcu_ont_create_order_parser;
/
show error;