g_org_id
lv_prepay
ln_total_amount

g_program_loc
g_order_source_id
v_orig_sys_document_ref
v_headers_count
v_header_id
v_orderline_count
v_max_date
v_min_date
lv_orig_system
lv_distri_flag

xxcu_create_svcs_pkg.create_person_cust_bo 

x_person_cust_obj_tbl hz_person_cust_bo_tbl;

lv_acct_number
ln_sold_to_org
p_object_version_number

ln_resp_id -----responsibility_name LIKE 'PB AR Super User'
ln_appl_id

fnd_global.apps_initialize (user_id => g_user_id, resp_id => ln_resp_id, resp_appl_id => ln_appl_id );

mo_global.init ('AR');
mo_global.set_policy_context ('S', p_batch_order.v_order_head (hi).org_id);

ln_object_version_number

lv_party_rec hz_party_v2pub.party_rec_type

hz_cust_account_v2pub.update_cust_account
ln_sold_to_org
ln_application_id
ln_attribute_group_id
l_attributes_row_table
l_attributes_data_table

ln_person_profile_id
ln_party_id

hz_extensibility_pub.process_person_record

ln_extension_id

lv_failed_row_id_list


lv_errors_tbl
ln_tax
lv_tax

g_intf_inv_spec_seq
lv_curr_code
lv_price_date


xxcu_interface_specifications-insert
xxcu_interface_spec_ref--insert
ln_spec_count
xxcu_intf_discount_spec---insert
lv_term_name
ln_term
lv_wrong_cust

oe_headers_iface_all-update
l_transaction_id
oe_processing_msgs--insert
oe_processing_msgs_tl--insert
lv_wrong_tax
ln_order_type_id
lv_tax_calc_event_code
oe_lines_iface_all--update
oe_price_adjs_iface_all--update
lv_sales_yes_no
lv_wrong_salesper
lv_wrong_price
lv_wrong_ret_data
l_item_type
l_order_count
l_country_codes