PROCEDURE createorder(
      p_batch_order IN xxcu_ont_create_order_parser.batch_order_rec,
      --p_operating_unit  IN              xxcu_ont_create_order_parser.batch_order_rec.org_id,
      p_status_code OUT NUMBER,
      p_error_message OUT VARCHAR2 )
  AS
    --v_order_head xxcu_ont_create_order_parser.order_head         := order_head ();
    v_order_head xxcu_ont_create_order_parser.order_head:= xxcu_ont_create_order_parser.order_head();
    v_order_line xxcu_ont_create_order_parser.order_line:=xxcu_ont_create_order_parser.order_line();
    v_inv_spec xxcu_ont_create_order_parser.spec_line   :=xxcu_ont_create_order_parser.spec_line();
    v_header_id             NUMBER;
    v_orderline_count       NUMBER := 0;
    ln_source_cnt           NUMBER;
    lv_is_bill              VARCHAR2(100):='FALSE';
    lv_cust_count           NUMBER       :=0;
    v_finish_status         BOOLEAN;
    v_startdate             DATE   := to_date(sysdate,'DD-MON-YY HH24:MI:SS');
    v_headers_count         NUMBER := 0;
    v_batch_seq_no          VARCHAR2 (10000);
    v_version_number        NUMBER;
    v_status_function       NUMBER := g_code_ok;
    v_orig_sys_document_ref VARCHAR2 (100);
    v_upd_orig_sys_line_ref VARCHAR2 (50); -- 1161
    v_errors                NUMBER;
    l_party_rec hz_party_v2pub.party_rec_type;
    ln_profile_id NUMBER;
    l_person_rec_type hz_party_v2pub.person_rec_type;
    --Logg attributes
    v_num_orderheads       NUMBER := 0;
    ln_party_obj_version   NUMBER;
    v_num_orderlines       NUMBER := 0;
    v_max_date             DATE   := NULL;
    v_min_date             DATE   := NULL;
    l_status_code          NUMBER;
    ln_order_type_id       NUMBER;
    lv_tax_calc_event_code VARCHAR2(30 byte); ---Added by kavita as per CR#2449
    ln_batch_count         NUMBER;
    l_message              VARCHAR2(1000);
    l_log_label            VARCHAR2(200);
    e_error                EXCEPTION;
    ln_count               NUMBER:=0;
    ln_sum                 NUMBER:=0;
    e_wrong_cust           EXCEPTION;
    e_mixed_order          EXCEPTION;
    lv_customer_num        VARCHAR2(100);
    lv_email               VARCHAR2(1000);
    ln_org_id              NUMBER;
    lv_price_date          DATE;
    lv_curr_code           VARCHAR2(100);
    l_transaction_id       NUMBER;
    lv_msg_text            VARCHAR2(4000);
    lv_tax                 VARCHAR2(100);
    e_null_tax             EXCEPTION;
    ln_total_amount        NUMBER:=0;
    e_invalid_source       EXCEPTION;
    ln_header_id           NUMBER;
    ln_hold                NUMBER;
    ln_spec_count          NUMBER;
    /* version 1.27 */
    ln_k_count        NUMBER:=0;
    lv_wrong_price    VARCHAR2(10);
    lv_wrong_cust     VARCHAR2(10);
    lv_wrong_ret_data VARCHAR2(10);
    lv_wrong_tax      VARCHAR2(10);
    lv_wrong_ref      VARCHAR2(10);
    lv_wrong_salesper VARCHAR2(10);
    /*version 1.23*/
    ln_customer_id  NUMBER;
    lv_party_type   VARCHAR2(20);
    lv_prepay       VARCHAR2(10):='Y';
    ln_print_count  NUMBER      :=0;
    lv_sales_yes_no VARCHAR2(20);
    ln_tax          NUMBER;
    /* start defect 3921 */
    ln_req_id            NUMBER;
    lv_status            VARCHAR2(20):='X';
    lv_phase             VARCHAR2(20):='Z';
    ln_resp_id           NUMBER;
    ln_app_id            NUMBER;
    lv_order_source_cust VARCHAR2(50);
    /*end */
    --Added by Divyansh for defect #8447
    l_item_type    NUMBER;
    l_item_id      NUMBER;
    l_order_count  NUMBER;
    ln_total_addr  NUMBER;
    lv_acct_number VARCHAR2(240):=NULL;
    --Added by Divyansh for defect #8447
    l_country_codes NUMBER;--Added by Divyansh for defect #8629
    x_person_cust_obj_tbl hz_person_cust_bo_tbl;
    lv_person_rec_type hz_party_v2pub.person_rec_type;-- CR 5026
    lv_party_rec hz_party_v2pub.party_rec_type;       -- CR 5026
    /*x_person_cust_obj         OUT NOCOPY hz_person_cust_bo,*/
    --removed as per the defect 1247
    p_return_status VARCHAR2(10);
    x_return_status VARCHAR2(10);
    x_msg_count     NUMBER;
    p_msg_data      VARCHAR2(2000);
    x_msg_data      VARCHAR2(2000);
    p_person_id     NUMBER;
    --ln_resp_id number;
    ln_appl_id     NUMBER;
    lv_orig_system VARCHAR2(240);
    ln_sold_to_org NUMBER;
    p_cust_account_rec hz_cust_account_v2pub.cust_account_rec_type;
    p_object_version_number  NUMBER;
    ln_object_version_number NUMBER;
    l_attributes_row_table ego_user_attr_row_table;
    l_attributes_data_table ego_user_attr_data_table;
    l_change_info_table ego_user_attr_change_table;
    ln_extension_id       NUMBER;
    ln_party_id           NUMBER;
    lv_mode               VARCHAR2(1000);
    lv_failed_row_id_list VARCHAR2(1000);
    lv_return_status      VARCHAR2(255):='S';---defect 4609
    lv_digipost_address   VARCHAR2(255);
    ln_errorcode          NUMBER;
    ln_msg_count          NUMBER;
    lv_msg_data           VARCHAR2(4000);
    ln_organization_id    NUMBER;
    ln_application_id     NUMBER;
    ln_attribute_group_id NUMBER;
    lv_attr_group_type    VARCHAR2(100);
    lv_attr_group_name    VARCHAR2(100);
    lv_attribute_name     VARCHAR2(2000);
    ln_person_profile_id  NUMBER;
    lv_term_name          VARCHAR2(100);
    ln_term               NUMBER;
    lv_distri_flag        VARCHAR2(10);--CR 5144
  BEGIN
    -- p_batch_order.v_order_head:= xxcu_ont_create_order_parser.order_head();
    v_order_head := xxcu_ont_create_order_parser.order_head();
    v_order_line := xxcu_ont_create_order_parser.order_line();
    v_inv_spec   :=xxcu_ont_create_order_parser.spec_line();
    v_order_head.extend(1);
    v_order_line.extend;
    v_inv_spec.extend;
    p_status_code := g_code_ok;
    g_program_loc := 'starter';
    --xxcu_int_util_pkg.int_apps_initialize(apps.fnd_profile.VALUE('ORG_ID'), upper('XXCU_ONT_CREATE_ORDER_PKG'), l_status_code, l_message);
    -- MO_GLOBAL.INIT('ONT');
    IF l_status_code <> 0 THEN
      l_log_label    := 'apps_initialize';
      l_message      := 'Unable to initialize application ' || l_message;
      raise e_error;
    END IF;
    xxcu_log_pkg.log (p_log_level => fnd_log.level_statement, p_module_name => gpackagename, p_log_text => 'Number of order headers: ' || p_batch_order.v_order_head.count );
    v_batch_seq_no := ' || BatchId:' || p_batch_order.batchid || ' Messageno:' || p_batch_order.messagesequenceno || ' || ';
    xxcu_log_pkg.log (p_log_level => fnd_log.level_statement, p_module_name => gpackagename, p_log_text => 'Ready to createorderheader');
    dbms_output.put_line('Hi:' || p_batch_order.v_order_head.count);
    /* added for version 1.9 Defect# 209,167 */
    /* BEGIN
    SELECT COUNT(batchid)
    INTO ln_batch_count
    FROM XXCU.XXCU_ONT_INT_ORDER_BATCH
    WHERE batchid=p_batch_order.batchid;
    EXCEPTION
    WHEN OTHERS THEN
    ln_batch_count:=0;
    END;*/
    IF(p_batch_order.batchid IS NULL ) THEN--OR ln_batch_count >0 ) THEN
      raise e_error;
    END IF;
    FOR hi IN 1 .. p_batch_order.v_order_head.count
    LOOP
      BEGIN
        ln_count:=0;
        ln_sum  :=0;
        initialize_variables(p_batch_order.v_order_head (hi).org_id);
        dbms_output.put_line('g_user_id:'||g_user_id);
        g_org_id:=p_batch_order.v_order_head (hi).org_id;
        /* Version 1.9 Defect # 216 */
        /*    BEGIN
        FOR p IN 1 .. p_batch_order.v_order_head (hi).orderlines.COUNT
        LOOP
        dbms_output.put_line(SIGN(p_batch_order.v_order_head (hi).orderlines(p).quantity));
        /* start defect 2413
        IF(p_batch_order.v_order_head (hi).orderlines(p).quantity=0) THEN
        ln_count                                              :=1;
        ELSE
        ln_count:=SIGN(p_batch_order.v_order_head (hi).orderlines(p).quantity);
        END IF;
        /* end defect 2413
        ln_sum :=ln_count+ln_sum;
        END LOOP;
        dbms_output.put_line('ln_sum:'||ln_sum);
        END;
        IF(ABS(ln_sum)<>p_batch_order.v_order_head (hi).orderlines.COUNT) THEN
        raise e_mixed_order;
        END IF;*/
        /* Version 1.25 CR # 1851 Prepaid Order */
        BEGIN
          ln_total_amount :=0;
          /* start  CR 2811  */
          lv_prepay                                          :='Y';
          IF(upper(p_batch_order.v_order_head (hi).order_type)='RETURN') THEN
            lv_prepay                                        :='N';
          END IF;
          /* end CR 2811 */
          IF(p_batch_order.v_order_head (hi).prepayment_flag='Y' AND lv_prepay<>'N' AND p_batch_order.v_order_head (hi).prepaid_amount IS NULL) THEN ---defect 3922
            FOR b IN 1 .. p_batch_order.v_order_head (hi).orderlines.count
            LOOP
              -- dbms_output.put_line(SIGN(p_batch_order.v_order_head (hi).orderlines(p).quantity));
              ln_total_amount :=ln_total_amount+(p_batch_order.v_order_head (hi).orderlines(b).unit_selling_price* p_batch_order.v_order_head (hi).orderlines(b).quantity)+ NVL(p_batch_order.v_order_head (hi).orderlines(b).tax_value,0);
            END LOOP;
          ELSE
            ln_total_amount:=p_batch_order.v_order_head (hi).prepaid_amount;--defect 3922
          END IF;
          dbms_output.put_line('ln_sum:'||ln_sum);
        END;
        BEGIN
          g_program_loc     := 'createOrderHeader';
          g_order_source_id := getordersourceid(p_batch_order.v_order_head (hi).order_source);
          xxcu_common_log_rt.msglog ('INFO', 'before Create Head ', 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
          v_orig_sys_document_ref := createorderhead_interface (p_batch_order.v_order_head (hi), p_batch_order.batchid, p_status_code, v_num_orderheads,ln_total_amount,p_error_message); --commented for E2-IM013089363 (defect 8035)
          v_headers_count         := v_headers_count + 1;
          --v_header_id             := getheader_id (p_batch_order.v_order_head (hi).ordereddate, p_batch_order.v_order_head (hi).customer_number, v_version_number);
          /* Defect#2848 Start change for Return order added org_id*/
          v_header_id := getheader_id ( p_batch_order.v_order_head (hi).customer_number,p_batch_order.v_order_head (hi).return_order_reference,p_batch_order.v_order_head (hi).org_id, v_version_number);
          /* Defect#2848 End change for Return order added org_id*/
          dbms_output.put_line('Header Id'||v_header_id);
          --COMMIT;
          --   xxcu_log_pkg.LOG (p_log_level => fnd_log.level_statement, p_module_name => gpackagename, p_log_text => ' - Order Lines Count: ' || p_batch_order.v_order_head(hi).orderlines.COUNT );
          dbms_output.put_line('B4 v_orderline_count');
          dbms_output.put_line('v_orderline_count' ||hi);                                           --p_batch_order.v_order_head(hi).orderlines.COUNT);
          v_orderline_count := v_orderline_count + p_batch_order.v_order_head (hi).orderlines.count;--p_batch_order.v_order_head(hi).orderlines.COUNT;
          --setting log attributes
          IF NVL(v_max_date,p_batch_order.v_order_head(hi).ordereddate-1 ) < p_batch_order.v_order_head(hi).ordereddate THEN
            v_max_date                                                    := p_batch_order.v_order_head(hi).ordereddate;
          END IF;
          IF NVL(v_min_date,p_batch_order.v_order_head(hi).ordereddate+1) > p_batch_order.v_order_head(hi).ordereddate THEN
            v_min_date                                                   := p_batch_order.v_order_head(hi).ordereddate;
          END IF;
          dbms_output.put_line('v_max_date:' || v_max_date);
          dbms_output.put_line('v_min_date:' || v_min_date);
          dbms_output.put_line('Hi1ines:' || p_batch_order.v_order_head(hi).orderlines.count);
          /* start CR artf5962829 */
          /* start defect 4677 */
          xxcu_common_log_rt.msglog ('INFO', 'p_batch_order.v_order_head (hi).lv_private_cust.count'||p_batch_order.v_order_head (hi).lv_private_cust.count, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
          FOR bjjj IN 1 .. p_batch_order.v_order_head (hi).lv_private_cust.count
          LOOP
            /* end defect 4677 */
            IF(p_batch_order.v_order_head (hi).lv_private_cust(bjjj).customer_reference IS NOT NULL AND p_batch_order.v_order_head (hi).customer_number IS NULL) THEN
              FOR cust_rec IN 1.. p_batch_order.v_order_head ( hi ) .lv_private_cust.count
              LOOP
                /* start CR 4609 */
                BEGIN
                  SELECT flv.description
                  INTO lv_orig_system
                  FROM applsys.fnd_lookup_values flv
                    /* start defect 4944 */
                    /* ,
                    --    oe_order_headers_all ooha,
                    oe_order_sources oos
                    */
                  WHERE flv.lookup_type     ='XXCU_CUSTOMER_ORDER_SOURCE'
                  AND upper(flv.lookup_code)=upper(p_batch_order.v_order_head (hi).order_source)
                  AND flv.language          ='US';
                  /* start defect 4944 */
                  /*AND oos.name          =p_batch_order.v_order_head (hi).order_source
                  -- AND ooha.org_id               =p_batch_order.v_order_head (hi).org_id
                  --  AND ooha.orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                  AND upper(oos.name) =upper(flv.lookup_code) ;*/
                EXCEPTION
                WHEN OTHERS THEN
                  xxcu_common_log_rt.msglog ('ERR', 'Error while deriving source system for private customer'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                END;
                --person type customer
                --   IF ( p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).first_name IS NOT NULL AND p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).last_name IS NOT NULL ) THEN
                --    BEGIN
                /*   INSERT
                INTO oe_customer_info_iface_all
                (
                created_by,
                creation_date,
                customer_info_ref,
                customer_info_type_code,
                customer_number,
                customer_type,
                last_update_date,
                last_updated_by,
                person_first_name,
                person_last_name,
                new_account_number
                )
                VALUES
                (
                g_user_id, -- created_by
                sysdate,   -- creation_date
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).customer_reference
                || '-'
                ||xxcu_oe_cust_ref.nextval,                                                                                       --Defect 4452
                'ACCOUNT',                                                                                                        -- customer_info_type_code
                NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number,xxdm_cust_acct_no_seq.nextval), -- customer_number
                'PERSON',                                                                                                         -- customer_type
                sysdate,                                                                                                          -- last_update_date
                g_user_id,                                                                                                        -- last_updated_by
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).first_name,
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).last_name,
                NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number,xxdm_cust_acct_no_seq.nextval)
                );
                */
                /* start CR 5144 */
                BEGIN
                  SELECT NVL(DECODE(upper(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).distribution_flag),'YES','Y','N'),'N')
                  INTO lv_distri_flag
                  FROM dual;
                EXCEPTION
                WHEN OTHERS THEN
                  lv_distri_flag:='N';
                END;
                /* end CR 5144 */
                IF( p_batch_order.v_order_head ( hi ). lv_private_cust(cust_rec).lv_addresslines.count=1 ) THEN--only bill to address is present in xml
                  FOR cust_addr IN 1 .. p_batch_order.v_order_head ( hi ). lv_private_cust(cust_rec).lv_addresslines.count
                  LOOP
                    BEGIN
                      /* start CR 5144 */
                      /* start CR 5113 */
                      /* xxcu_imc_private_cust_pkg.create_person_cust_bo( p_init_msg_list => fnd_api.g_false, p_validate_bo_flag => fnd_api.g_true, p_person_prenameadj=> NULL, p_person_first_name =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).first_name, p_person_mid_name =>NULL, p_person_last_name => p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).last_name, p_date_of_birth =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).date_of_birth, p_account_name => NULL, p_country_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country,                                                                                             -- country
                      p_address1 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address1, p_address2 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address2, p_address3 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address3, p_address4 =>NULL, p_city =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).city, p_postal_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).postal_code, p_county =>NULL, p_state =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country, -- country
                      p_province =>NULL, p_ship_address1 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address1, p_ship_address2 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address2, p_ship_address3 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address3, p_ship_address4 =>NULL, p_ship_city =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).city , p_ship_postal_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).postal_code, p_ship_country_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country , p_ship_county =>NULL, p_ship_state =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country , p_ship_province =>NULL, p_care_of =>NULL, p_behalf_of =>NULL, p_invoice_ref =>NULL, p_reserved_text =>NULL,
                      p_created_by_module =>NULL, p_source_system =>lv_orig_system, p_source_system_reference =>NULL, p_user_id =>NULL, p_phone_number =>NULL, p_far_bill =>NULL, p_far_ship =>NULL, p_distribution=>lv_distri_flag,p_org_id=>p_batch_order.v_order_head (hi).org_id,x_person_cust_obj_tbl=>x_person_cust_obj_tbl, x_return_status=>p_return_status , x_msg_count=>x_msg_count, x_msg_data=>p_msg_data, x_person_id=>p_person_id );
                      */
                      xxcu_create_svcs_pkg.create_person_cust_bo ( p_init_msg_list => fnd_api.g_false, p_validate_bo_flag => fnd_api.g_true, p_person_prenameadj=> NULL, p_person_first_name =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).first_name, p_person_mid_name =>NULL, p_person_last_name => p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).last_name, p_date_of_birth =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).date_of_birth, p_account_name => NULL, p_country_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country,                                                                                                 -- country
                      p_address1 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address1, p_address2 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address2, p_address3 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address3, p_address4 =>NULL, p_city =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).city, p_postal_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).postal_code, p_county =>NULL, p_state =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country, -- country
                      p_province =>NULL, p_ship_address1 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address1, p_ship_address2 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address2, p_ship_address3 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address3, p_ship_address4 =>NULL, p_ship_city =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).city , p_ship_postal_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).postal_code, p_ship_country_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country , p_ship_county =>NULL, p_ship_state =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country , p_ship_province =>NULL, p_care_of =>NULL, p_behalf_of =>NULL, p_invoice_ref =>NULL, p_reserved_text =>NULL,
                      p_created_by_module =>NULL, p_source_system =>lv_orig_system, p_source_system_reference =>NULL, p_user_id =>NULL, p_phone_number =>NULL, p_far_bill =>NULL, p_far_ship =>NULL, x_person_cust_obj_tbl=>x_person_cust_obj_tbl, x_return_status=>p_return_status , x_msg_count=>x_msg_count, x_msg_data=>p_msg_data, x_person_id=>p_person_id );
                      /* end CR 5113 */
                      /* end CR 5144 */
                      COMMIT;
                      xxcu_common_log_rt.msglog ('INFO', 'Customer creation status '||p_return_status||' ' ||p_person_id|| p_msg_data, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                    EXCEPTION
                    WHEN OTHERS THEN
                      xxcu_common_log_rt.msglog ('ERR', 'Error while creating customer 1'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                    END ;
                  END LOOP;
                  BEGIN
                    FOR i IN x_person_cust_obj_tbl.first.. x_person_cust_obj_tbl.last
                    LOOP
                      FOR j IN x_person_cust_obj_tbl(i).account_objs.first..x_person_cust_obj_tbl(i).account_objs.last
                      LOOP
                        xxcu_common_log_rt.msglog ('INFO', 'Account Number :'||x_person_cust_obj_tbl(i).account_objs(j).account_number, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                        lv_acct_number:=x_person_cust_obj_tbl(i).account_objs(j).account_number;
                      END LOOP;
                    END LOOP;
                  EXCEPTION
                  WHEN OTHERS THEN
                    lv_acct_number:=NULL;
                  END;
                ELSE
                  --bill to and ship to addresses are exactly same or different
                  -- FOR cust_addrr IN 1 .. p_batch_order.v_order_head ( hi ). lv_private_cust(cust_rec).lv_addresslines.count
                  -- LOOP
                  -- ln_k_count:=ln_k_count+1;
                  --   IF( ln_k_count                                                                                                                                                                                                                                                                                           <>p_batch_order.v_order_head(hi).lv_private_cust(cust_rec).lv_addresslines.count) THEN
                  --     IF(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addrr).address1                                                                                                                                                                                                        = p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addrr+1).address1 AND NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addrr).address2,'X') = NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addrr+1).address2,'X') AND NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addrr).address3,'X') = NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addrr+1).address3,'X') AND p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addrr).city = p_batch_order.v_order_head (hi)
                  -- .lv_private_cust(cust_rec).lv_addresslines(cust_addrr+1).city AND p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addrr).postal_code = p_batch_order.v_order_head (hi).lv_private_cust(cust_rec)
                  --      .lv_addresslines(cust_addrr                                                                                                                                                          +1) .postal_code AND p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addrr).country = p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addrr+1).country ) THEN
                  BEGIN
                    /* start CR 5144 */
                    /* CR 5113 */
                    /* xxcu_imc_private_cust_pkg.create_person_cust_bo ( p_init_msg_list => fnd_api.g_false, p_validate_bo_flag => fnd_api.g_true, p_person_prenameadj=> NULL, p_person_first_name =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).first_name, p_person_mid_name =>NULL, p_person_last_name => p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).last_name, p_date_of_birth =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).date_of_birth, p_account_name => NULL, p_country_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).country,                                                    -- country
                    p_address1 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).address1, p_address2 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).address2, p_address3 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).address3, p_address4 =>NULL, p_city =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).city, p_postal_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).postal_code, p_county =>NULL, p_state =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).country, -- country
                    p_province =>NULL, p_ship_address1 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).address1, p_ship_address2 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).address2, p_ship_address3 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).address3, p_ship_address4 =>NULL, p_ship_city =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).city , p_ship_postal_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).postal_code, p_ship_country_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).country , p_ship_county =>NULL, p_ship_state =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).country , p_ship_province =>NULL, p_care_of =>NULL, p_behalf_of =>NULL, p_invoice_ref =>NULL, p_reserved_text =>NULL, p_created_by_module =>NULL, p_source_system =>lv_orig_system,
                    p_source_system_reference =>NULL, p_user_id =>NULL, p_phone_number =>NULL, p_far_bill =>NULL, p_far_ship =>NULL, p_distribution=>lv_distri_flag,p_org_id=>p_batch_order.v_order_head (hi).org_id, x_person_cust_obj_tbl=>x_person_cust_obj_tbl, x_return_status=>p_return_status , x_msg_count=>x_msg_count, x_msg_data=>p_msg_data, x_person_id=>p_person_id );
                    */
                    xxcu_create_svcs_pkg.create_person_cust_bo ( p_init_msg_list => fnd_api.g_false, p_validate_bo_flag => fnd_api.g_true, p_person_prenameadj=> NULL, p_person_first_name =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).first_name, p_person_mid_name =>NULL, p_person_last_name => p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).last_name, p_date_of_birth =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).date_of_birth, p_account_name => NULL, p_country_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).country,                                                         -- country
                    p_address1 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).address1, p_address2 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).address2, p_address3 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).address3, p_address4 =>NULL, p_city =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).city, p_postal_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).postal_code, p_county =>NULL, p_state =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(1).country, -- country
                    p_province =>NULL, p_ship_address1 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).address1, p_ship_address2 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).address2, p_ship_address3 =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).address3, p_ship_address4 =>NULL, p_ship_city =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).city , p_ship_postal_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).postal_code, p_ship_country_code =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).country , p_ship_county =>NULL, p_ship_state =>p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(2).country , p_ship_province =>NULL, p_care_of =>NULL, p_behalf_of =>NULL, p_invoice_ref =>NULL, p_reserved_text =>NULL, p_created_by_module =>NULL, p_source_system =>lv_orig_system,
                    p_source_system_reference =>NULL, p_user_id =>NULL, p_phone_number =>NULL, p_far_bill =>NULL, p_far_ship =>NULL, x_person_cust_obj_tbl=>x_person_cust_obj_tbl, x_return_status=>p_return_status , x_msg_count=>x_msg_count, x_msg_data=>p_msg_data, x_person_id=>p_person_id );
                    /* end CR 5113 */
                    /* end CR 5144 */
                    COMMIT;
                    xxcu_common_log_rt.msglog ('INFO', 'Customer creation status '||p_return_status||' ' ||p_person_id|| p_msg_data, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                    BEGIN
                      FOR i IN x_person_cust_obj_tbl.first.. x_person_cust_obj_tbl.last
                      LOOP
                        FOR j IN x_person_cust_obj_tbl(i).account_objs.first..x_person_cust_obj_tbl(i).account_objs.last
                        LOOP
                          xxcu_common_log_rt.msglog ('INFO', 'Account Number :'||x_person_cust_obj_tbl(i).account_objs(j).account_number, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                          lv_acct_number:=x_person_cust_obj_tbl(i).account_objs(j).account_number;
                        END LOOP;
                      END LOOP;
                    EXCEPTION
                    WHEN OTHERS THEN
                      lv_acct_number:=NULL;
                    END;
                  EXCEPTION
                  WHEN OTHERS THEN
                    xxcu_common_log_rt.msglog ('ERR', 'Error while creating private customer 2'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  END;
                END IF;
                BEGIN
                  IF(lv_acct_number IS NULL) THEN
                    xxcu_common_log_rt.msglog ('INFO', 'p_person_id'||p_person_id, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                    SELECT cust_account_id,
                      object_version_number
                    INTO ln_sold_to_org,
                      p_object_version_number
                    FROM hz_cust_accounts
                    WHERE party_id=p_person_id;
                    xxcu_common_log_rt.msglog ('INFO', 'ln_sold_to_org'||ln_sold_to_org, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  ELSE
                    SELECT cust_account_id,
                      object_version_number
                    INTO ln_sold_to_org,
                      p_object_version_number
                    FROM hz_cust_accounts
                    WHERE account_number=lv_acct_number;
                  END IF;
                  -- xxcu_common_log_rt.msglog ('INFO', 'p_person_id'||p_person_id, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                EXCEPTION
                WHEN OTHERS THEN
                  xxcu_common_log_rt.msglog ('ERROR', 'Customer Creation failed '||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  /* start defect 5204*/
                  p_status_code  :=2;
                  p_error_message:='Customer Creation failed '||p_msg_data;
                  DELETE
                  FROM oe_headers_iface_all
                  WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                  AND org_id                 =p_batch_order.v_order_head (hi).org_id;
                  /* end defect 5204 */
                END;
                /* start CR 5026 */
                IF(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).far_number IS NOT NULL) THEN
                  mo_global.init ('AR');
                  SELECT responsibility_id,
                    application_id
                  INTO ln_resp_id,
                    ln_appl_id
                  FROM applsys.fnd_responsibility_tl
                  WHERE responsibility_name LIKE 'PB AR Super User'
                  AND language='US';
                  fnd_global.apps_initialize (user_id => g_user_id, resp_id => ln_resp_id, resp_appl_id => ln_appl_id );
                  mo_global.set_policy_context ('S', p_batch_order.v_order_head (hi).org_id);
                  BEGIN
                    SELECT object_version_number
                    INTO ln_object_version_number
                    FROM ar.hz_parties
                    WHERE party_id=p_person_id;
                  EXCEPTION
                  WHEN OTHERS THEN
                    fnd_file.put_line(fnd_file.output,'Invalid object version number');
                  END;
                  lv_party_rec.party_id        := p_person_id;
                  lv_party_rec.attribute9      := p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).far_number;
                  lv_person_rec_type.party_rec := lv_party_rec;
                  hz_party_v2pub.update_person (p_init_msg_list => fnd_api.g_true, p_person_rec => lv_person_rec_type, p_party_object_version_number => ln_object_version_number, x_profile_id => ln_profile_id, x_return_status =>lv_return_status, x_msg_count => ln_msg_count, x_msg_data => lv_msg_data );
                  --dbms_output.put_line ('API Status: ' || lv_return_status);
                  IF (lv_return_status <> 'S') THEN
                    xxcu_common_log_rt.msglog ('ERR', 'ERROR while updating attribute9 of hz_parties :' || lv_msg_data, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  ELSE
                    xxcu_common_log_rt.msglog ('INFO', 'Attribute9 is updated successfully.', 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  END IF;
                  COMMIT;
                END IF;
                /* end CR 5026 */
                IF(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number IS NOT NULL) THEN
                  mo_global.init ('AR');
                  SELECT responsibility_id,
                    application_id
                  INTO ln_resp_id,
                    ln_appl_id
                  FROM applsys.fnd_responsibility_tl
                  WHERE responsibility_name LIKE 'PB AR Super User'
                  AND language='US';
                  fnd_global.apps_initialize (user_id => g_user_id, resp_id => ln_resp_id, resp_appl_id => ln_appl_id );
                  mo_global.set_policy_context ('S', p_batch_order.v_order_head (hi).org_id);
                  p_cust_account_rec.cust_account_id := ln_sold_to_org;
                  p_cust_account_rec.account_number  := p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number;
                  hz_cust_account_v2pub.update_cust_account ( 'T' , p_cust_account_rec , p_object_version_number , x_return_status , x_msg_count , x_msg_data ) ;
                  COMMIT;
                END IF;
                IF(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).digi_id IS NOT NULL) THEN
                  lv_attr_group_name                                                 := 'DIGIPOST_ID';
                  l_change_info_table                                                := NULL;
                  --  l_attribute_Group_id   :=281;
                  lv_attribute_name :='ID';
                  --l_digipost_address     :=p_digi_id;
                  BEGIN
                    SELECT application_id,
                      attr_group_id
                    INTO ln_application_id,
                      ln_attribute_group_id
                    FROM ego_attr_groups_v
                    WHERE attr_group_type='HZ_PERSON_PROFILES_GROUP';
                  EXCEPTION
                  WHEN OTHERS THEN
                    xxcu_common_log_rt.msglog ('ERR', 'No data found for attr_group_type HZ_PERSON_PROFILES_GROUP'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  END;
                  /*values can be find from EGO_ATTR_GROUPS_V*/
                  l_attributes_row_table :=ego_user_attr_row_table( ego_user_attr_row_obj( 1 --ROW_IDENTIFIER
                  ,ln_attribute_group_id                                                     --ATTR_GROUP_ID
                  ,ln_application_id                                                         --ATTR_GROUP_APP_ID
                  ,lv_attr_group_type                                                        --ATTR_GROUP_TYPE
                  ,lv_attr_group_name ,NULL ,NULL                                            --DATA_LEVEL_1
                  ,NULL                                                                      --DATA_LEVEL_2
                  ,NULL ,NULL ,NULL ,ego_user_attrs_data_pvt.g_create_mode                   --TRANSACTION_TYPE
                  ) );
                  l_attributes_data_table := ego_user_attr_data_table( ego_user_attr_data_obj( 1--ROW_IDENTIFIER
                  ,lv_attribute_name                                                            --ATTR_NAME
                  ,p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).digi_id            --ATTR_VALUE_STR
                  ,NULL                                                                         --ATTR_VALUE_NUM (in the baseUOM,'FT')
                  ,NULL                                                                         --ATTR_VALUE_DATE
                  ,NULL                                                                         --ATTR_DISP_VALUE
                  ,NULL                                                                         --ATTR_UNIT_OF_MEASURE (display this value in'CM')
                  ,1                                                                            --USER_ROW_IDENTIFIER
                  ) );
                  BEGIN
                    SELECT hpp.person_profile_id,
                      hca.party_id
                    INTO ln_person_profile_id,
                      ln_party_id
                    FROM hz_person_profiles hpp,
                      -- oe_order_headers_all ooha,
                      hz_cust_accounts hca
                    WHERE hpp.party_id =hca.party_id
                      --  AND ooha.orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                    AND hca.cust_account_id=ln_sold_to_org;
                  EXCEPTION
                  WHEN OTHERS THEN
                    xxcu_common_log_rt.msglog ('ERR', 'No data found for person profile id'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  END;
                  hz_extensibility_pub.process_person_record ( p_api_version => 1.0 , p_person_profile_id => ln_person_profile_id , p_attributes_row_table => l_attributes_row_table , p_attributes_data_table => l_attributes_data_table , p_change_info_table => l_change_info_table , p_entity_id => 1 , p_entity_index => 1 , p_entity_code => NULL , p_debug_level => 3 , p_init_error_handler => fnd_api.g_true , p_write_to_concurrent_log => fnd_api.g_false , p_init_fnd_msg_list => fnd_api.g_false , p_log_errors => fnd_api.g_true , p_add_errors_to_fnd_stack => fnd_api.g_false , p_commit => fnd_api.g_false ,x_failed_row_id_list => lv_failed_row_id_list ,x_return_status => lv_return_status ,x_errorcode => ln_errorcode ,x_msg_count => ln_msg_count ,x_msg_data => lv_msg_data );
                  SELECT extension_id
                  INTO ln_extension_id
                  FROM hz_per_profiles_ext_b
                  WHERE person_profile_id=ln_person_profile_id;
                  --  fnd_file.put_line(fnd_file.output,'Extension Id:'||SUBSTR(ln_extension_id,1,254));
                  -- xxcu_common_log_rt.msglog ('INFO', 'x_return_status '||SQLERRM, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  -- xxcu_common_log_rt.msglog ('INFO', 'l_msg_data '||SUBSTR(l_msg_data,1,254), 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  -- xxcu_common_log_rt.msglog ('INFO', 'Extension id: '||SUBSTR(L_EXTENSION_ID,1,254), 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  IF (LENGTH(lv_failed_row_id_list) > 0) THEN
                    fnd_file.put_line(fnd_file.output,'List of rows that failed: '||lv_failed_row_id_list);
                    -- xxcu_common_log_rt.msglog ('INFO', 'List of rows that failed: '||l_failed_row_id_list, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                    DECLARE
                      lv_errors_tbl error_handler.error_tbl_type;
                    BEGIN
                      error_handler.get_message_list(lv_errors_tbl);
                      FOR i IN 1..lv_errors_tbl.count
                      LOOP
                        xxcu_common_log_rt.msglog ('ERR', 'Message:'||SUBSTR(lv_errors_tbl(i).message_text,1,254), 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                        --   fnd_file.put_line(fnd_file.output,'Message: '||SUBSTR(lv_errors_tbl(i).message_text,1,254));
                        --   fnd_file.put_line(fnd_file.output,'Msg Type: '||SUBSTR(lv_errors_tbl(i).message_type,1,254));
                        --  xxcu_common_log_rt.msglog ('INFO', 'Message: '||SUBSTR(l_errors_tbl(i).message_text,1,254), 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                        --  xxcu_common_log_rt.msglog ('INFO', 'Msg Type: '||SUBSTR(l_errors_tbl(i).message_type,1,254), 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                      END LOOP;
                    END;
                  END IF;
                END IF;
                -- END If;
                -- END LOOP;
                /* start defect 4783 */
                BEGIN
                  BEGIN
                    SELECT flv.profile_option_value
                    INTO lv_term_name
                    FROM fnd_profile_options_vl fpov,
                      applsys.fnd_profile_option_values flv
                    WHERE fpov.profile_option_name='XXCU_DEFAULT_PAYMET_TERM'
                    AND flv.profile_option_id     =fpov.profile_option_id;
                  EXCEPTION
                  WHEN OTHERS THEN
                    xxcu_common_log_rt.msglog ('ERR', 'Error in profile option PB Default Payment Term for Private Customers'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  END;
                  BEGIN
                    SELECT term_id INTO ln_term FROM ra_terms WHERE name=lv_term_name;
                  EXCEPTION
                  WHEN OTHERS THEN
                    xxcu_common_log_rt.msglog ('ERR', 'Error while deriving paymet term for private customer'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  END;
                  /* end defect 4783 */
                  UPDATE oe_headers_iface_all
                  SET payment_term_id        =ln_term,--'10 days',--defect 4783
                    sold_to_org_id           =ln_sold_to_org
                  WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                  AND org_id                 =p_batch_order.v_order_head (hi).org_id;
                  COMMIT;
                EXCEPTION
                WHEN OTHERS THEN
                  xxcu_common_log_rt.msglog ('ERR', 'Error while updating order header'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                END;
                /*  FOR bjk IN 1 .. p_batch_order.v_order_head (hi).orderlines.count
                LOOP
                -- dbms_output.put_line(SIGN(p_batch_order.v_order_head (hi).orderlines(p).quantity));
                UPDATE oe_lines_iface_all
                SET payment_term_id           =ln_term,--'10 days'--defect 4783
                WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                AND org_id                 =p_batch_order.v_order_head (hi).org_id;
                COMMIT;
                END LOOP;
                */
                /*  EXCEPTION
                WHEN OTHERS THEN
                xxcu_common_log_rt.msglog ('INFO', 'Error in insert of customer '||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                END;
                */
                /*   ELSE
                BEGIN
                INSERT
                INTO oe_customer_info_iface_all
                (
                created_by,
                creation_date,
                customer_info_ref,
                customer_info_type_code,
                customer_number,
                customer_type,
                last_update_date,
                last_updated_by,
                organization_name,
                new_account_number
                )
                VALUES
                (
                g_user_id, -- created_by
                sysdate,   -- creation_date
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).customer_reference
                ||'-'
                ||xxcu_oe_cust_ref.nextval,                                                                                       --Defect 4452
                'ACCOUNT',                                                                                                        -- customer_info_type_code
                NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number,xxdm_cust_acct_no_seq.nextval), -- customer_number
                'ORGANIZATION',                                                                                                   -- customer_type
                sysdate,                                                                                                          -- last_update_date
                g_user_id,                                                                                                        -- last_updated_by
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).customer_reference
                ||'-'
                ||xxcu_oe_cust_ref.currval, --'IL CUST ACT 06', -- customer_info_ref
                NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number,xxdm_cust_acct_no_seq.nextval)
                );
                UPDATE oe_headers_iface_all
                SET orig_sys_customer_ref =p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).customer_reference
                || '-'
                ||xxcu_oe_cust_ref.currval,--Defect 4452
                payment_term             ='10 days'
                WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                AND org_id                 =p_batch_order.v_order_head (hi).org_id;
                COMMIT;
                EXCEPTION
                WHEN OTHERS THEN
                xxcu_common_log_rt.msglog ('INFO', 'Error in insert of customer '||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                END;
                FOR bjk IN 1 .. p_batch_order.v_order_head (hi).orderlines.count
                LOOP
                -- dbms_output.put_line(SIGN(p_batch_order.v_order_head (hi).orderlines(p).quantity));
                UPDATE oe_lines_iface_all
                SET payment_term           ='10 days'
                WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                AND org_id                 =p_batch_order.v_order_head (hi).org_id;
                COMMIT;
                END LOOP;
                END IF;
                xxcu_common_log_rt.msglog ('INFO', 'p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines.count '||p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines.count, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                /* start defect 4534 */
                /*     IF( p_batch_order.v_order_head ( hi ). lv_private_cust(cust_rec).lv_addresslines.count=1 ) THEN
                FOR cust_addr IN 1 .. p_batch_order.v_order_head ( hi ). lv_private_cust(cust_rec).lv_addresslines.count
                LOOP
                INSERT
                INTO oe_customer_info_iface_all
                (
                address1,
                address2,
                address3,
                --ADDRESS4,
                city,
                country,
                created_by,
                creation_date,
                customer_info_ref,
                customer_info_type_code,
                is_bill_to_address,
                is_ship_to_address,
                last_update_date,
                last_updated_by,
                parent_customer_ref,
                postal_code,
                state
                --location_number
                )
                VALUES
                (
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address1, -- address1
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address2, -- address2
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address3, -- address3
                --'NO 941031', -- address4
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).city,    -- city
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country, -- country
                g_user_id,                                                                                    -- created_by
                sysdate,                                                                                      -- creation_date
                NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number,xxdm_cust_acct_no_seq.currval)
                ||xxcu_oe_bill_ref.nextval, --||'_'||ln_k_count, -- customer_info_ref
                'ADDRESS',                  -- customer_info_type_code
                'Y',                        -- is_bill_to_address
                'Y',                        -- is_ship_to_address
                sysdate,                    -- last_update_date
                g_user_id,                  -- last_updated_by
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).customer_reference
                ||'-'
                ||xxcu_oe_cust_ref.currval,                                                                       --Defect 4452                    --'IL CUST ACT 06', -- parent_customer_ref
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).postal_code, -- postal_code
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country
                --'76567'-- state
                );
                UPDATE oe_headers_iface_all
                SET orig_bill_address_ref=NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number,xxdm_cust_acct_no_seq.currval)
                ||xxcu_oe_bill_ref.currval--||'_'||ln_k_count
                WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                AND org_id                 =p_batch_order.v_order_head (hi).org_id;
                COMMIT;
                END LOOP;
                ELSE
                /* end defect 4534 */
                /*   FOR cust_addr IN 1 .. p_batch_order.v_order_head ( hi ). lv_private_cust(cust_rec).lv_addresslines.count
                LOOP
                ln_k_count:=ln_k_count+1;
                BEGIN
                IF( ln_k_count                                                                                                                                                                                                                                                                                           <>p_batch_order.v_order_head(hi).lv_private_cust(cust_rec).lv_addresslines.count) THEN
                IF(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address1                                                                                                                                                                                                        = p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr+1).address1 AND NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address2,'X') = NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr+1).address2,'X') AND NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address3,'X') = NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr+1).address3,'X') AND p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).city = p_batch_order.v_order_head (hi).lv_private_cust(cust_rec)
                .lv_addresslines(cust_addr+1).city AND p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).postal_code = p_batch_order.v_order_head (hi).lv_private_cust(cust_rec)
                .lv_addresslines(cust_addr                                                                                                                                                          +1) .postal_code AND p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country = p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr+1).country ) THEN
                INSERT
                INTO oe_customer_info_iface_all
                (
                address1,
                address2,
                address3,
                --ADDRESS4,
                city,
                country,
                created_by,
                creation_date,
                customer_info_ref,
                customer_info_type_code,
                is_bill_to_address,
                is_ship_to_address,
                last_update_date,
                last_updated_by,
                parent_customer_ref,
                postal_code,
                state
                --location_number
                )
                VALUES
                (
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address1, -- address1
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address2, -- address2
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address3, -- address3
                --'NO 941031', -- address4
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).city,    -- city
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country, -- country
                g_user_id,                                                                                    -- created_by
                sysdate,                                                                                      -- creation_date
                NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number,xxdm_cust_acct_no_seq.currval)
                ||xxcu_oe_bill_ref.nextval, --||'_'||ln_k_count, -- customer_info_ref
                'ADDRESS',                  -- customer_info_type_code
                'Y',                        -- is_bill_to_address
                'Y',                        -- is_ship_to_address
                sysdate,                    -- last_update_date
                g_user_id,                  -- last_updated_by
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).customer_reference
                ||'-'
                ||xxcu_oe_cust_ref.currval,                                                                       --Defect 4452                    --'IL CUST ACT 06', -- parent_customer_ref
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).postal_code, -- postal_code
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country
                --'76567'-- state
                );
                UPDATE oe_headers_iface_all
                SET orig_bill_address_ref=NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number,xxdm_cust_acct_no_seq.currval)
                ||xxcu_oe_bill_ref.currval--||'_'||ln_k_count
                WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                AND org_id                 =p_batch_order.v_order_head (hi).org_id;
                COMMIT;
                lv_is_bill:='TRUE';
                ELSE
                INSERT
                INTO oe_customer_info_iface_all
                (
                address1,
                address2,
                address3,
                --ADDRESS4,
                city,
                country,
                created_by,
                creation_date,
                customer_info_ref,
                customer_info_type_code,
                is_bill_to_address,
                is_ship_to_address,
                last_update_date,
                last_updated_by,
                parent_customer_ref,
                postal_code,
                state
                --,
                --location_number
                )
                VALUES
                (
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address1, -- address1
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address2, -- address2
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address3, -- address3
                --'NO 941031', -- address4
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).city,    -- city
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country, -- country
                g_user_id,                                                                                    -- created_by
                sysdate,                                                                                      -- creation_date
                NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number,xxdm_cust_acct_no_seq.currval)
                ||xxcu_oe_bill_ref.nextval,                                                                                                       --||'_'||ln_k_count+1, -- customer_info_ref
                'ADDRESS',                                                                                                                        -- customer_info_type_code
                DECODE(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).addr_type,'BillingAddress','Y','N'),  -- is_bill_to_address
                DECODE(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).addr_type,'ShippingAddress','Y','N'), -- is_ship_to_address
                sysdate,                                                                                                                          -- last_update_date
                g_user_id,                                                                                                                        -- last_updated_by
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).customer_reference
                ||'-'
                ||xxcu_oe_cust_ref.currval,                                                                       --Defect 4452                                                    --'IL CUST ACT 06', -- parent_customer_ref
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).postal_code, -- postal_code
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country
                --'76567'-- state
                );
                END IF;
                ELSE
                IF(lv_is_bill<>'TRUE') THEN
                INSERT
                INTO oe_customer_info_iface_all
                (
                address1,
                address2,
                address3,
                --ADDRESS4,
                city,
                country,
                created_by,
                creation_date,
                customer_info_ref,
                customer_info_type_code,
                is_bill_to_address,
                is_ship_to_address,
                last_update_date,
                last_updated_by,
                parent_customer_ref,
                postal_code,
                state
                --,
                --location_number
                )
                VALUES
                (
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address1, -- address1
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address2, -- address2
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).address3, -- address3
                --'NO 941031', -- address4
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).city,    -- city
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country, -- country
                g_user_id,                                                                                    -- created_by
                sysdate,                                                                                      -- creation_date
                NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number,xxdm_cust_acct_no_seq.currval)
                ||xxcu_oe_bill_ref.nextval,
                'ADDRESS',                                                                                                                        -- customer_info_type_code
                DECODE(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).addr_type,'BillingAddress','Y','N'),  -- is_bill_to_address
                DECODE(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).addr_type,'ShippingAddress','Y','N'), -- is_ship_to_address
                sysdate,                                                                                                                          -- last_update_date
                g_user_id,                                                                                                                        -- last_updated_by
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).customer_reference
                ||'-'
                ||xxcu_oe_cust_ref.currval,                                                                       --'IL CUST ACT 06', -- parent_customer_ref
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).postal_code, -- postal_code
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).country
                --'76567'-- state
                );
                END IF;
                END IF;
                IF(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).lv_addresslines(cust_addr).addr_type='BillingAddress') THEN
                UPDATE oe_headers_iface_all
                SET orig_bill_address_ref=NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number,xxdm_cust_acct_no_seq.currval)
                ||xxcu_oe_bill_ref.currval
                WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                AND org_id                 =p_batch_order.v_order_head (hi).org_id;
                COMMIT;
                ELSE
                UPDATE oe_headers_iface_all
                SET orig_ship_address_ref=NVL(p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).private_cust_number,xxdm_cust_acct_no_seq.currval)
                ||xxcu_oe_bill_ref.currval
                WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                AND org_id                 =p_batch_order.v_order_head (hi).org_id;
                COMMIT;
                END IF;
                --end if;
                COMMIT;
                EXCEPTION
                WHEN OTHERS THEN
                xxcu_common_log_rt.msglog ('INFO', 'Error in insert of address '||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                END;
                END LOOP;
                */
                /*
                ln_k_count:=0;
                lv_is_bill:='FALSE';
                */
                --END IF;
                /*  BEGIN
                SELECT COUNT(*)
                INTO lv_cust_count
                FROM xxcu_oe_digi_id_data_t
                WHERE order_reference=p_batch_order.v_order_head (hi).order_reference
                AND org_id           =p_batch_order.v_order_head (hi).org_id
                AND process_flag    IS NULL;
                EXCEPTION
                WHEN OTHERS THEN
                lv_cust_count:=0;
                END;
                IF(lv_cust_count=0) THEN
                BEGIN
                INSERT
                INTO xxcu_oe_digi_id_data_t
                (
                oe_digi_id,
                order_reference ,
                org_id,
                digi_id,
                process_flag,
                creation_date ,
                created_by ,
                last_update_date ,
                last_updated_by
                )
                VALUES
                (
                xxcu_oe_digi_id_s.nextval,
                p_batch_order.v_order_head (hi).order_reference,
                p_batch_order.v_order_head (hi).org_id,
                p_batch_order.v_order_head (hi).lv_private_cust(cust_rec).digi_id,
                NULL,
                sysdate,
                g_user_id,
                sysdate,
                g_user_id
                );
                COMMIT;
                EXCEPTION
                WHEN OTHERS THEN
                xxcu_common_log_rt.msglog ('ERR', 'Error while inserting into xxcu_oe_digi_id_data_t '||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                END;
                END IF;
                */
              END LOOP;
            END IF;
          END LOOP;
          /* end artf5962829 */
          /* end CR 4609 */
          /* lines insertion loop starts */
          FOR li IN 1 .. p_batch_order.v_order_head ( hi ) .orderlines.count
          LOOP
            /* start wave 2 modification artf5860509 */
            BEGIN
              SELECT COUNT(tax_rate_code)
              INTO ln_tax
              FROM zx_rates_b
              WHERE tax_rate_code=p_batch_order.v_order_head (hi).orderlines (li).tax_code
              AND effective_to  IS NULL
              AND active_flag    ='Y';
            EXCEPTION
            WHEN OTHERS THEN
              ln_tax:=0;
            END;
            IF(ln_tax=0) THEN
              BEGIN
                SELECT tag
                INTO lv_tax
                FROM fnd_lookup_values_vl
                WHERE lookup_type    ='PB_TAX_CODE_MAPPING'
                AND lookup_code      =p_batch_order.v_order_head (hi).orderlines (li).tax_code
                AND end_date_active IS NULL
                AND enabled_flag     ='Y';
              EXCEPTION
              WHEN OTHERS THEN
                /*  xxcu_common_log_rt.msglog ('ERR', 'Error deriving tax code'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                p_status_code  := 2;
                p_error_message:='Error deriving tax code'||sqlerrm||dbms_utility.format_error_backtrace;
                */
                lv_tax:=NULL;
              END;
            ELSE
              lv_tax:=p_batch_order.v_order_head (hi).orderlines (li).tax_code;
            END IF;
            /* end wave 2 modification */
            --   lv_tax:=p_batch_order.v_order_head (hi).orderlines (li).tax_code;
            -- msgtext := 'Tax Code in main: ' || lv_tax ;
            g_intf_inv_spec_seq := NULL; -- Added by Divyansh for Incident#E2-IM013492120
            --   xxcu_common_log_rt.msglog ('ERR', 'Tax Code in main: ' || p_batch_order.v_order_head (hi).orderlines.COUNT, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => SYSDATE, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
            BEGIN
              dbms_output.put_line('calling lines');
              g_program_loc := 'getline_id_source_exists';
              --IF NOT getline_id_source_exists (p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource, 'LM') THEN
              g_program_loc := 'createOrderlineAggregate';
              --Creates orderlines
              v_status_function := g_code_ok;
              --    v_orderline_count := v_orderline_count + createorderline (p_batch_order.v_order_head (hi).orderlines, v_header_id, v_status_function);
              /* version  1.17 Defect # 797 */
              BEGIN
                SELECT gso.currency_code
                INTO lv_curr_code
                FROM hr_operating_units hou,
                  gl_sets_of_books gso
                WHERE gso.set_of_books_id=hou.set_of_books_id
                AND hou.organization_id  =p_batch_order.v_order_head (hi).org_id;
              EXCEPTION
              WHEN OTHERS THEN
                lv_curr_code:=NULL;
              END;
              IF (upper(p_batch_order.v_order_head (hi).order_type)='RETURN' AND lv_curr_code<>NVL(get_currencycode(getcustomer_id (p_batch_order.v_order_head (hi).customer_number),p_batch_order.v_order_head (hi).org_id),p_batch_order.v_order_head (hi).currency_code) AND p_batch_order.v_order_head (hi).payment_provider_trans_id IS NULL) THEN
                BEGIN
                  SELECT pricing_date
                  INTO lv_price_date
                  FROM oe_order_headers_all
                  WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).return_order_reference
                  AND org_id                 = p_batch_order.v_order_head (hi).org_id; --added org_id defect#2848
                  /* start defect 3446 */
                EXCEPTION
                WHEN OTHERS THEN
                  lv_price_date:=NULL;
                END;
                /* end defect 3446 */
              ELSE
                lv_price_date:=p_batch_order.v_order_head (hi).pricing_date;
              END IF;
              /* call line insertion procedure */
              /*Version added New new parameter of header  Kavita 1.30 CR#2499*/
              SELECT xxcu_intf_spec_inv_s.nextval
              INTO g_intf_inv_spec_seq
              FROM dual; ---- Added by Divyansh for Incident#E2-IM013492120
              /* start wave 2 modification */
              IF(p_batch_order.v_order_head (hi).order_source='NO002_RB' AND upper(p_batch_order.v_order_head (hi).order_type)='RETURN') THEN
                create_rettbetalt_lines(p_batch_order.v_order_head (hi),p_batch_order.v_order_head (hi).orderlines (li),lv_price_date,p_status_code,p_error_message);
              ELSE
                createorderline_interface (p_batch_order.v_order_head (hi),p_batch_order.v_order_head (hi).orderlines (li), v_header_id, p_batch_order.v_order_head (hi).order_reference,                                              -- v_orig_sys_document_ref, --changed on Snehal for 8035
                p_batch_order.v_order_head (hi).currency_code,p_batch_order.v_order_head (hi).sales_agmnt_no,getcustomer_id (p_batch_order.v_order_head (hi).customer_number),p_status_code, v_num_orderlines, v_upd_orig_sys_line_ref --1161
                ,p_batch_order.v_order_head (hi).org_id,lv_price_date,p_batch_order.v_order_head (hi).order_type,p_error_message);
              END IF;
              --  COMMIT;
              ----Start for defect#2959
              -- dbms_lock.sleep(5);
              IF NVL(p_batch_order.v_order_head (hi).orderlines(li).order_line_spec_hdr_cnt,0)>0
                /* start CR 2811 */
                /* start CR 4089 */
                --  AND upper(p_batch_order.v_order_head (hi).order_type)<>'RETURN'
                /* end */
                /* end */
                THEN
                BEGIN
                  /* start defect 4310 */
                  IF( p_batch_order.v_order_head (hi).orderlines (li).date_from            IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).date_to IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).description IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).order_date IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).uom IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).waybill_number IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).sender_name IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).receiver_name IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_from IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).spec_ship_to IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).number_of_packages IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).pallet IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).volume IS NOT NULL OR
                    p_batch_order.v_order_head (hi).orderlines (li).weight                 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).freight_calc_weight IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).responsible_person IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).pp_price IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).cargo_type IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).container_reference IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).pick_up_point IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).awb IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).mawb IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).hawb IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).vessel IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).incoterm IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).sender_reference IS NOT NULL OR
                    p_batch_order.v_order_head (hi).orderlines (li).receiver_reference     IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).agent_reference IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).load_carrier IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).transport_method IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).delivery_point IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).our_reference IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).cargo_id_number IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).position_number IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).load_meter IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).cargo_label IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).charteque_number IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).delivered_time IS NOT NULL OR p_batch_order.v_order_head (hi)
                    .orderlines (li).received_time                                         IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_from_address1 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_from_address2 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_from_address3 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_from_country IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_from_postal_code IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_to_address1 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_to_address2 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_to_address3 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_to_postal_code IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_to_country IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).volume_uom IS NOT NULL OR
                    p_batch_order.v_order_head (hi).orderlines (li).weight_uom             IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).freight_calc_weight_uom IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).currency IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).currency_amount IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).exchange_rate IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).exchange_date IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).pick_up_address1 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).pick_up_address2 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).pick_up_address3 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).pick_up_postal_code IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).pick_up_city IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).pick_up_country IS NOT NULL OR p_batch_order.v_order_head
                    (hi).orderlines (li).delivery_address1                                 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).delivery_address2 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).delivery_address3 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).delivery_postal_code IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).delivery_city IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).delivery_country IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).consignment_type_code IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).consignment_type_text IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).transport_method_text IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).incoterm_text IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_to_fiscal_code IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ship_from_fiscal_code IS NOT
                    NULL OR to_clob( p_batch_order.v_order_head (hi).orderlines (li).note) IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).loading_point IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).unloading_point IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ordered_by IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ordered_by_addr1 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ordered_by_addr2 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ordered_by_addr3 IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ordered_by_postal IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ordered_by_city IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ordered_by_country IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ordered_by_contact IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ordered_by_con_email IS NOT NULL OR
                    p_batch_order.v_order_head (hi).orderlines (li).bill_to_con_person     IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).bill_to_con_email IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).deviation IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).franking_type IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).price_table IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).speed IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).destination IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).weight_spec IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).unit_price_inc_vat IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).total_inc_vat IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).paid_amount IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).agreement_sum IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li)
                    .shipment_id_number                                                    IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).unit_price_excl_vat IS NOT NULL ) THEN
                    /* end defect 4310 */
                    INSERT
                    INTO xxcu_interface_specifications VALUES
                      (
                        -- XXCU.XXCU_INTF_INVOICE_SPEC_S.nextval, --commented 1.30 Kavita
                        'N',
                        p_batch_order.v_order_head (hi).order_source,
                        p_batch_order.v_order_head (hi).order_reference,
                        p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource, -- lv_line_number,
                        p_batch_order.v_order_head (hi).orderlines (li).date_from,
                        p_batch_order.v_order_head (hi).orderlines (li).date_to,
                        p_batch_order.v_order_head (hi).orderlines (li).description,
                        p_batch_order.v_order_head (hi).orderlines (li).order_date,
                        p_batch_order.v_order_head (hi).orderlines (li).uom,
                        /* version 1.27 CR 2468 */
                        -- p_batch_order.v_order_head (rec_head).orderlines (rec_line).PER_TIME_UNIT,
                        -- p_batch_order.v_order_head (rec_head).orderlines (rec_line).UNIT_PRICE,
                        --p_batch_order.v_order_head (rec_head).orderlines (rec_line).AMOUNT,
                        -----------------------------------------------------
                        p_batch_order.v_order_head (hi).orderlines (li).waybill_number,
                        p_batch_order.v_order_head (hi).orderlines (li).sender_name,
                        p_batch_order.v_order_head (hi).orderlines (li).receiver_name,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_from,
                        p_batch_order.v_order_head (hi).orderlines (li).spec_ship_to,
                        p_batch_order.v_order_head (hi).orderlines (li).number_of_packages,
                        p_batch_order.v_order_head (hi).orderlines (li).pallet,
                        p_batch_order.v_order_head (hi).orderlines (li).volume,
                        p_batch_order.v_order_head (hi).orderlines (li).weight,
                        p_batch_order.v_order_head (hi).orderlines (li).freight_calc_weight,
                        p_batch_order.v_order_head (hi).orderlines (li).responsible_person,
                        p_batch_order.v_order_head (hi).orderlines (li).pp_price,
                        p_batch_order.v_order_head (hi).orderlines (li).cargo_type,
                        sysdate,
                        g_user_id,
                        g_user_id,
                        sysdate,
                        /* version 1.24 CR 1929 */
                        p_batch_order.v_order_head (hi).orderlines (li).container_reference,
                        p_batch_order.v_order_head (hi).orderlines (li).pick_up_point ,
                        p_batch_order.v_order_head (hi).orderlines (li).awb ,
                        p_batch_order.v_order_head (hi).orderlines (li).mawb ,
                        p_batch_order.v_order_head (hi).orderlines (li).hawb ,
                        p_batch_order.v_order_head (hi).orderlines (li).vessel ,
                        p_batch_order.v_order_head (hi).orderlines (li).incoterm ,
                        p_batch_order.v_order_head (hi).orderlines (li).sender_reference ,
                        p_batch_order.v_order_head (hi).orderlines (li).receiver_reference,
                        p_batch_order.v_order_head (hi).orderlines (li).agent_reference ,
                        p_batch_order.v_order_head (hi).orderlines (li).load_carrier ,
                        p_batch_order.v_order_head (hi).orderlines (li).transport_method ,
                        p_batch_order.v_order_head (hi).orderlines (li).delivery_point ,
                        p_batch_order.v_order_head (hi).orderlines (li).our_reference ,
                        p_batch_order.v_order_head (hi).orderlines (li).cargo_id_number ,
                        p_batch_order.v_order_head (hi).orderlines (li).position_number ,
                        p_batch_order.v_order_head (hi).orderlines (li).load_meter ,
                        p_batch_order.v_order_head (hi).orderlines (li).cargo_label,
                        p_batch_order.v_order_head (hi).orderlines (li).charteque_number ,
                        p_batch_order.v_order_head (hi).orderlines (li).delivered_time ,
                        p_batch_order.v_order_head (hi).orderlines (li).received_time ,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_from_address1 ,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_from_address2 ,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_from_address3,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_from_country ,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_from_postal_code ,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_to_address1 ,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_to_address2,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_to_address3 ,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_to_postal_code ,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_to_country,
                        -----------------------------------------------------------------------------------------------------------------------------------
                        /* version 1.27 CR 2468 */
                        p_batch_order.v_order_head (hi).orderlines (li).volume_uom,
                        p_batch_order.v_order_head (hi).orderlines (li).weight_uom,
                        p_batch_order.v_order_head (hi).orderlines (li).freight_calc_weight_uom,
                        /* Start 1.30 Kavita CR 2499 */
                        /* Start Defect 3218 */
                        NVL(p_batch_order.v_order_head (hi).printed_order_number,g_order_number),
                        /* end defect 3218 */
                        -- g_order_number
                        /* END 1.30 Kavita CR 2499 */
                        /* start 1.38 CR 3006 */
                        p_batch_order.v_order_head (hi).orderlines (li).currency,
                        p_batch_order.v_order_head (hi).orderlines (li).currency_amount,
                        p_batch_order.v_order_head (hi).orderlines (li).exchange_rate,
                        p_batch_order.v_order_head (hi).orderlines (li).exchange_date,
                        /* end 1.38 CR 3006 */
                        /* start CR 3118 */
                        p_batch_order.v_order_head (hi).orderlines (li).pick_up_address1,
                        p_batch_order.v_order_head (hi).orderlines (li).pick_up_address2,
                        p_batch_order.v_order_head (hi).orderlines (li).pick_up_address3,
                        p_batch_order.v_order_head (hi).orderlines (li).pick_up_postal_code ,
                        p_batch_order.v_order_head (hi).orderlines (li).pick_up_city ,
                        p_batch_order.v_order_head (hi).orderlines (li).pick_up_country ,
                        p_batch_order.v_order_head (hi).orderlines (li).delivery_address1 ,
                        p_batch_order.v_order_head (hi).orderlines (li).delivery_address2 ,
                        p_batch_order.v_order_head (hi).orderlines (li).delivery_address3 ,
                        p_batch_order.v_order_head (hi).orderlines (li).delivery_postal_code,
                        p_batch_order.v_order_head (hi).orderlines (li).delivery_city ,
                        p_batch_order.v_order_head (hi).orderlines (li).delivery_country ,
                        p_batch_order.v_order_head (hi).orderlines (li).consignment_type_code ,
                        p_batch_order.v_order_head (hi).orderlines (li).consignment_type_text,
                        p_batch_order.v_order_head (hi).orderlines (li).transport_method_text,
                        p_batch_order.v_order_head (hi).orderlines (li).incoterm_text ,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_to_fiscal_code ,
                        p_batch_order.v_order_head (hi).orderlines (li).ship_from_fiscal_code,
                        to_clob( p_batch_order.v_order_head (hi).orderlines (li).note),
                        /* start CR 3374 */
                        p_batch_order.v_order_head (hi).orderlines (li).loading_point ,
                        p_batch_order.v_order_head (hi).orderlines (li).unloading_point,
                        /* end CR 3374 */
                        /* end CR 3118 */
                        g_intf_inv_spec_seq, ---- Added by Divyansh for Incident#E2-IM013492120
                        /* start wave 2 modification */
                        p_batch_order.v_order_head (hi).orderlines (li).ordered_by,
                        p_batch_order.v_order_head (hi).orderlines (li).ordered_by_addr1,
                        p_batch_order.v_order_head (hi).orderlines (li).ordered_by_addr2,
                        p_batch_order.v_order_head (hi).orderlines (li).ordered_by_addr3,
                        p_batch_order.v_order_head (hi).orderlines (li).ordered_by_postal,
                        p_batch_order.v_order_head (hi).orderlines (li).ordered_by_city,
                        p_batch_order.v_order_head (hi).orderlines (li).ordered_by_country,
                        p_batch_order.v_order_head (hi).orderlines (li).ordered_by_contact,
                        p_batch_order.v_order_head (hi).orderlines (li).ordered_by_con_email,
                        p_batch_order.v_order_head (hi).orderlines (li).bill_to_con_person,
                        p_batch_order.v_order_head (hi).orderlines (li).bill_to_con_email,
                        p_batch_order.v_order_head (hi).orderlines (li).deviation,
                        p_batch_order.v_order_head (hi).orderlines (li).franking_type,
                        p_batch_order.v_order_head (hi).orderlines (li).price_table,
                        p_batch_order.v_order_head (hi).orderlines (li).speed,
                        p_batch_order.v_order_head (hi).orderlines (li).destination,
                        p_batch_order.v_order_head (hi).orderlines (li).weight_spec,
                        p_batch_order.v_order_head (hi).orderlines (li).unit_price_inc_vat,
                        p_batch_order.v_order_head (hi).orderlines (li).total_inc_vat,
                        p_batch_order.v_order_head (hi).orderlines (li).paid_amount,
                        p_batch_order.v_order_head (hi).orderlines (li).agreement_sum,
                        p_batch_order.v_order_head (hi).orderlines (li).shipment_id_number,
                        p_batch_order.v_order_head (hi).orderlines (li).unit_price_excl_vat,
                        /* end wave 2 modification */
                        /* start CR 4475 */
                        p_batch_order.v_order_head (hi).orderlines (li).freight_payer
                        /* end CR 4475 */
                        ------------------------------------------------------------------------------------------------------------------------
                      );
                    COMMIT;
                  END IF;
                  /* start CR 3118 */
                  FOR rec_spec_ref IN 1.. p_batch_order.v_order_head
                  (
                    hi
                  )
                  .orderlines
                  (
                    li
                  )
                  .ref_spec_line.count-- p_batch_order.v_order_head (rec_head).InvSpecURL.count
                  LOOP
                    xxcu_common_log_rt.msglog
                    (
                      msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => 'Entered in ref spec for loop', msgcode => 1117, usermsg => '1', -- not sure what this is, maps to user_id in log table
                      msgsrc => 'XXCU_INTERFACE_SPEC_REF' , msgjobid => 10054
                    )
                    ;
                    --xxcu_log_pkg.LOG (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Excpetion occured before inserting in SPEC_URL TBL <' || v_batch_seq_no || SQLERRM );
                    xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => 'free_reference_code'||p_batch_order.v_order_head (hi).orderlines(li).ref_spec_line(rec_spec_ref).free_reference_code, msgcode => 1117, usermsg => '1', -- not sure what this is, maps to user_id in log table
                    msgsrc => 'XXCU_INTERFACE_SPEC_REF' , msgjobid => 10054);
                    IF( p_batch_order.v_order_head (hi).orderlines(li).ref_spec_line(rec_spec_ref).free_reference_code IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines(li).ref_spec_line(rec_spec_ref).free_reference_text IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines(li).ref_spec_line(rec_spec_ref).free_reference_content IS NOT NULL ) THEN
                      INSERT
                      INTO xxcu.xxcu_interface_spec_ref VALUES
                        (
                          /* start defect 3218 */
                          --g_ordeR_number,
                          NVL(p_batch_order.v_order_head (hi).printed_order_number,g_order_number),
                          /* end defect 3218 */
                          xxcu_interface_spec_ref_s.nextval,
                          p_batch_order.v_order_head (hi).orderlines(li).ref_spec_line(rec_spec_ref).free_reference_code,
                          p_batch_order.v_order_head (hi).orderlines(li).ref_spec_line(rec_spec_ref).free_reference_text,
                          p_batch_order.v_order_head (hi).orderlines(li).ref_spec_line(rec_spec_ref).free_reference_content,
                          NVL(p_batch_order.v_order_head (hi).orderlines(li).ref_spec_line(rec_spec_ref).print_on_invoice_flag,'Yes'),
                          sysdate,
                          g_user_id,
                          sysdate,
                          g_user_id,
                          /* start CR 3487 */
                          p_batch_order.v_order_head (hi).order_reference,
                          p_batch_order.v_order_head (hi).order_source,
                          p_batch_order.v_order_head (hi).orderlines(li).orderlineidsource,
                          /* end CR 3487 */
                          g_intf_inv_spec_seq ---- Added by Divyansh for Incident#E2-IM013492120
                        );
                      COMMIT;
                    END IF;
                  END LOOP;
                  /* end CR 3118 */
                EXCEPTION
                WHEN OTHERS THEN
                  --xxcu_log_pkg.LOG (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled errors in the xxcu_invoice_spec_p > ::Contact your system administrator:: ' || SQLERRM );
                  xxcu_common_log_rt.msglog ('ERR', 'Error Inserted in Spec Header'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  p_status_code  := 2;
                  p_error_message:='Error in invoice spec procedure'||sqlerrm||dbms_utility.format_error_backtrace;
                END;
                -- COMMIT;
                xxcu_common_log_rt.msglog ('INFO', 'Inserted in Spec Header', 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                IF(p_batch_order.v_order_head (hi).orderlines(li).speclines.count=0) THEN
                  /**ln_spec_count                                                             := p_batch_order.v_order_head (hi).orderlines.COUNT;**/
                  ln_spec_count :=0;
                  --  insert_invoice_spec_p(p_batch_order.v_order_head (rec_head),p_batch_order.v_order_head (rec_head).orderlines (rec_line),NULL,p_batch_order.v_order_head (rec_head).Order_Reference,p_batch_order.v_order_head (rec_head).orderlines (rec_line).orderlineidsource,g_order_number,p_status_code,p_error_message);
                ELSE
                  ln_spec_count:=p_batch_order.v_order_head (hi).orderlines(li).speclines.count;
                END IF;
                IF NVL( ln_spec_count ,0) >0 THEN
                  /* start CR 2811 */
                  /* start CR 4089 */
                  --AND upper(p_batch_order.v_order_head (hi).order_type)<>'RETURN' THEN
                  /* end */
                  /* end */
                  FOR rec_spec IN 1.. ln_spec_count
                  LOOP
                    --  dbms_output.put_line('count of spec:'||p_batch_order.v_order_head (rec_head).Orderlines(rec_line).speclines.count);
                    --xxcu_common_log_rt.msglog ('INFO', 'Inside Invoice spec loop', 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => SYSDATE, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                    /** IF nvl(p_batch_order.v_order_head (hi).orderlines(li).order_line_spec_hdr_cnt,0)>0 then
                    IF(p_batch_order.v_order_head (hi).orderlines(li).speclines.count=0) THEN
                    xxcu_common_log_rt.msglog ('INFO', 'Inside Invoice spec loop for speclines.count=0', 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => SYSDATE, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                    insert_invoice_spec_p(p_batch_order.v_order_head (hi),p_batch_order.v_order_head (hi).orderlines (li),NULL,p_batch_order.v_order_head (hi).Order_Reference,p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource,g_order_number,p_status_code,p_error_message);
                    ELSE**/
                    xxcu_common_log_rt.msglog
                    (
                      'INFO', 'Inside Invoice spec loop for speclines.count>0', 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL )
                    )
                    ;
                    insert_invoice_spec_p(p_batch_order.v_order_head (hi),p_batch_order.v_order_head (hi).orderlines (li),p_batch_order.v_order_head (hi).orderlines(li).speclines(rec_spec),p_batch_order.v_order_head (hi).order_reference,p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource,p_batch_order.v_order_head (hi).printed_order_number,p_status_code,p_error_message);
                    COMMIT;
                    /** END IF;**/
                    --  insert_invoice_spec_p(p_batch_order.v_order_head (rec_head),p_batch_order.v_order_head (rec_head).orderlines (rec_line),null,p_batch_order.v_order_head (rec_head).Order_Reference,p_status_code,p_error_message);
                  END LOOP;
                END IF;
              END IF;
              ---End Defect#2959
              /* start wave 2 modification */
              BEGIN
                FOR rec_spec_disc IN 1.. p_batch_order.v_order_head
                (
                  hi
                )
                .orderlines
                (
                  li
                )
                .inv_spec_disc.count
                LOOP
                  xxcu_common_log_rt.msglog
                  (
                    msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => 'Entered in rec_spec_disc for loop', msgcode => 1117, usermsg => '1', msgsrc => 'XXCU_INTF_DISCOUNT_SPEC' , msgjobid => 10054
                  )
                  ;
                  IF( p_batch_order.v_order_head (hi).orderlines(li).inv_spec_disc(rec_spec_disc).descriptionno IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines(li).inv_spec_disc(rec_spec_disc).descriptionus IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines(li).inv_spec_disc(rec_spec_disc).percentage IS NOT NULL)--defect 4259
                    THEN
                    INSERT
                    INTO xxcu_intf_discount_spec VALUES
                      (
                        g_order_number,
                        p_batch_order.v_order_head (hi).order_reference,
                        p_batch_order.v_order_head (hi).order_source,
                        p_batch_order.v_order_head (hi).orderlines(li).orderlineidsource,
                        p_batch_order.v_order_head (hi).orderlines(li).inv_spec_disc(rec_spec_disc).descriptionno,
                        p_batch_order.v_order_head (hi).orderlines(li).inv_spec_disc(rec_spec_disc).descriptionus,
                        p_batch_order.v_order_head (hi).orderlines(li).inv_spec_disc(rec_spec_disc).percentage,
                        sysdate,
                        g_user_id,
                        g_user_id,
                        sysdate,
                        g_intf_inv_spec_seq
                      );
                    COMMIT;
                  END IF;
                END LOOP;
              EXCEPTION
              WHEN OTHERS THEN
                --xxcu_log_pkg.LOG (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled errors in the xxcu_invoice_spec_p > ::Contact your system administrator:: ' || SQLERRM );
                xxcu_common_log_rt.msglog ('ERR', 'Error Inserted in Spec Discount Header'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                p_status_code  := 2;
                p_error_message:='Error in spec discount insert'||sqlerrm||dbms_utility.format_error_backtrace;
              END;
              /* end wave 2 modification */
              /* Version 1.9 Defect # 217 */
              --xxcu_common_log_rt.msglog ('INFO', 'p_batch_order.v_order_head (hi).lv_private_cust(1).customer_reference '||p_batch_order.v_order_head (hi).lv_private_cust(1).customer_reference, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
              IF(lv_orig_system IS NOT NULL) THEN
                FOR bjk IN 1 .. p_batch_order.v_order_head
                (
                  hi
                )
                .orderlines.count
                LOOP
                  -- dbms_output.put_line(SIGN(p_batch_order.v_order_head (hi).orderlines(p).quantity));
                  /* start defect 4783 */
                  BEGIN
                    SELECT flv.profile_option_value
                    INTO lv_term_name
                    FROM fnd_profile_options_vl fpov,
                      applsys.fnd_profile_option_values flv
                    WHERE fpov.profile_option_name='XXCU_DEFAULT_PAYMET_TERM'
                    AND flv.profile_option_id     =fpov.profile_option_id;
                  EXCEPTION
                  WHEN OTHERS THEN
                    xxcu_common_log_rt.msglog ('ERR', 'Error in profile option PB Default Payment Term for Private Customers'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  END;
                  BEGIN
                    SELECT term_id INTO ln_term FROM ra_terms WHERE name=lv_term_name;
                  EXCEPTION
                  WHEN OTHERS THEN
                    xxcu_common_log_rt.msglog ('ERR', 'Error while deriving paymet term for private customer'||sqlerrm, 1117, 1, 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
                  END;
                  /* end defect 4783 */
                  UPDATE oe_lines_iface_all
                  SET payment_term_id        =ln_term,--'10 days',--defect 4783
                    sold_to_org_id           =ln_sold_to_org
                  WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference
                  AND org_id                 =p_batch_order.v_order_head (hi).org_id;
                  COMMIT;
                END LOOP;
              END IF;
              IF (                                                                                                                                                                                     --p_batch_order.v_order_head (hi).lv_private_cust.count=0  --defect 4640
                p_batch_order.v_order_head (hi).lv_private_cust.count =0 OR (p_batch_order.v_order_head (hi).lv_private_cust.count =1 AND p_batch_order.v_order_head (hi).customer_number IS NOT NULL )--defect 4640
                OR ln_sold_to_org                                    IS NULL                                                                                                                           -- CR 5204
                AND p_batch_order.v_order_head (hi).order_source     <>'NO002_RB' AND upper(p_batch_order.v_order_head (hi).order_type)<>'RETURN' ) THEN
                BEGIN
                  lv_wrong_cust:='N';
                  /* start CR 5204 */
                  IF(ln_sold_to_org IS NULL) THEN
                    lv_wrong_cust   :='Y';
                  END IF;
                  /* end CR 5204 */
                  SELECT account_number
                  INTO lv_customer_num
                  FROM hz_cust_accounts
                  WHERE account_number=p_batch_order.v_order_head (hi).customer_number;
                EXCEPTION
                WHEN OTHERS THEN
                  lv_wrong_cust:='Y';
                  UPDATE oe_headers_iface_all
                  SET error_flag             ='Y'
                  WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;
                  COMMIT;
                  SELECT oe_msg_id_s.nextval INTO l_transaction_id FROM dual;
                  /* SELECT message_text
                  INTO lv_msg_text
                  FROM fnd_new_messages
                  WHERE message_name='XXCU_CUSTOMER_NUMBER_NULL'
                  AND language_code =USERENV('LANG');*/
                  INSERT
                  INTO oe_processing_msgs
                    (
                      transaction_id ,
                      request_id
                      --     ,message_text
                      ,
                      entity_code ,
                      entity_ref ,
                      entity_id ,
                      header_id ,
                      line_id ,
                      order_source_id ,
                      original_sys_document_ref ,
                      original_sys_document_line_ref ,
                      orig_sys_shipment_ref ,
                      change_sequence ,
                      source_document_type_id ,
                      source_document_id ,
                      source_document_line_id ,
                      attribute_code ,
                      creation_date ,
                      created_by ,
                      last_update_date ,
                      last_updated_by ,
                      last_update_login ,
                      program_application_id ,
                      program_id ,
                      program_update_date ,
                      process_activity ,
                      notification_flag ,
                      type ,
                      message_source_code ,
                      message_status_code ,
                      org_id
                    )
                    VALUES
                    (
                      l_transaction_id ,
                      NULL
                      --     ,l_msg_data
                      ,
                      'LINE' ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      g_order_source_id ,
                      p_batch_order.v_order_head (hi).order_reference ,
                      p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      sysdate ,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      fnd_global.login_id ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      'ERROR' ,
                      'C' ,
                      'OPEN' ,
                      p_batch_order.v_order_head (hi).org_id
                    );
                  BEGIN
                    INSERT
                    INTO oe_processing_msgs_tl
                      (
                        transaction_id ,
                        language ,
                        source_lang ,
                        message_text ,
                        created_by ,
                        creation_date ,
                        last_updated_by ,
                        last_update_date ,
                        last_update_login
                      )
                    SELECT l_transaction_id ,
                      l.language_code ,
                      'US' ,
                      (SELECT message_text
                      FROM fnd_new_messages
                      WHERE message_name='XXCU_CUSTOMER_NUMBER_NULL'
                      AND language_code ='US'
                      )--,'Tax Code Can not be null'
                      ,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      sysdate ,
                      fnd_global.login_id
                    FROM fnd_languages l
                    WHERE l.installed_flag IN ('I','B')
                    AND language_code       = 'US'
                    AND NOT EXISTS
                      (SELECT NULL
                      FROM oe_processing_msgs_tl t
                      WHERE t.transaction_id = l_transaction_id
                      AND t.language         = l.language_code
                      );
                    --start defect 2891
                    INSERT
                    INTO oe_processing_msgs_tl
                      (
                        transaction_id ,
                        language ,
                        source_lang ,
                        message_text ,
                        created_by ,
                        creation_date ,
                        last_updated_by ,
                        last_update_date ,
                        last_update_login
                      )
                    SELECT l_transaction_id ,
                      l.language_code ,
                      'N' ,
                      (SELECT message_text
                      FROM fnd_new_messages
                      WHERE message_name='XXCU_CUSTOMER_NUMBER_NULL'
                      AND language_code ='N'
                      )--,'Tax Code Can not be null'
                      ,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      sysdate ,
                      fnd_global.login_id
                    FROM fnd_languages l
                    WHERE l.installed_flag IN ('I','B')
                    AND language_code       = 'N'
                    AND NOT EXISTS
                      (SELECT NULL
                      FROM oe_processing_msgs_tl t
                      WHERE t.transaction_id = l_transaction_id
                      AND t.language         = l.language_code
                      );
                  END;
                  --end
                  COMMIT;
                END;
              END IF;
              -- END LOOP;
              /* version 1.23 CR# 1229 */
              BEGIN
                lv_wrong_tax     :='N';
                ln_order_type_id := NULL;
                IF(lv_tax        IS NULL) THEN
                  /**********************/
                  ---Start changes CR#2449
                  BEGIN
                    BEGIN
                      ln_order_type_id := get_transaction_type_id(p_batch_order.v_order_head (hi).order_source, p_batch_order.v_order_head (hi).order_type, p_batch_order.v_order_head (hi).org_id, p_status_code, p_error_message);
                    EXCEPTION
                    WHEN OTHERS THEN
                      xxcu_common_log_rt.msglog ('ERR', 'Failed to derive transaction type id 1 '||sqlerrm||dbms_utility.format_error_backtrace, 1117, '1', 'get_transaction_type_id', '-1' );
                    END;
                    BEGIN
                      SELECT tax_calculation_event_code
                      INTO lv_tax_calc_event_code
                      FROM oe_transaction_types_all
                      WHERE transaction_type_id =ln_order_type_id;
                    EXCEPTION
                    WHEN OTHERS THEN
                      ln_order_type_id := NULL;
                    END;
                    --
                    IF lv_tax_calc_event_code ='INVOICING' THEN -----End changes CR#2449
                      lv_wrong_tax           :='Y';
                      UPDATE oe_headers_iface_all
                      SET error_flag             ='Y'
                      WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;
                      UPDATE oe_lines_iface_all
                      SET error_flag         ='Y'
                      WHERE orig_sys_line_ref=v_upd_orig_sys_line_ref;
                      UPDATE oe_price_adjs_iface_all
                      SET error_flag           ='Y'
                      WHERE orig_sys_line_ref  =v_upd_orig_sys_line_ref
                      AND orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;
                      COMMIT;
                      -------------------------------------------------------------------
                      --  OE_MSG_PUB               BEGIN
                      SELECT oe_msg_id_s.nextval
                      INTO l_transaction_id
                      FROM dual;
                      /* SELECT message_text
                      INTO lv_msg_text
                      FROM fnd_new_messages
                      WHERE message_name='OE_VAL_TAX_CODE_REQD'
                      AND language_code =USERENV('LANG');*/
                      --
                      INSERT
                      INTO oe_processing_msgs
                        (
                          transaction_id ,
                          request_id
                          --     ,message_text
                          ,
                          entity_code ,
                          entity_ref ,
                          entity_id ,
                          header_id ,
                          line_id ,
                          order_source_id ,
                          original_sys_document_ref ,
                          original_sys_document_line_ref ,
                          orig_sys_shipment_ref ,
                          change_sequence ,
                          source_document_type_id ,
                          source_document_id ,
                          source_document_line_id ,
                          attribute_code ,
                          creation_date ,
                          created_by ,
                          last_update_date ,
                          last_updated_by ,
                          last_update_login ,
                          program_application_id ,
                          program_id ,
                          program_update_date ,
                          process_activity ,
                          notification_flag ,
                          type ,
                          message_source_code ,
                          message_status_code ,
                          org_id
                        )
                        VALUES
                        (
                          l_transaction_id ,
                          NULL
                          --     ,l_msg_data
                          ,
                          'LINE' ,
                          NULL ,
                          NULL ,
                          NULL ,
                          NULL ,
                          g_order_source_id ,
                          p_batch_order.v_order_head (hi).order_reference ,
                          p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource ,
                          NULL ,
                          NULL ,
                          NULL ,
                          NULL ,
                          NULL ,
                          NULL ,
                          sysdate ,
                          g_user_id ,
                          sysdate ,
                          g_user_id ,
                          fnd_global.login_id ,
                          NULL ,
                          NULL ,
                          NULL ,
                          NULL ,
                          NULL ,
                          'ERROR' ,
                          'C' ,
                          'OPEN' ,
                          p_batch_order.v_order_head (hi).org_id
                        );
                      --
                      BEGIN
                        INSERT
                        INTO oe_processing_msgs_tl
                          (
                            transaction_id ,
                            language ,
                            source_lang ,
                            message_text ,
                            created_by ,
                            creation_date ,
                            last_updated_by ,
                            last_update_date ,
                            last_update_login
                          )
                        SELECT l_transaction_id ,
                          l.language_code ,
                          'US' ,
                          (SELECT message_text
                          FROM fnd_new_messages
                          WHERE message_name='OE_VAL_TAX_CODE_REQD'
                          AND language_code ='US'
                          ) ,
                          g_user_id ,
                          sysdate ,
                          g_user_id ,
                          sysdate ,
                          fnd_global.login_id
                        FROM fnd_languages l
                        WHERE l.installed_flag IN ('I','B')
                        AND language_code       = 'US'
                        AND NOT EXISTS
                          (SELECT NULL
                          FROM oe_processing_msgs_tl t
                          WHERE t.transaction_id = l_transaction_id
                          AND t.language         = l.language_code
                          );
                        --start defect 2891
                        INSERT
                        INTO oe_processing_msgs_tl
                          (
                            transaction_id ,
                            language ,
                            source_lang ,
                            message_text ,
                            created_by ,
                            creation_date ,
                            last_updated_by ,
                            last_update_date ,
                            last_update_login
                          )
                        SELECT l_transaction_id ,
                          l.language_code ,
                          'N' ,
                          (SELECT message_text
                          FROM fnd_new_messages
                          WHERE message_name='OE_VAL_TAX_CODE_REQD'
                          AND language_code ='N'
                          ) ,
                          g_user_id ,
                          sysdate ,
                          g_user_id ,
                          sysdate ,
                          fnd_global.login_id
                        FROM fnd_languages l
                        WHERE l.installed_flag IN ('I','B')
                        AND language_code       = 'N'
                        AND NOT EXISTS
                          (SELECT NULL
                          FROM oe_processing_msgs_tl t
                          WHERE t.transaction_id = l_transaction_id
                          AND t.language         = l.language_code
                          );
                        --end
                      END;
                      COMMIT;
                    END IF;
                  END;
                END IF;
              EXCEPTION
              WHEN OTHERS THEN
                p_status_code := g_code_error;
                xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Tax code should not be null' || g_program_loc || '> ::Contact your system administrator:: ' || v_batch_seq_no || sqlerrm );
                dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
              END;
              /* version 1.28 CR# 2499 */
              /* wave 2 modification */
              BEGIN
                SELECT NVL(ffvv.attribute7,'N')
                INTO lv_sales_yes_no
                FROM fnd_flex_value_sets ffvs,
                  fnd_flex_values ffvv
                WHERE ffvs.flex_value_set_name='XXCU_OM_SOURCE_ORDER_TYPE'
                AND ffvs.flex_value_set_id    =ffvv.flex_value_set_id
                AND upper(ffvv.flex_value)    =upper(p_batch_order.v_order_head (hi).order_source);
              EXCEPTION
              WHEN OTHERS THEN
                lv_sales_yes_no:='N';
              END;
              IF(lv_sales_yes_no='N') THEN
                BEGIN
                  lv_wrong_salesper                                              :='N';
                  IF(p_batch_order.v_order_head (hi).orderlines (li).salesperson IS NULL) THEN
                    lv_wrong_salesper                                            :='Y';
                    UPDATE oe_headers_iface_all
                    SET error_flag             ='Y'
                    WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;
                    UPDATE oe_lines_iface_all
                    SET error_flag         ='Y'
                    WHERE orig_sys_line_ref=v_upd_orig_sys_line_ref;
                    UPDATE oe_price_adjs_iface_all
                    SET error_flag           ='Y'
                    WHERE orig_sys_line_ref  =v_upd_orig_sys_line_ref
                    AND orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;
                    COMMIT;
                    -------------------------------------------------------------------
                    --  OE_MSG_PUB               BEGIN
                    SELECT oe_msg_id_s.nextval
                    INTO l_transaction_id
                    FROM dual;
                    /*  SELECT message_text
                    INTO lv_msg_text
                    FROM fnd_new_messages
                    WHERE message_name='XXCU_INVALID_SALESPERSON'
                    AND language_code =USERENV('LANG');*/
                    INSERT
                    INTO oe_processing_msgs
                      (
                        transaction_id ,
                        request_id
                        --     ,message_text
                        ,
                        entity_code ,
                        entity_ref ,
                        entity_id ,
                        header_id ,
                        line_id ,
                        order_source_id ,
                        original_sys_document_ref ,
                        original_sys_document_line_ref ,
                        orig_sys_shipment_ref ,
                        change_sequence ,
                        source_document_type_id ,
                        source_document_id ,
                        source_document_line_id ,
                        attribute_code ,
                        creation_date ,
                        created_by ,
                        last_update_date ,
                        last_updated_by ,
                        last_update_login ,
                        program_application_id ,
                        program_id ,
                        program_update_date ,
                        process_activity ,
                        notification_flag ,
                        type ,
                        message_source_code ,
                        message_status_code ,
                        org_id
                      )
                      VALUES
                      (
                        l_transaction_id ,
                        NULL
                        --     ,l_msg_data
                        ,
                        'LINE' ,
                        NULL ,
                        NULL ,
                        NULL ,
                        NULL ,
                        g_order_source_id ,
                        p_batch_order.v_order_head (hi).order_reference ,
                        v_upd_orig_sys_line_ref,--p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource ,
                        NULL ,
                        NULL ,
                        NULL ,
                        NULL ,
                        NULL ,
                        NULL ,
                        sysdate ,
                        g_user_id ,
                        sysdate ,
                        g_user_id ,
                        fnd_global.login_id ,
                        NULL ,
                        NULL ,
                        NULL ,
                        NULL ,
                        NULL ,
                        'ERROR' ,
                        'C' ,
                        'OPEN' ,
                        p_batch_order.v_order_head (hi).org_id
                      );
                    BEGIN
                      INSERT
                      INTO oe_processing_msgs_tl
                        (
                          transaction_id ,
                          language ,
                          source_lang ,
                          message_text ,
                          created_by ,
                          creation_date ,
                          last_updated_by ,
                          last_update_date ,
                          last_update_login
                        )
                      SELECT l_transaction_id ,
                        l.language_code ,
                        'US' ,
                        (SELECT message_text
                        FROM fnd_new_messages
                        WHERE message_name='XXCU_INVALID_SALESPERSON'
                        AND language_code ='US'
                        ) ,
                        g_user_id ,
                        sysdate ,
                        g_user_id ,
                        sysdate ,
                        fnd_global.login_id
                      FROM fnd_languages l
                      WHERE l.installed_flag IN ('I','B')
                      AND language_code       = 'US'
                      AND NOT EXISTS
                        (SELECT NULL
                        FROM oe_processing_msgs_tl t
                        WHERE t.transaction_id = l_transaction_id
                        AND t.language         = l.language_code
                        );
                      --start defect 2891
                      INSERT
                      INTO oe_processing_msgs_tl
                        (
                          transaction_id ,
                          language ,
                          source_lang ,
                          message_text ,
                          created_by ,
                          creation_date ,
                          last_updated_by ,
                          last_update_date ,
                          last_update_login
                        )
                      SELECT l_transaction_id ,
                        l.language_code ,
                        'N' ,
                        (SELECT message_text
                        FROM fnd_new_messages
                        WHERE message_name='XXCU_INVALID_SALESPERSON'
                        AND language_code ='N'
                        ) ,
                        g_user_id ,
                        sysdate ,
                        g_user_id ,
                        sysdate ,
                        fnd_global.login_id
                      FROM fnd_languages l
                      WHERE l.installed_flag IN ('I','B')
                      AND language_code       = 'N'
                      AND NOT EXISTS
                        (SELECT NULL
                        FROM oe_processing_msgs_tl t
                        WHERE t.transaction_id = l_transaction_id
                        AND t.language         = l.language_code
                        );
                      --end
                    END;
                    COMMIT;
                  END IF;
                EXCEPTION
                WHEN OTHERS THEN
                  p_status_code := g_code_error;
                  xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Tax code should not be null' || g_program_loc || '> ::Contact your system administrator:: ' || v_batch_seq_no || sqlerrm );
                  dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
                END;
              END IF;
              /* end version 1.28 CR 2499 */
              /* version 1.27 CR# 2375 */
              BEGIN
                -- FOR rec_c IN 1 .. p_batch_order.v_order_head (hi).orderlines.COUNT
                --LOOP
                lv_wrong_price :='N';
                -- IF(NVL(p_batch_order.v_order_head (hi).orderlines(li).unit_selling_price,0)<>(NVL(p_batch_order.v_order_head (hi).orderlines(li).unit_list_price,0)-ABS(NVL(p_batch_order.v_order_head (hi).orderlines(li).price_adj_per_unit,0)))) THEN
                /* start defect 4676 */
                -- IF(ABS(NVL(p_batch_order.v_order_head (hi).orderlines(li).unit_selling_price,0)-NVL(p_batch_order.v_order_head (hi).orderlines(li).unit_list_price,0))<>ABS(NVL(p_batch_order.v_order_head (hi).orderlines(li).price_adj_per_unit,0))) THEN
                IF(ABS(ROUND(NVL(p_batch_order.v_order_head (hi).orderlines(li).unit_selling_price,0)-NVL(p_batch_order.v_order_head (hi).orderlines(li).unit_list_price,0),2))<>ABS(NVL(ROUND(p_batch_order.v_order_head (hi).orderlines(li).price_adj_per_unit,2),0))) THEN
                  /* end defect 4676 */
                  lv_wrong_price :='Y';
                END IF;
                --  end loop;
                IF(lv_wrong_price='Y') THEN
                  UPDATE oe_headers_iface_all
                  SET error_flag             ='Y'
                  WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;
                  UPDATE oe_lines_iface_all
                  SET error_flag         ='Y'
                  WHERE orig_sys_line_ref=v_upd_orig_sys_line_ref;
                  UPDATE oe_price_adjs_iface_all
                  SET error_flag           ='Y'
                  WHERE orig_sys_line_ref  =v_upd_orig_sys_line_ref
                  AND orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;
                  COMMIT;
                  -------------------------------------------------------------------
                  --  OE_MSG_PUB               BEGIN
                  SELECT oe_msg_id_s.nextval
                  INTO l_transaction_id
                  FROM dual;
                  /* SELECT message_text
                  INTO lv_msg_text
                  FROM fnd_new_messages
                  WHERE message_name='XXCU_PRICE_ADJUSTMENTS'
                  AND language_code =USERENV('LANG');*/
                  INSERT
                  INTO oe_processing_msgs
                    (
                      transaction_id ,
                      request_id
                      --     ,message_text
                      ,
                      entity_code ,
                      entity_ref ,
                      entity_id ,
                      header_id ,
                      line_id ,
                      order_source_id ,
                      original_sys_document_ref ,
                      original_sys_document_line_ref ,
                      orig_sys_shipment_ref ,
                      change_sequence ,
                      source_document_type_id ,
                      source_document_id ,
                      source_document_line_id ,
                      attribute_code ,
                      creation_date ,
                      created_by ,
                      last_update_date ,
                      last_updated_by ,
                      last_update_login ,
                      program_application_id ,
                      program_id ,
                      program_update_date ,
                      process_activity ,
                      notification_flag ,
                      type ,
                      message_source_code ,
                      message_status_code ,
                      org_id
                    )
                    VALUES
                    (
                      l_transaction_id ,
                      NULL
                      --     ,l_msg_data
                      ,
                      'LINE' ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      g_order_source_id ,
                      p_batch_order.v_order_head (hi).order_reference ,
                      p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      sysdate ,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      fnd_global.login_id ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      'ERROR' ,
                      'C' ,
                      'OPEN' ,
                      p_batch_order.v_order_head (hi).org_id
                    );
                  BEGIN
                    INSERT
                    INTO oe_processing_msgs_tl
                      (
                        transaction_id ,
                        language ,
                        source_lang ,
                        message_text ,
                        created_by ,
                        creation_date ,
                        last_updated_by ,
                        last_update_date ,
                        last_update_login
                      )
                    SELECT l_transaction_id ,
                      l.language_code ,
                      'US' ,
                      (SELECT message_text
                      FROM fnd_new_messages
                      WHERE message_name='XXCU_PRICE_ADJUSTMENTS'
                      AND language_code ='US'
                      ) ,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      sysdate ,
                      fnd_global.login_id
                    FROM fnd_languages l
                    WHERE l.installed_flag IN ('I','B')
                    AND language_code       = 'US'
                    AND NOT EXISTS
                      (SELECT NULL
                      FROM oe_processing_msgs_tl t
                      WHERE t.transaction_id = l_transaction_id
                      AND t.language         = l.language_code
                      );
                    --start defect 2891
                    INSERT
                    INTO oe_processing_msgs_tl
                      (
                        transaction_id ,
                        language ,
                        source_lang ,
                        message_text ,
                        created_by ,
                        creation_date ,
                        last_updated_by ,
                        last_update_date ,
                        last_update_login
                      )
                    SELECT l_transaction_id ,
                      l.language_code ,
                      'N' ,
                      (SELECT message_text
                      FROM fnd_new_messages
                      WHERE message_name='XXCU_PRICE_ADJUSTMENTS'
                      AND language_code ='N'
                      ) ,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      sysdate ,
                      fnd_global.login_id
                    FROM fnd_languages l
                    WHERE l.installed_flag IN ('I','B')
                    AND language_code       = 'N'
                    AND NOT EXISTS
                      (SELECT NULL
                      FROM oe_processing_msgs_tl t
                      WHERE t.transaction_id = l_transaction_id
                      AND t.language         = l.language_code
                      );
                    --end
                  END;
                  COMMIT;
                  --  end if;
                END IF;
              EXCEPTION
              WHEN OTHERS THEN
                p_status_code := g_code_error;
                xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Tax code should not be null' || g_program_loc || '> ::Contact your system administrator:: ' || v_batch_seq_no || sqlerrm );
                dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
              END;
              /* version 1.9 modified for defect # 167 */
              BEGIN
                lv_wrong_ret_data                           :='N';
                IF(p_batch_order.v_order_head (hi).order_type='Regular' AND (p_batch_order.v_order_head (hi).return_order_reference IS NOT NULL OR p_batch_order.v_order_head (hi).orderlines (li).ret_orderlineidsource IS NOT NULL)) THEN
                  lv_wrong_ret_data                         :='Y';
                  UPDATE oe_headers_iface_all
                  SET error_flag             ='Y'
                  WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;
                  UPDATE oe_lines_iface_all
                  SET error_flag         ='Y'
                  WHERE orig_sys_line_ref=p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource;
                  UPDATE oe_price_adjs_iface_all
                  SET error_flag           ='Y'
                  WHERE orig_sys_line_ref  =p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource
                  AND orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;
                  COMMIT;
                  SELECT oe_msg_id_s.nextval INTO l_transaction_id FROM dual;
                  /* SELECT message_text
                  INTO lv_msg_text
                  FROM fnd_new_messages
                  WHERE message_name='XXCU_ORDER_REFERENCE_REGULAR'
                  AND language_code =USERENV('LANG');*/
                  INSERT
                  INTO oe_processing_msgs
                    (
                      transaction_id ,
                      request_id
                      --     ,message_text
                      ,
                      entity_code ,
                      entity_ref ,
                      entity_id ,
                      header_id ,
                      line_id ,
                      order_source_id ,
                      original_sys_document_ref ,
                      original_sys_document_line_ref ,
                      orig_sys_shipment_ref ,
                      change_sequence ,
                      source_document_type_id ,
                      source_document_id ,
                      source_document_line_id ,
                      attribute_code ,
                      creation_date ,
                      created_by ,
                      last_update_date ,
                      last_updated_by ,
                      last_update_login ,
                      program_application_id ,
                      program_id ,
                      program_update_date ,
                      process_activity ,
                      notification_flag ,
                      type ,
                      message_source_code ,
                      message_status_code ,
                      org_id
                    )
                    VALUES
                    (
                      l_transaction_id ,
                      NULL
                      --     ,l_msg_data
                      ,
                      'LINE' ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      g_order_source_id ,
                      p_batch_order.v_order_head (hi).order_reference ,
                      p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      sysdate ,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      fnd_global.login_id ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      'ERROR' ,
                      'C' ,
                      'OPEN' ,
                      p_batch_order.v_order_head (hi).org_id
                    );
                  BEGIN
                    INSERT
                    INTO oe_processing_msgs_tl
                      (
                        transaction_id ,
                        language ,
                        source_lang ,
                        message_text ,
                        created_by ,
                        creation_date ,
                        last_updated_by ,
                        last_update_date ,
                        last_update_login
                      )
                    SELECT l_transaction_id ,
                      l.language_code ,
                      'US' ,
                      (SELECT message_text
                      FROM fnd_new_messages
                      WHERE message_name='XXCU_ORDER_REFERENCE_REGULAR'
                      AND language_code ='US'
                      ) ,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      sysdate ,
                      fnd_global.login_id
                    FROM fnd_languages l
                    WHERE l.installed_flag IN ('I','B')
                    AND language_code       = 'US'
                    AND NOT EXISTS
                      (SELECT NULL
                      FROM oe_processing_msgs_tl t
                      WHERE t.transaction_id = l_transaction_id
                      AND t.language         = l.language_code
                      );
                    --start defect 2891
                    INSERT
                    INTO oe_processing_msgs_tl
                      (
                        transaction_id ,
                        language ,
                        source_lang ,
                        message_text ,
                        created_by ,
                        creation_date ,
                        last_updated_by ,
                        last_update_date ,
                        last_update_login
                      )
                    SELECT l_transaction_id ,
                      l.language_code ,
                      'N' ,
                      (SELECT message_text
                      FROM fnd_new_messages
                      WHERE message_name='XXCU_ORDER_REFERENCE_REGULAR'
                      AND language_code ='N'
                      ) ,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      sysdate ,
                      fnd_global.login_id
                    FROM fnd_languages l
                    WHERE l.installed_flag IN ('I','B')
                    AND language_code       = 'N'
                    AND NOT EXISTS
                      (SELECT NULL
                      FROM oe_processing_msgs_tl t
                      WHERE t.transaction_id = l_transaction_id
                      AND t.language         = l.language_code
                      );
                  END;
                  COMMIT;
                END IF;
              EXCEPTION
              WHEN OTHERS THEN
                p_status_code := g_code_error;
                xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled error in updating error flag: <' || g_program_loc || '> ::Contact your system administrator:: ' || v_batch_seq_no || sqlerrm );
                dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
              END;
              BEGIN
                xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => 'Order Entry' || sqlerrm, msgcode => 1117, usermsg => '1', -- not sure what this is, maps to user_id in log table
                msgsrc => 'Test' , msgjobid => 10054);
                lv_wrong_ref                                :='N';
                IF(p_batch_order.v_order_head (hi).order_type='Return' AND (p_batch_order.v_order_head (hi).return_order_reference IS NULL OR p_batch_order.v_order_head (hi).orderlines (li).ret_orderlineidsource IS NULL) AND p_batch_order.v_order_head (hi).order_source NOT IN ('NO002_RB','RETTBETALT')) THEN
                  lv_wrong_ref                              :='Y';
                  UPDATE oe_headers_iface_all
                  SET error_flag             ='Y'
                  WHERE orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;
                  UPDATE oe_lines_iface_all
                  SET error_flag         ='Y'
                  WHERE orig_sys_line_ref=p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource;
                  UPDATE oe_price_adjs_iface_all
                  SET error_flag           ='Y'
                  WHERE orig_sys_line_ref  =p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource
                  AND orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;
                  COMMIT;
                  SELECT oe_msg_id_s.nextval INTO l_transaction_id FROM dual;
                  /* SELECT message_text
                  INTO lv_msg_text
                  FROM fnd_new_messages
                  WHERE message_name='XXCU_ORDER_REFERENCE_RETURN'
                  AND language_code =USERENV('LANG');*/
                  INSERT
                  INTO oe_processing_msgs
                    (
                      transaction_id ,
                      request_id
                      --     ,message_text
                      ,
                      entity_code ,
                      entity_ref ,
                      entity_id ,
                      header_id ,
                      line_id ,
                      order_source_id ,
                      original_sys_document_ref ,
                      original_sys_document_line_ref ,
                      orig_sys_shipment_ref ,
                      change_sequence ,
                      source_document_type_id ,
                      source_document_id ,
                      source_document_line_id ,
                      attribute_code ,
                      creation_date ,
                      created_by ,
                      last_update_date ,
                      last_updated_by ,
                      last_update_login ,
                      program_application_id ,
                      program_id ,
                      program_update_date ,
                      process_activity ,
                      notification_flag ,
                      type ,
                      message_source_code ,
                      message_status_code ,
                      org_id
                    )
                    VALUES
                    (
                      l_transaction_id ,
                      NULL
                      --     ,l_msg_data
                      ,
                      'LINE' ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      g_order_source_id ,
                      p_batch_order.v_order_head (hi).order_reference ,
                      p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      sysdate ,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      fnd_global.login_id ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      'ERROR' ,
                      'C' ,
                      'OPEN' ,
                      p_batch_order.v_order_head (hi).org_id
                    );
                  BEGIN
                    INSERT
                    INTO oe_processing_msgs_tl
                      (
                        transaction_id ,
                        language ,
                        source_lang ,
                        message_text ,
                        created_by ,
                        creation_date ,
                        last_updated_by ,
                        last_update_date ,
                        last_update_login
                      )
                    SELECT l_transaction_id ,
                      l.language_code ,
                      'US' ,
                      (SELECT message_text
                      FROM fnd_new_messages
                      WHERE message_name='XXCU_ORDER_REFERENCE_RETURN'
                      AND language_code ='US'
                      ) ,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      sysdate ,
                      fnd_global.login_id
                    FROM fnd_languages l
                    WHERE l.installed_flag IN ('I','B')
                    AND language_code       = 'US'
                    AND NOT EXISTS
                      (SELECT NULL
                      FROM oe_processing_msgs_tl t
                      WHERE t.transaction_id = l_transaction_id
                      AND t.language         = l.language_code
                      );
                    --start defect 2891
                    INSERT
                    INTO oe_processing_msgs_tl
                      (
                        transaction_id ,
                        language ,
                        source_lang ,
                        message_text ,
                        created_by ,
                        creation_date ,
                        last_updated_by ,
                        last_update_date ,
                        last_update_login
                      )
                    SELECT l_transaction_id ,
                      l.language_code ,
                      'N' ,
                      (SELECT message_text
                      FROM fnd_new_messages
                      WHERE message_name='XXCU_ORDER_REFERENCE_RETURN'
                      AND language_code ='N'
                      ) ,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      sysdate ,
                      fnd_global.login_id
                    FROM fnd_languages l
                    WHERE l.installed_flag IN ('I','B')
                    AND language_code       = 'N'
                    AND NOT EXISTS
                      (SELECT NULL
                      FROM oe_processing_msgs_tl t
                      WHERE t.transaction_id = l_transaction_id
                      AND t.language         = l.language_code
                      );
                  END;
                  COMMIT;
                END IF;
              EXCEPTION
              WHEN OTHERS THEN
                p_status_code := g_code_error;
                xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled error in updating error flag: <' || g_program_loc || '> ::Contact your system administrator:: ' || v_batch_seq_no || sqlerrm );
                dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
              END;
              --reconciliation (p_batch_order.batchid, p_batch_order.messagesequenceno, p_batch_order.Batchnototal, v_orderline_count, p_batch_order.batchdate, p_batch_order.batchdetailcount,v_max_date, v_min_date, p_batch_order.messagedetailcount,v_num_orderheads, v_num_orderlines, v_finish_status, v_status_function );
              -- END IF;
            EXCEPTION
            WHEN OTHERS THEN
              p_status_code := g_code_error;
              xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled error in creation of order line: <' || g_program_loc || '> ::Contact your system administrator:: ' || v_batch_seq_no || sqlerrm );
              ROLLBACK;
              dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
            END;
            ----Changes started by Divyansh for incident #E2-IM014174700 Defect #8447
            BEGIN
              l_item_id := xxcu_ont_create_order_pkg.getinventory_item_id( p_batch_order.v_order_head (hi).orderlines(li).itemno, p_batch_order.v_order_head (hi).order_source, p_batch_order.v_order_head (hi).order_type, p_batch_order.v_order_head (hi).org_id );
              BEGIN
                SELECT 1
                INTO l_item_type
                FROM mtl_system_items_b
                WHERE inventory_item_id = l_item_id
                AND organization_id     = p_batch_order.v_order_head (hi).org_id
                AND item_type          IN
                  (SELECT ffvv.flex_value
                  FROM fnd_flex_value_sets ffvs,
                    fnd_flex_values_vl ffvv
                  WHERE ffvs.flex_value_set_name = 'XXCU_OM_TAX_ITEM_TYPE'
                  AND ffvs.flex_value_set_id     =ffvv.flex_value_set_id
                  );
              EXCEPTION
              WHEN OTHERS THEN
                l_item_type:=2;
              END;
              IF l_item_type = 1 AND (p_batch_order.v_order_head (hi).orderlines(li).postal_code_from IS NULL OR p_batch_order.v_order_head (hi).orderlines(li).postal_code_to IS NULL OR p_batch_order.v_order_head (hi).orderlines(li).country_code_from IS NULL OR p_batch_order.v_order_head (hi).orderlines(li).country_code_to IS NULL) THEN
                UPDATE oe_lines_iface_all
                SET error_flag         ='Y'
                WHERE orig_sys_line_ref=v_upd_orig_sys_line_ref;
                UPDATE oe_price_adjs_iface_all
                SET error_flag           ='Y'
                WHERE orig_sys_line_ref  =v_upd_orig_sys_line_ref
                AND orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;-- v_orig_sys_document_ref , --changed for incident E2-IM013472372
                COMMIT;
                -------------------------------------------------------------------
                SELECT oe_msg_id_s.nextval
                INTO l_transaction_id
                FROM dual;
                INSERT
                INTO oe_processing_msgs
                  (
                    transaction_id ,
                    request_id,
                    entity_code ,
                    entity_ref ,
                    entity_id ,
                    header_id ,
                    line_id ,
                    order_source_id ,
                    original_sys_document_ref ,
                    original_sys_document_line_ref ,
                    orig_sys_shipment_ref ,
                    change_sequence ,
                    source_document_type_id ,
                    source_document_id ,
                    source_document_line_id ,
                    attribute_code ,
                    creation_date ,
                    created_by ,
                    last_update_date ,
                    last_updated_by ,
                    last_update_login ,
                    program_application_id ,
                    program_id ,
                    program_update_date ,
                    process_activity ,
                    notification_flag ,
                    type ,
                    message_source_code ,
                    message_status_code ,
                    org_id
                  )
                  VALUES
                  (
                    l_transaction_id ,
                    NULL
                    --     ,l_msg_data
                    ,
                    'LINE' ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    g_order_source_id ,
                    p_batch_order.v_order_head (hi).order_reference,-- v_orig_sys_document_ref , --changed for incident E2-IM013472372
                    p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    sysdate ,
                    g_user_id ,
                    sysdate ,
                    g_user_id ,
                    fnd_global.login_id ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    'ERROR' ,
                    'C' ,
                    'OPEN' ,
                    p_batch_order.v_order_head (hi).org_id
                  );
                BEGIN
                  INSERT
                  INTO oe_processing_msgs_tl
                    (
                      transaction_id ,
                      language ,
                      source_lang ,
                      message_text ,
                      created_by ,
                      creation_date ,
                      last_updated_by ,
                      last_update_date ,
                      last_update_login
                    )
                  SELECT l_transaction_id ,
                    l.language_code ,
                    'US' ,
                    (SELECT message_text
                    FROM fnd_new_messages
                    WHERE message_name='XXCU_TRANSPORT_ITEM'
                    AND language_code ='US'
                    ) ,
                    g_user_id ,
                    sysdate ,
                    g_user_id ,
                    sysdate ,
                    fnd_global.login_id
                  FROM fnd_languages l
                  WHERE l.installed_flag IN ('I','B')
                  AND language_code       = 'US'
                  AND NOT EXISTS
                    (SELECT NULL
                    FROM oe_processing_msgs_tl t
                    WHERE t.transaction_id = l_transaction_id
                    AND t.language         = l.language_code
                    );
                  --start defect 2891
                  INSERT
                  INTO oe_processing_msgs_tl
                    (
                      transaction_id ,
                      language ,
                      source_lang ,
                      message_text ,
                      created_by ,
                      creation_date ,
                      last_updated_by ,
                      last_update_date ,
                      last_update_login
                    )
                  SELECT l_transaction_id ,
                    l.language_code ,
                    'N' ,
                    (SELECT message_text
                    FROM fnd_new_messages
                    WHERE message_name='XXCU_TRANSPORT_ITEM'
                    AND language_code ='N'
                    ) ,
                    g_user_id ,
                    sysdate ,
                    g_user_id ,
                    sysdate ,
                    fnd_global.login_id
                  FROM fnd_languages l
                  WHERE l.installed_flag IN ('I','B')
                  AND language_code       = 'N'
                  AND NOT EXISTS
                    (SELECT NULL
                    FROM oe_processing_msgs_tl t
                    WHERE t.transaction_id = l_transaction_id
                    AND t.language         = l.language_code
                    );
                END;
                COMMIT;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              p_status_code := g_code_error;
              xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Incorrect values for Transport Item' || g_program_loc || '> ::Contact your system administrator:: ' || v_batch_seq_no || sqlerrm );
              dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
            END;
            ----Changes End by Divyansh for incident #E2-IM014174700 Defect #8447
            ----Code changes added by Divyansh for incident #E2-IM014178902 Defect #8447
            BEGIN
              BEGIN
                SELECT COUNT(1)
                INTO l_order_count
                FROM oe_order_headers_all
                WHERE orig_sys_document_ref = p_batch_order.v_order_head (hi).order_reference
                AND org_id                  = p_batch_order.v_order_head (hi).org_id
                AND order_source_id         = g_order_source_id;
              EXCEPTION
              WHEN OTHERS THEN
                l_order_count:=2;
              END;
              IF l_order_count > 0 AND upper(p_batch_order.v_order_head (hi).order_type) = 'REGULAR' THEN
                UPDATE oe_lines_iface_all
                SET error_flag         ='Y'
                WHERE orig_sys_line_ref=v_upd_orig_sys_line_ref;
                UPDATE oe_price_adjs_iface_all
                SET error_flag           ='Y'
                WHERE orig_sys_line_ref  =v_upd_orig_sys_line_ref
                AND orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;-- v_orig_sys_document_ref , --changed for incident E2-IM013472372
                COMMIT;
                -------------------------------------------------------------------
                SELECT oe_msg_id_s.nextval
                INTO l_transaction_id
                FROM dual;
                INSERT
                INTO oe_processing_msgs
                  (
                    transaction_id ,
                    request_id,
                    entity_code ,
                    entity_ref ,
                    entity_id ,
                    header_id ,
                    line_id ,
                    order_source_id ,
                    original_sys_document_ref ,
                    original_sys_document_line_ref ,
                    orig_sys_shipment_ref ,
                    change_sequence ,
                    source_document_type_id ,
                    source_document_id ,
                    source_document_line_id ,
                    attribute_code ,
                    creation_date ,
                    created_by ,
                    last_update_date ,
                    last_updated_by ,
                    last_update_login ,
                    program_application_id ,
                    program_id ,
                    program_update_date ,
                    process_activity ,
                    notification_flag ,
                    type ,
                    message_source_code ,
                    message_status_code ,
                    org_id
                  )
                  VALUES
                  (
                    l_transaction_id ,
                    NULL
                    --     ,l_msg_data
                    ,
                    'LINE' ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    g_order_source_id ,
                    p_batch_order.v_order_head (hi).order_reference,-- v_orig_sys_document_ref , --changed for incident E2-IM013472372
                    p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    sysdate ,
                    g_user_id ,
                    sysdate ,
                    g_user_id ,
                    fnd_global.login_id ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    NULL ,
                    'ERROR' ,
                    'C' ,
                    'OPEN' ,
                    p_batch_order.v_order_head (hi).org_id
                  );
                BEGIN
                  INSERT
                  INTO oe_processing_msgs_tl
                    (
                      transaction_id ,
                      language ,
                      source_lang ,
                      message_text ,
                      created_by ,
                      creation_date ,
                      last_updated_by ,
                      last_update_date ,
                      last_update_login
                    )
                  SELECT l_transaction_id ,
                    l.language_code ,
                    'US' ,
                    (SELECT message_text
                    FROM fnd_new_messages
                    WHERE message_name='XXCU_DUPLICATE_ORDER'
                    AND language_code ='US'
                    ) ,
                    g_user_id ,
                    sysdate ,
                    g_user_id ,
                    sysdate ,
                    fnd_global.login_id
                  FROM fnd_languages l
                  WHERE l.installed_flag IN ('I','B')
                  AND language_code       = 'US'
                  AND NOT EXISTS
                    (SELECT NULL
                    FROM oe_processing_msgs_tl t
                    WHERE t.transaction_id = l_transaction_id
                    AND t.language         = l.language_code
                    );
                  --start defect 2891
                  INSERT
                  INTO oe_processing_msgs_tl
                    (
                      transaction_id ,
                      language ,
                      source_lang ,
                      message_text ,
                      created_by ,
                      creation_date ,
                      last_updated_by ,
                      last_update_date ,
                      last_update_login
                    )
                  SELECT l_transaction_id ,
                    l.language_code ,
                    'N' ,
                    (SELECT message_text
                    FROM fnd_new_messages
                    WHERE message_name='XXCU_DUPLICATE_ORDER'
                    AND language_code ='N'
                    ) ,
                    g_user_id ,
                    sysdate ,
                    g_user_id ,
                    sysdate ,
                    fnd_global.login_id
                  FROM fnd_languages l
                  WHERE l.installed_flag IN ('I','B')
                  AND language_code       = 'N'
                  AND NOT EXISTS
                    (SELECT NULL
                    FROM oe_processing_msgs_tl t
                    WHERE t.transaction_id = l_transaction_id
                    AND t.language         = l.language_code
                    );
                END;
                COMMIT;
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              p_status_code := g_code_error;
              xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Duplicate Order received' || g_program_loc || '> ::Contact your system administrator:: ' || v_batch_seq_no || sqlerrm );
              dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
            END;
            ----Code changes added by Divyansh for incident #E2-IM014178902 Defect #8447
            --------------------Changes done by Divyansh for Defect #8629
            BEGIN
              SELECT COUNT(0)
              INTO l_country_codes
              FROM fnd_territories
              WHERE territory_code = p_batch_order.v_order_head (hi).orderlines(li).country_code_from
              AND obsolete_flag    = 'Y';
              IF l_country_codes   =0 THEN
                SELECT COUNT(0)
                INTO l_country_codes
                FROM fnd_territories
                WHERE territory_code = p_batch_order.v_order_head (hi).orderlines(li).country_code_to
                AND obsolete_flag    = 'Y';
              END IF;
            EXCEPTION
            WHEN OTHERS THEN
              l_country_codes:=1;
            END;
            IF l_country_codes > 0 THEN
              UPDATE oe_lines_iface_all
              SET error_flag         ='Y'
              WHERE orig_sys_line_ref=v_upd_orig_sys_line_ref;
              UPDATE oe_price_adjs_iface_all
              SET error_flag           ='Y'
              WHERE orig_sys_line_ref  =v_upd_orig_sys_line_ref
              AND orig_sys_document_ref=p_batch_order.v_order_head (hi).order_reference;-- v_orig_sys_document_ref , --changed for incident E2-IM013472372
              COMMIT;
              -------------------------------------------------------------------
              SELECT oe_msg_id_s.nextval
              INTO l_transaction_id
              FROM dual;
              INSERT
              INTO oe_processing_msgs
                (
                  transaction_id ,
                  request_id,
                  entity_code ,
                  entity_ref ,
                  entity_id ,
                  header_id ,
                  line_id ,
                  order_source_id ,
                  original_sys_document_ref ,
                  original_sys_document_line_ref ,
                  orig_sys_shipment_ref ,
                  change_sequence ,
                  source_document_type_id ,
                  source_document_id ,
                  source_document_line_id ,
                  attribute_code ,
                  creation_date ,
                  created_by ,
                  last_update_date ,
                  last_updated_by ,
                  last_update_login ,
                  program_application_id ,
                  program_id ,
                  program_update_date ,
                  process_activity ,
                  notification_flag ,
                  type ,
                  message_source_code ,
                  message_status_code ,
                  org_id
                )
                VALUES
                (
                  l_transaction_id ,
                  NULL
                  --     ,l_msg_data
                  ,
                  'LINE' ,
                  NULL ,
                  NULL ,
                  NULL ,
                  NULL ,
                  g_order_source_id ,
                  p_batch_order.v_order_head (hi).order_reference,-- v_orig_sys_document_ref , --changed for incident E2-IM013472372
                  p_batch_order.v_order_head (hi).orderlines (li).orderlineidsource ,
                  NULL ,
                  NULL ,
                  NULL ,
                  NULL ,
                  NULL ,
                  NULL ,
                  sysdate ,
                  g_user_id ,
                  sysdate ,
                  g_user_id ,
                  fnd_global.login_id ,
                  NULL ,
                  NULL ,
                  NULL ,
                  NULL ,
                  NULL ,
                  'ERROR' ,
                  'C' ,
                  'OPEN' ,
                  p_batch_order.v_order_head (hi).org_id
                );
              BEGIN
                INSERT
                INTO oe_processing_msgs_tl
                  (
                    transaction_id ,
                    language ,
                    source_lang ,
                    message_text ,
                    created_by ,
                    creation_date ,
                    last_updated_by ,
                    last_update_date ,
                    last_update_login
                  )
                SELECT l_transaction_id ,
                  l.language_code ,
                  'US' ,
                  (SELECT message_text
                  FROM fnd_new_messages
                  WHERE message_name='XXCU_INVALID_COUNTRY_CODE'
                  AND language_code ='US'
                  ) ,
                  g_user_id ,
                  sysdate ,
                  g_user_id ,
                  sysdate ,
                  fnd_global.login_id
                FROM fnd_languages l
                WHERE l.installed_flag IN ('I','B')
                AND language_code       = 'US'
                AND NOT EXISTS
                  (SELECT NULL
                  FROM oe_processing_msgs_tl t
                  WHERE t.transaction_id = l_transaction_id
                  AND t.language         = l.language_code
                  );
                --start defect 2891
                INSERT
                INTO oe_processing_msgs_tl
                  (
                    transaction_id ,
                    language ,
                    source_lang ,
                    message_text ,
                    created_by ,
                    creation_date ,
                    last_updated_by ,
                    last_update_date ,
                    last_update_login
                  )
                SELECT l_transaction_id ,
                  l.language_code ,
                  'N' ,
                  (SELECT message_text
                  FROM fnd_new_messages
                  WHERE message_name='XXCU_INVALID_COUNTRY_CODE'
                  AND language_code ='N'
                  ) ,
                  g_user_id ,
                  sysdate ,
                  g_user_id ,
                  sysdate ,
                  fnd_global.login_id
                FROM fnd_languages l
                WHERE l.installed_flag IN ('I','B')
                AND language_code       = 'N'
                AND NOT EXISTS
                  (SELECT NULL
                  FROM oe_processing_msgs_tl t
                  WHERE t.transaction_id = l_transaction_id
                  AND t.language         = l.language_code
                  );
              END;
              COMMIT;
            END IF;
            --------------------Changes complete by Divyansh for Defect #8629
          END LOOP;
          /* start defect 3310 */
          --v_orig_sys_document_ref := createorderhead_interface (p_batch_order.v_order_head (hi), p_batch_order.batchid, p_status_code, v_num_orderheads,ln_total_amount,p_error_message); --added for E2-IM013089363 (defect 8035)
          COMMIT; --added for E2-IM013089363 (defect 8035)
          /* start CR 4721 */
          BEGIN
            FOR rec_addr_print IN 1.. p_batch_order.v_order_head (hi).invaddr.count
            LOOP
              BEGIN
                IF(p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_addressee            IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_address_1 IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_address_2 IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_address_3 IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_postal_code IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_city IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_country_code IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_country_name IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_contact_person IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_contact_email IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_addressee IS
                  NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_address_1 IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_address_2 IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_address_3 IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_postal_code IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_city IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_country_code IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_country_name IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_contact_person IS NOT NULL OR p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_contact_email IS NOT NULL )THEN
                  BEGIN
                    SELECT name
                    INTO lv_order_source_cust
                    FROM oe_order_sources
                    WHERE order_source_id=g_order_source_id;
                  EXCEPTION
                  WHEN OTHERS THEN
                    lv_order_source_cust:=NULL;
                  END;
                  INSERT
                  INTO xxcu_customer_addresses VALUES
                    (
                      xxcu_customer_address_id_s.nextval,
                      g_order_number,
                      p_batch_order.v_order_head (hi).order_reference,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_addressee ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_address_1 ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_address_2 ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_address_3 ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_postal_code ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_city ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_country_code ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_country_name ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_contact_person ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).bill_to_contact_email ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_addressee ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_address_1 ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_address_2 ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_address_3 ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_postal_code ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_city ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_country_code ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_country_name ,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_contact_person,
                      p_batch_order.v_order_head (hi).invaddr(rec_addr_print).ship_to_contact_email ,
                      lv_order_source_cust,--p_batch_order.v_order_head (hi).ordeR_source        ,
                      g_user_id,
                      sysdate,
                      g_user_id,
                      sysdate,
                      NULL,
                      NULL
                    );
                  COMMIT;
                END IF;
              EXCEPTION
              WHEN OTHERS THEN
                p_status_code := 2;
                xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error while inserting records into xxcu_customer_addresses <' || g_program_loc || '> ::Contact your system administrator:: ' || sqlerrm );
                p_error_message:='Error while inserting records into xxcu_customer_addresses '||sqlerrm||dbms_utility.format_error_backtrace;
                xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => 'In Error ' || sqlerrm, msgcode => 1117, usermsg => '1', -- not sure what this is, maps to user_id in log table
                msgsrc => 'XXCU_CUSTOMER_ADDRESSES' , msgjobid => 10054);
                ROLLBACK;
              END;
            END LOOP;
          END;
          /* end CR 4721 */
          /* start wave 2 modification */
          IF(v_orig_sys_document_ref IS NOT NULL AND p_batch_order.v_order_head (hi).order_source='NO002_BUTTERFLY') THEN
            xxcu_common_log_rt.msglog ('INFO', 'Inserted in xxcu_print_criteria', 1117, 1, 'xxcu_ont_create_order_pkg BODY', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
            IF(p_batch_order.v_order_head (hi).invprint.count=0) THEN
              /**ln_spec_count                                                             := p_batch_order.v_order_head (hi).orderlines.COUNT;**/
              ln_print_count :=0;
              --  insert_invoice_spec_p(p_batch_order.v_order_head (rec_head),p_batch_order.v_order_head (rec_head).orderlines (rec_line),NULL,p_batch_order.v_order_head (rec_head).Order_Reference,p_batch_order.v_order_head (rec_head).orderlines (rec_line).orderlineidsource,g_order_number,p_status_code,p_error_message);
            ELSE
              ln_print_count:=p_batch_order.v_order_head (hi).invprint.count;
            END IF;
            IF NVL( ln_print_count ,0) >0 THEN
              BEGIN
                FOR rec_print IN 1.. ln_print_count
                LOOP
                  BEGIN
                    ln_customer_id:= getcustomer_id (p_batch_order.v_order_head (hi).customer_number);
                    SELECT DECODE(hp.party_type,'ORGANIZATION','O','P')
                    INTO lv_party_type
                    FROM hz_cust_accounts hca,
                      hz_parties hp
                    WHERE hca.cust_account_id=ln_customer_id
                    AND hca.party_id         =hp.party_id;
                  EXCEPTION
                  WHEN OTHERS THEN
                    lv_party_type:=NULL;
                  END;
                  xxcu_common_log_rt.msglog ( 'INFO', 'Inside print loop for printlines.count>0', 1117, 1, 'xxcu_ont_create_order_pkg BODY', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_pkg BODY', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ) ) ;
                  INSERT
                  INTO xxcu_custom_printcriteria VALUES
                    (
                      p_batch_order.v_order_head (hi).invprint(rec_print).messageid ,
                      p_batch_order.v_order_head (hi).order_source,
                      p_batch_order.v_order_head (hi).invprint(rec_print).receipt_reference ,
                      NULL,
                      NULL ,
                      p_batch_order.v_order_head (hi).order_reference,
                      NULL,
                      NULL,
                      sysdate,
                      g_user_id ,
                      sysdate ,
                      g_user_id ,
                      p_batch_order.v_order_head (hi).invprint(rec_print).preferred_language ,
                      p_batch_order.v_order_head (hi).invprint(rec_print).invoice_type,
                      p_batch_order.v_order_head (hi).consignment_num,
                      NULL ,
                      p_batch_order.v_order_head (hi).invprint(rec_print).invoice_settlement ,
                      p_batch_order.v_order_head (hi).master_consign_id ,
                      p_batch_order.v_order_head (hi).customs_id ,
                      p_batch_order.v_order_head (hi).invprint(rec_print).shipment_type ,
                      p_batch_order.v_order_head (hi).invprint(rec_print).customer_enclosure,
                      p_batch_order.v_order_head (hi).invprint(rec_print).inv_customer_group ,
                      p_batch_order.v_order_head (hi).invprint(rec_print).custom_clearance_status_code,
                      p_batch_order.v_order_head (hi).invprint(rec_print).adr_lev_deviation ,
                      p_batch_order.v_order_head (hi).invprint(rec_print).product ,
                      p_batch_order.v_order_head (hi).invprint(rec_print).collie ,
                      getsiteuseid (ln_customer_id, 'SHIP_TO',p_batch_order.v_order_head (hi).org_id) ,
                      p_batch_order.v_order_head (hi).invprint(rec_print).inv_split ,
                      p_batch_order.v_order_head (hi).invprint(rec_print).inv_mail ,
                      p_batch_order.v_order_head (hi).consign_item_num ,
                      NULL ,
                      p_batch_order.v_order_head (hi).customer_number,
                      lv_party_type ,
                      NULL ,
                      NULL,
                      NULL ,
                      NULL,
                      xxcu_oe_message_id_s.nextval,
                      p_batch_order.v_order_head (hi).invprint(rec_print).shipper_goods_value,
                      NULL,
                      p_batch_order.v_order_head (hi).invprint(rec_print).commodity_classification,-- CR 5310
                      p_batch_order.v_order_head (hi).invprint(rec_print).total_num_items          -- CR 5310
                    );
                  COMMIT;
                  /** END IF;**/
                END LOOP;
              EXCEPTION
              WHEN OTHERS THEN
                p_status_code := 2;
                xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error while inserting records into XXCU_CUSTOM_PRINTCRITERIA <' || g_program_loc || '> ::Contact your system administrator:: ' || sqlerrm );
                p_error_message:='Error while inserting records into XXCU_CUSTOM_PRINTCRITERIA '||sqlerrm||dbms_utility.format_error_backtrace;
                xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => 'In Error ' || sqlerrm, msgcode => 1117, usermsg => '1', -- not sure what this is, maps to user_id in log table
                msgsrc => 'XXCU_INTERFACE_SPEC_URL' , msgjobid => 10054);
                ROLLBACK;
              END;
            END IF;
          END IF;
          /* end wave 2 modification */
          --code added for defect 8003
          BEGIN
            FOR p IN 1 .. p_batch_order.v_order_head
            (
              hi
            )
            .orderlines.count
            LOOP
              dbms_output.put_line
              (
                SIGN(p_batch_order.v_order_head (hi).orderlines(p).quantity)
              )
              ;
              /* start defect 2413 */
              IF(p_batch_order.v_order_head (hi).orderlines(p).quantity=0) THEN
                ln_count                                              :=1;
              ELSE
                ln_count:=SIGN(p_batch_order.v_order_head (hi).orderlines(p).quantity);
              END IF;
              /* end defect 2413 */
              ln_sum :=ln_count+ln_sum;
            END LOOP;
            dbms_output.put_line('ln_sum:'||ln_sum);
          END;
          IF(ABS(ln_sum)<>p_batch_order.v_order_head (hi).orderlines.count) THEN
            BEGIN
              UPDATE oe_headers_iface_all
              SET error_flag             ='Y'
              WHERE orig_sys_document_ref=v_orig_sys_document_ref;
              /* UPDATE oe_lines_iface_all
              SET error_flag         ='Y'
              WHERE orig_sys_line_ref=v_upd_orig_sys_line_ref;
              UPDATE oe_price_adjs_iface_all
              SET error_flag           ='Y'
              WHERE orig_sys_line_ref  =v_upd_orig_sys_line_ref
              AND orig_sys_document_ref=v_orig_sys_document_ref;*/
              COMMIT;
              -------------------------------------------------------------------
              --  OE_MSG_PUB               BEGIN
              SELECT oe_msg_id_s.nextval
              INTO l_transaction_id
              FROM dual;
              /* SELECT message_text
              INTO lv_msg_text
              FROM fnd_new_messages
              WHERE message_name='OE_VAL_TAX_CODE_REQD'
              AND language_code =USERENV('LANG');*/
              --
              INSERT
              INTO oe_processing_msgs
                (
                  transaction_id ,
                  request_id
                  --     ,message_text
                  ,
                  entity_code ,
                  entity_ref ,
                  entity_id ,
                  header_id ,
                  line_id ,
                  order_source_id ,
                  original_sys_document_ref ,
                  original_sys_document_line_ref ,
                  orig_sys_shipment_ref ,
                  change_sequence ,
                  source_document_type_id ,
                  source_document_id ,
                  source_document_line_id ,
                  attribute_code ,
                  creation_date ,
                  created_by ,
                  last_update_date ,
                  last_updated_by ,
                  last_update_login ,
                  program_application_id ,
                  program_id ,
                  program_update_date ,
                  process_activity ,
                  notification_flag ,
                  type ,
                  message_source_code ,
                  message_status_code ,
                  org_id
                )
                VALUES
                (
                  l_transaction_id ,
                  NULL
                  --     ,l_msg_data
                  ,
                  'LINE' ,
                  NULL ,
                  NULL ,
                  NULL ,
                  NULL ,
                  g_order_source_id ,
                  v_orig_sys_document_ref ,
                  NULL,-- p_batch_order.v_order_head (hi).orderlines (p).orderlineidsource ,
                  NULL ,
                  NULL ,
                  NULL ,
                  NULL ,
                  NULL ,
                  NULL ,
                  sysdate ,
                  g_user_id ,
                  sysdate ,
                  g_user_id ,
                  fnd_global.login_id ,
                  NULL ,
                  NULL ,
                  NULL ,
                  NULL ,
                  NULL ,
                  'ERROR' ,
                  'C' ,
                  'OPEN' ,
                  p_batch_order.v_order_head (hi).org_id
                );
              --
              BEGIN
                INSERT
                INTO oe_processing_msgs_tl
                  (
                    transaction_id ,
                    language ,
                    source_lang ,
                    message_text ,
                    created_by ,
                    creation_date ,
                    last_updated_by ,
                    last_update_date ,
                    last_update_login
                  )
                SELECT l_transaction_id ,
                  l.language_code ,
                  'US' ,
                  'Mixed Order Import not allowed' ,
                  g_user_id ,
                  sysdate ,
                  g_user_id ,
                  sysdate ,
                  fnd_global.login_id
                FROM fnd_languages l
                WHERE l.installed_flag IN ('I','B')
                AND language_code       = 'US'
                AND NOT EXISTS
                  (SELECT NULL
                  FROM oe_processing_msgs_tl t
                  WHERE t.transaction_id = l_transaction_id
                  AND t.language         = l.language_code
                  );
                --start defect 2891
                INSERT
                INTO oe_processing_msgs_tl
                  (
                    transaction_id ,
                    language ,
                    source_lang ,
                    message_text ,
                    created_by ,
                    creation_date ,
                    last_updated_by ,
                    last_update_date ,
                    last_update_login
                  )
                SELECT l_transaction_id ,
                  l.language_code ,
                  'N' ,
                  'Mixed Order Import ikke tillatt',
                  g_user_id ,
                  sysdate ,
                  g_user_id ,
                  sysdate ,
                  fnd_global.login_id
                FROM fnd_languages l
                WHERE l.installed_flag IN ('I','B')
                AND language_code       = 'N'
                AND NOT EXISTS
                  (SELECT NULL
                  FROM oe_processing_msgs_tl t
                  WHERE t.transaction_id = l_transaction_id
                  AND t.language         = l.language_code
                  );
                --end
              END;
              COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
              p_status_code := g_code_error;
              xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Tax code should not be null' || g_program_loc || '> ::Contact your system administrator:: ' || v_batch_seq_no || sqlerrm );
              dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
            END;
          END IF;
          --end of code for defect 8003
          /* end defect 3310 */
        EXCEPTION
        WHEN OTHERS THEN
          p_status_code := g_code_error;
          xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Unhandled error in creation of order header: <' || g_program_loc || '> ::Contact your system administrator:: ' || v_batch_seq_no || sqlerrm );
          dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
          ROLLBACK;
        END;
        /* exception
        WHEN e_mixed_order THEN
        xxcu_log_pkg.log(p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Mixed Order Import not allowed ' || g_program_loc || ' ' || v_batch_seq_no || SQLERRM );
        p_status_code  := 2;
        p_error_message:='Mixed Order Import Not allowed';*/
      END;
      /* start CR 5027 */
      BEGIN
        SELECT COUNT(1)
        INTO ln_source_cnt
        FROM applsys.fnd_profile_options fpot,
          applsys.fnd_profile_option_values fpov
        WHERE profile_option_name    ='XXCU_KFS_ORDER_SOURCE'
        AND fpot.profile_option_id   =fpov.profile_option_id
        AND fpov.profile_option_value=p_batch_order.v_order_head (hi).order_source;
      EXCEPTION
      WHEN OTHERS THEN
        ln_source_cnt:=0;
      END;
      /* end CR 5027 */
      IF((upper(p_batch_order.v_order_head (hi).prepayment_flag)='Y' AND upper(p_batch_order.v_order_head(hi).order_type)='REGULAR') OR ln_source_cnt>0) THEN-- CR 5027
        /* start defect 3921 */
        mo_global.set_policy_context('S',p_batch_order.v_order_head (hi).org_id);
        SELECT user_id INTO g_user_id FROM fnd_user WHERE user_name='OPERATIONS';
        SELECT responsibility_id,
          application_id
        INTO ln_resp_id,
          ln_app_id
        FROM fnd_responsibility_vl
        WHERE responsibility_name = 'PB OM Super User';
        fnd_global.apps_initialize(g_user_id, ln_resp_id, ln_app_id);
        ln_req_id := fnd_request.submit_request ( application => 'XXCU' , program => 'XXCU_OE_PREPROCESSOR' , argument1 => p_batch_order.v_order_head (hi).org_id--FND_PROFILE.VALUE('ORG_ID')
        ,argument2 => p_batch_order.v_order_head (hi).order_source                                                                                               -- Order Source
        ,argument3 => p_batch_order.v_order_head (hi).order_reference                                                                                            --CR 4296                                                                                               -- Order Reference
        );
        COMMIT;
        WHILE (lv_status<>'C' AND lv_phase<>'C')
        LOOP
          BEGIN
            SELECT phase_code,
              status_code
            INTO lv_phase,
              lv_status
            FROM fnd_concurrent_requests
            WHERE request_id=ln_req_id;
          EXCEPTION
          WHEN OTHERS THEN
            lv_status:=NULL;
            lv_phase :=NULL;
          END;
        END LOOP;
        lv_status:='X';
        lv_phase :='Z';
        /* end */
        submit_order_import_request (p_batch_order.batchid,p_batch_order.v_order_head (hi).order_reference,g_org_id);
        xxcu_common_log_rt.msglog ('INFO', 'Submit Order Import ', 1117, 1, 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', xxcu_common_log_rt.set_eventjoblogstart (ip_event_id => NULL, ip_started => sysdate, ip_completed => NULL, ip_status => 1, ip_task_id => NULL, ip_msg_id => 1117, ip_source => 'xxcu_ont_create_order_parser BODY.parse_xmlmessage', ip_target_id => NULL, ip_retry => 1, ip_response => NULL, ip_paramvalues => NULL ));
      END IF;
    END LOOP;
    g_program_loc   := 'Reconciliation';
    v_finish_status := false;
    dbms_output.put_line('before reconcile:'||v_orderline_count);
    --  reconciliation (p_batch_order.batchid, p_batch_order.messagesequenceno, p_batch_order.Batchnototal, v_orderline_count, p_batch_order.batchdate, p_batch_order.batchdetailcount,v_max_date, v_min_date, p_batch_order.messagedetailcount,v_num_orderheads, v_num_orderlines, v_finish_status, v_status_function );
    ---------version 1.15-----
    reconciliation (p_batch_order.batchid, p_batch_order.messagesequenceno, p_batch_order.batchnototal, v_orderline_count, p_batch_order.batchdate,p_batch_order.batchdetailcount,-- p_batch_order.MessageDetailCount,
    v_max_date, v_min_date, p_batch_order.messagedetailcount,v_num_orderheads, v_num_orderlines,p_batch_order.numberofmessages, v_finish_status, v_status_function );
    --reconciliate number of orders received
    -- dbms_output.put_line(v_finish_status);
    IF v_finish_status THEN
      --IF (v_finish_status AND (lv_wrong_price<>'Y' AND lv_wrong_tax<>'Y' AND lv_wrong_cust<>'Y' AND lv_wrong_ref<>'Y' AND lv_wrong_ret_data <>'Y')) THEN
      dbms_output.put_line('Submit request');
      update_batch_status(p_batch_order.batchid, 'ORDER IMPORT');
      g_program_loc := 'BookOrder';
      dbms_output.put_line('g_org_id:'||g_org_id);
      ln_org_id:=g_org_id;
      /*start version 1.28 Defect 2454 */
      --submit_order_import_request (p_batch_order.batchid,g_org_id);
      /* end defect 2454 */
      --how many lines did not import?
      SELECT COUNT (*)
      INTO v_errors
      FROM oe_lines_iface_all
      WHERE error_flag          = 'Y'
      AND TRUNC (creation_date) = TRUNC (sysdate)
      AND order_source_id       = g_order_source_id;
      IF v_errors               > 0 THEN
        xxcu_log_pkg.log (p_log_level => fnd_log.level_event, p_module_name => gpackagename, p_log_text => 'Info: a few lines(' || v_errors || ') the import has failed, will move the lines again feilde over head and import the remaining' );
      END IF;
      update_batch_status(p_batch_order.batchid, 'FINISHED');
    END IF;
    /* version 1.23 CR 1899 */
    BEGIN
      /* version 1.24 CR 1929 */
      FOR rec_head IN 1 .. p_batch_order.v_order_head.count
      LOOP
        /*Start version Kavita 1.30 CR 2499*/
        /* BEGIN
        SELECT header_id
        INTO ln_header_id
        FROM oe_order_headers_all
        WHERE orig_sys_document_ref=p_batch_order.v_order_head (rec_head).Order_Reference;
        EXCEPTION
        WHEN OTHERS THEN
        ln_header_id:=NULL;
        END; */
        /*End version Kavita 1.30 CR 2499*/
        --xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => 'Going To print <' || SQLERRM, msgcode => 1117, usermsg => '1', -- not sure what this is, maps to user_id in log table
        -- msgsrc => 'XXCU_INTERFACE_SPEC_URL' , msgjobid => 10054);
        --xxcu_log_pkg.LOG (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Going To print <' || SQLERRM );
        --xxcu_log_pkg.LOG (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Excpetion occured before p_batch_order.v_order_head (rec_head).InvSpecURL.count <'|| SQLERRM );
        FOR rec_spec_url IN 1.. p_batch_order.v_order_head (rec_head).invspecurl.count
        LOOP
          -- xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => 'Excpetion occured before inserting in SPEC_URL TBL '||p_batch_order.v_order_head (rec_head).Order_Reference || SQLERRM, msgcode => 1117, usermsg => '1', -- not sure what this is, maps to user_id in log table
          --msgsrc => 'XXCU_INTERFACE_SPEC_URL' , msgjobid => 10054);
          --xxcu_log_pkg.LOG (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Excpetion occured before inserting in SPEC_URL TBL <' || v_batch_seq_no || SQLERRM );
          INSERT
            /* Start version Kavita 1.30 CR 2499*/
          INTO xxcu.xxcu_interface_spec_url VALUES
            (
              /* start defect 3218 */
              --g_order_number,                                        --added by kavita version 1.30
              NVL(p_batch_order.v_order_head (rec_head).printed_order_number,g_order_number),
              /* end defect 3218 */
              p_batch_order.v_order_head (rec_head).order_reference, --ORIG_SYS_DOCUMENT_REF
              p_batch_order.v_order_head (rec_head).order_source,    --ORDER_SOURCE
              p_batch_order.v_order_head (rec_head).invspecurl (rec_spec_url).attachment_name,
              p_batch_order.v_order_head (rec_head).invspecurl (rec_spec_url).link_url,
              p_batch_order.v_order_head (rec_head).invspecurl (rec_spec_url).link_label,
              p_batch_order.v_order_head (rec_head).invspecurl (rec_spec_url).mime_type,
              'N'
            );
          -- XXCU_INVOICE_ATTACH_SEQ.nextval,
          -- ln_header_id,
          --source
          -- p_batch_order.v_order_head (rec_head).InvSpecURL (rec_spec_url).ATTACHMENT_NAME,
          --p_batch_order.v_order_head (rec_head).InvSpecURL (rec_spec_url).LINK_URL,
          -- p_batch_order.v_order_head (rec_head).InvSpecURL (rec_spec_url).LINK_LABEL,
          --p_batch_order.v_order_head (rec_head).InvSpecURL (rec_spec_url).MIME_TYPE
          -- );
          /*End version Kavita 1.30 CR 2499*/
          COMMIT;
        END LOOP;
      END LOOP;
      --------------------------------------------------------------------------------------------------------------------------------
    EXCEPTION
    WHEN OTHERS THEN
      p_status_code := 2;
      xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error while inserting records into XXCU_INTERFACE_SPEC_URL <' || g_program_loc || '> ::Contact your system administrator:: ' || sqlerrm );
      p_error_message:='Error while inserting records into XXCU_INTERFACE_SPEC_URL '||sqlerrm||dbms_utility.format_error_backtrace;
      xxcu_common_log_rt.msglog ( msgtype => xxcu_intf_sys.gc_rlevel_info, msgtext => 'In Error ' || sqlerrm, msgcode => 1117, usermsg => '1', -- not sure what this is, maps to user_id in log table
      msgsrc => 'XXCU_INTERFACE_SPEC_URL' , msgjobid => 10054);
      dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
    END;
    -----------------------------------------------------------------------------------------
    /* start version 1.28 CR 2499 */
    /*  BEGIN
    SELECT COUNT(ooh.header_id)
    INTO ln_hold
    FROM oe_order_headers_all ooh,
    hz_cust_accounts hca,
    oe_order_lines_all ool,
    hz_parties hp,
    oe_order_holds_all hld,
    oe_hold_sources_all ohs,
    oe_hold_definitions ohd
    WHERE 1           =1
    AND hp.PARTY_ID   =hca.PARTY_ID
    AND ooh.header_id =ool.header_id
    AND ooh.org_id    =ool.org_id
    /* Version 1.2 */
    /*  AND ooh.org_id           =ln_org_id
    AND ooh.global_attribute1=p_batch_order.batchid
    AND hca.cust_account_id  =ooh.sold_to_org_id
    AND hld.header_id        = ooh.header_id
    -- and ooh.attribute15 is null
    AND hld.hold_release_id IS NULL
    AND ohs.hold_source_id   = hld.hold_source_id
    AND ohd.hold_id          = ohs.hold_id
    --             and ooh.ordeR_number=704
    AND ohd.name='Credit Check Failure';
    --Version 1.16
    /* SELECT fpovv.profile_option_value
    INTO lv_email
    FROM FND_PROFILE_OPTIONS_VL fpov,
    FND_PROFILE_OPTION_VALUES fpovv
    WHERE fpov.profile_option_name='XXCU_ONT_EMAIL_CREDIT_FAIL_NOTIF'
    AND fpovv.profile_option_id   =fpov.profile_option_id;
    submit_notification_report(p_batch_order.batchid,lv_email,g_org_id);*/
    /*  IF(ln_hold>0) THEN
    submit_release_hold_report(p_batch_order.batchid,ln_org_id);
    END IF;
    EXCEPTION
    WHEN OTHERS THEN
    p_status_code := g_code_error;
    xxcu_log_pkg.LOG (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Error in Release hold procedure<' || g_program_loc || '> ::Contact your system administrator:: ' || SQLERRM );
    dbms_output.put_line( SQLERRM||dbms_utility.format_error_backtrace);
    END;
    */
    g_program_loc := 'Finished';
    xxcu_log_pkg.log (p_log_level => fnd_log.level_procedure, p_module_name => gpackagename, p_log_text => 'Info: Processing Time; ' || v_batch_seq_no || '; ' || trim (TO_CHAR ((sysdate - v_startdate) * 1440, '999990.99')) || '; minutes on the ' || v_headers_count || '; heads and ' || v_orderline_count || '; lines.' );
    --  COMMIT;
  EXCEPTION
  WHEN e_error THEN
    xxcu_log_pkg.log(p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Untreated errors in order imports: ' || g_program_loc || ' ' || v_batch_seq_no || sqlerrm );
    p_status_code  := 2;
    p_error_message:='Duplicate Batch ID or Untreated errors in order imports';
  WHEN e_invalid_source THEN
    xxcu_log_pkg.log(p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Invalid or Null Order Source ID' || g_program_loc || ' ' || v_batch_seq_no || sqlerrm );
    p_status_code  := 2;
    p_error_message:='Invalid or Null Order Source ID';
    -- x_error_message := 'Error in XXCU_ONT_CREATE_ORDER_PKG';
    /* WHEN e_wrong_cust THEN
    xxcu_log_pkg.log(p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Invalid or null customer ' || g_program_loc || ' ' || v_batch_seq_no || SQLERRM );
    p_status_code  := 2;
    p_error_message:='Invalid or null customer';*/
  WHEN OTHERS THEN
    dbms_output.put_line( sqlerrm||dbms_utility.format_error_backtrace);
    update_batch_status(p_batch_order.batchid, 'ERROR');
    p_status_code := g_code_warning;
    xxcu_log_pkg.log (p_log_level => fnd_log.level_exception, p_module_name => gpackagename, p_log_text => 'Untreated errors in order imports: ' || g_program_loc || ' ' || v_batch_seq_no || sqlerrm );
    p_error_message:=sqlerrm||dbms_utility.format_error_backtrace;
    ROLLBACK;
    --  dbms_output.put_line(x_error_message|| dbms_utility.format_error_backtrace);
    -- p_error_message := p_error_message || '  '|| sqlerrm;
  END;