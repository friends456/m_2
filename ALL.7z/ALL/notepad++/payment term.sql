i/p--org id, currurency code, aggreement num, customer id, payment term, order source
o/p-

FUNCTION getpayment_term(
      p_org_id        NUMBER,
      p_curr_code     VARCHAR2,
      p_agreement_num VARCHAR2,
      p_cust_id       NUMBER,
      p_payment_term  VARCHAR2,-- CR 4813
      p_order_source VARCHAR2 )
	  
    RETURN NUMBER
  AS
    l_payment_term NUMBER;
  BEGIN
    /* start CR 4813 */
   

   BEGIN
      SELECT term_id INTO l_payment_term FROM ra_terms WHERE name=p_payment_term;
    EXCEPTION
    WHEN OTHERS THEN
      l_payment_term:=NULL;
    END;
   

   /* end CR 4813 */
    /* start CR 4790 */
    
	
	IF(l_payment_term IS NULL) THEN
      
	  BEGIN
        SELECT ra.term_id
        INTO l_payment_term
        FROM ra_terms ra,
          oe_blanket_headers_all obha,
          fnd_flex_value_sets ffvs,
          fnd_flex_values ffv,
          --oe_order_sources oos,
          oe_transaction_types_tl otta,
          hz_cust_accounts hca,
          oe_blanket_headers_ext obhe
        WHERE obha.sold_to_org_id                             =hca.cust_account_id
        AND otta.transaction_type_id                          =obha.order_type_id
        AND otta.language                                     ='US'
        AND obhe.order_number                                 =obha.order_number
        AND obha.org_id                                       =p_org_id
        AND ra.term_id                                        =obha.payment_term_id
        AND upper(obha.flow_status_code)                      ='ACTIVE'
        AND ffvs.flex_value_set_name                          ='XXCU_OM_SOURCE_ORDER_TYPE'
        AND ffvs.flex_value_set_id                            =ffv.flex_value_set_id
        AND NVL(upper(ffv.attribute1),upper(ffv.flex_value) ) =upper(p_order_source)
          --  AND oos.order_source_id                               =g_order_source_id
        AND upper(ffv.attribute13) =upper(otta.name)
        AND ffv.enabled_flag       ='Y'
        AND rownum                 =1--purposely used rownum because the requirement is data should come for latest activation date order in case of multiple orders
        ORDER BY obhe.start_date_active DESC;
      EXCEPTION
      WHEN OTHERS THEN
        l_payment_term:=NULL;
      END;
    END IF;
    /* end CR 4790 */
    -----------logic used as per defaulting rules set--------------------------------------
    
	
	IF(l_payment_term IS NULL) THEN
      BEGIN
        IF(p_agreement_num IS NOT NULL) THEN
          SELECT payment_term_id
          INTO l_payment_term
          FROM oe_blanket_headers_all
          WHERE org_id                      =p_org_id
          AND upper(transactional_curr_code)=upper(p_curr_code)
          AND order_number                  =p_agreement_num
          AND sold_to_org_id                =p_cust_id;
        END IF;
      EXCEPTION
      WHEN OTHERS THEN
        l_payment_term:=NULL;
      END;
    END IF;
   

   IF(l_payment_term IS NULL) THEN
      BEGIN
        SELECT payment_term_id
        INTO l_payment_term
        FROM hz_cust_site_uses_all
        WHERE site_use_id=getsiteuseid(p_cust_id,'SHIP_TO',p_org_id);
      EXCEPTION
      WHEN OTHERS THEN
        l_payment_term:=NULL;
      END;
    END IF;
    
	
	IF(l_payment_term IS NULL) THEN
      BEGIN
        SELECT payment_term_id
        INTO l_payment_term
        FROM hz_cust_site_uses_all
        WHERE site_use_id=getsiteuseid(p_cust_id,'BILL_TO',p_org_id);
      EXCEPTION
      WHEN OTHERS THEN
        l_payment_term:=NULL;
      END;
    END IF;
   
   IF(l_payment_term IS NULL) THEN
      BEGIN
        SELECT standard_terms
        INTO l_payment_term
        FROM hz_customer_profiles
        WHERE cust_account_id=p_cust_id
        AND status           ='A'
        AND site_use_id     IS NULL;
      EXCEPTION
      WHEN OTHERS THEN
        l_payment_term:=NULL;
      END;
    END IF;
    
	
	
	IF(l_payment_term IS NULL) THEN
      BEGIN
        SELECT terms_id
        INTO l_payment_term
        FROM oe_price_lists_v
        WHERE price_list_id          =getpricelistid (p_curr_code)
        AND (TRUNC(end_date_active) IS NULL
        OR TRUNC(end_date_active)   >=TRUNC(sysdate));
      EXCEPTION
      WHEN OTHERS THEN
        l_payment_term:=NULL;
      END;
    END IF;
	
	
    RETURN l_payment_term;
  EXCEPTION
  WHEN OTHERS THEN
    xxcu_log_pkg.log (p_log_level => fnd_log.level_statement, p_module_name => gpackagename, p_log_text => 'Error i getpayment_term function ' );
	
    RETURN NULL;
  END;