 PROCEDURE initialize_variables
    (
      p_org_id IN NUMBER
    )
  IS
    l_location      VARCHAR2(100);
    l_status_code   NUMBER;
    l_message       VARCHAR2(1000);
    ln_user_id      NUMBER;
    ln_resp_id      NUMBER;
    ln_resp_appl_id NUMBER;
    l_org_name      VARCHAR2(100);
  BEGIN
   
    BEGIN
      SELECT name
      INTO l_org_name
      FROM hr_operating_units
      WHERE organization_id=p_org_id;
	  
      SELECT userid,
        respid,
        respapplid
      INTO ln_user_id,
        ln_resp_id,
        ln_resp_appl_id
      FROM xxcu_int_init_app_logons
      WHERE procedure_name          =upper('XXCU_ONT_CREATE_ORDER_PKG')
      AND upper(operating_unit_name)=upper(l_org_name);
	  
    EXCEPTION
    WHEN OTHERS THEN
      ln_user_id     :=fnd_global.user_id;
      ln_resp_id     :=fnd_global.resp_id;
      ln_resp_appl_id:=fnd_global.resp_appl_id;
    END;
	
	
    fnd_global.apps_initialize (ln_user_id, ln_resp_id, ln_resp_appl_id);--1352
    g_user_id:=ln_user_id;
    g_org_id :=p_org_id;
	
    --  MO_GLOBAL.INIT('ONT');
    mo_global.set_policy_context('S',g_org_id);
	
    oe_msg_pub.initialize;
    -- xxcu_int_util_pkg.int_apps_initialize(apps.fnd_profile.VALUE('ORG_ID'), upper('XXCU_ONT_CREATE_ORDER_PKG'), l_status_code, l_message);
    COMMIT;
    --COMMIT;
  EXCEPTION
  WHEN OTHERS THEN
    xxcu_log_pkg.log (p_log_level => fnd_log.level_error, p_module_name => gpackagename, p_log_text => 'Error in initialization of variables by "' ||l_location||'"' || ' :: Ensure value set XXCU_ONT_LM_CONFIG_VALUES :: ' );
  END;